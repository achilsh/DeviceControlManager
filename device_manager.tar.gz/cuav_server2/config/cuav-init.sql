-- cuav DATABASE 初始化数据库脚本
-- name: cuav-init

DROP TABLE IF EXISTS "tracers_orientation_detect_drone";
CREATE TABLE "tracers_orientation_detect_drone"
(
    "id"                integer NOT NULL,
    "sn"                text, -- 检测设备tracerS sn
    "drone_number"      integer, -- 无人机编号
    "drone_name"        text,     --- 无人机名称
    "freq"              integer, -- mhz
    "azimuth"           integer, -- 方位角
    "create_time"       integer, -- 创建时间
    "update_time"       integer,
    "status"            integer, -- 1: 开始定向且未定向到无人机， 2：已经定向无人机
    CONSTRAINT "radar_adc_pkey" PRIMARY KEY ("id")
);
CREATE INDEX orientation_detect_drone_index ON tracers_orientation_detect_drone(drone_number, drone_name, freq);

-- autel_radar_adc definition

DROP TABLE IF EXISTS "autel_radar_adc";
CREATE TABLE "autel_radar_adc"
(
    "id"                integer NOT NULL,
    "info_sycn"         integer,
    "info_type"         integer,
    "info_length"       integer,
    "frame_id"          integer,
    "crt_time"          text(30),
    "terminal_id"       integer,
    "terminal_type"     integer,
    "sub_terminal_type" integer,
    "info_version"      integer,
    "reserved1"         integer,
    "length"            integer,
    "type"              integer,
    "raw_data"          integer,
    "reserved2"         integer,
    "crc"               integer,
    "timestamp"         integer,
    CONSTRAINT "radar_adc_pkey" PRIMARY KEY ("id")
);

-- autel_radar_carry_platform definition

DROP TABLE IF EXISTS "autel_radar_carry_platform";
CREATE TABLE "autel_radar_carry_platform"
(
    "id"                integer NOT NULL,
    "info_sycn"         integer,
    "info_type"         integer,
    "info_length"       integer,
    "frame_id"          integer,
    "crt_time"          text(30),
    "terminal_id"       integer,
    "terminal_type"     integer,
    "sub_terminal_type" integer,
    "info_version"      integer,
    "reserved1"         integer,
    "heading"           real,
    "pitching"          real,
    "rolling"           real,
    "longitude"         real,
    "latitude"          real,
    "altitude"          real,
    "velocity_navi"     real,
    "target_time_mark"  integer,
    "sig_relative_time" real,
    "reserve"           integer,
    "reserved2"         integer,
    "crc"               integer,
    "timestamp"         integer,
    CONSTRAINT "radar_carry_platform_pkey" PRIMARY KEY ("id")
);

-- autel_radar_plot_track_body definition

DROP TABLE IF EXISTS "autel_radar_plot_track_body";
CREATE TABLE "autel_radar_plot_track_body"
(
    "id"                integer NOT NULL,
    "obj_id"            integer,
    "header_uid"        integer,
    "azimuth"           real,
    "obj_dist_interpol" real,
    "elevation"         real,
    "velocity"          real,
    "doppler_chn"       integer,
    "mag"               real,
    "ambiguous"         integer,
    "classification"    integer,
    "classfy_prob"      real,
    "existing_prob"     real,
    "abs_vel"           real,
    "orientation_angle" real,
    "alive"             integer,
    "tws_tas_flag"      integer,
    "x"                 real,
    "y"                 real,
    "z"                 real,
    "vx"                real,
    "vy"                real,
    "vz"                real,
    "ax"                real,
    "ay"                real,
    "az"                real,
    "x_variance"        real,
    "y_variance"        real,
    "z_variance"        real,
    "vx_variance"       real,
    "vy_variance"       real,
    "vz_variance"       real,
    "ax_variance"       real,
    "ay_variance"       real,
    "az_variance"       real,
    "state_type"        integer,
    "motion_type"       integer,
    "forcast_frame_num" integer,
    "association_num"   integer,
    "assoc_bit0"        integer,
    "assoc_bit1"        integer,
    "reserve"           integer,
    "reserved2"         integer,
    "crc"               integer,
    "create_time"       text(6),
    "vendor"            text(255),
    "frequency"         text(255),
    "model"             text(255),
    "is_whitelist"      text(5),
    CONSTRAINT "radar_plot_track_body_pkey" PRIMARY KEY ("id")
);

-- autel_radar_plot_track_header definition

DROP TABLE IF EXISTS "autel_radar_plot_track_header";
CREATE TABLE "autel_radar_plot_track_header"
(
    "id"                 integer NOT NULL,
    "info_sync"          integer,
    "info_type"          integer,
    "info_length"        integer,
    "frame_id"           integer,
    "crt_time"           text(30),
    "terminal_id"        integer,
    "terminal_type"      integer,
    "sub_terminal_type"  integer,
    "info_version"       integer,
    "reserved1"          integer,
    "track_obj_num"      integer,
    "track_tws_num"      integer,
    "track_tas_num"      integer,
    "track_obj_byte"     integer,
    "track_tws_tas_flag" integer,
    "reserved"           integer,
    "timestamp"          integer,
    "update_header_id"   integer,
    uid                  int,
    CONSTRAINT "radar_plot_track_header_pkey" PRIMARY KEY ("id")
);

-- autel_radar_point_track_body definition

DROP TABLE IF EXISTS "autel_radar_point_track_body";
CREATE TABLE "autel_radar_point_track_body"
(
    "id"                integer NOT NULL,
    "obj_id"            integer,
    "point_header_id"   integer,
    "azimuth"           real,
    "obj_dist_interpol" real,
    "elevation"         real,
    "velocity"          real,
    "doppler_chn"       integer,
    "mag"               real,
    "obj_confidence"    real    NOT NULL,
    "ambiguous"         integer,
    "classification"    integer,
    "classfy_prob"      real,
    "cohesion_ok_flag"  integer,
    "cohesion_pnt_num"  integer,
    "cohesion_beam_num" integer,
    "azi_beam_id"       integer,
    "ele_beam_id"       integer,
    "reserved"          integer,
    "reserved2"         integer,
    "crc"               integer,
    CONSTRAINT "radar_point_track_body_pkey" PRIMARY KEY ("id")
);

-- autel_radar_point_track_header definition

DROP TABLE IF EXISTS "autel_radar_point_track_header";
CREATE TABLE "autel_radar_point_track_header"
(
    "id"                 integer NOT NULL,
    "info_sycn"          integer,
    "info_type"          integer,
    "info_length"        integer,
    "frame_id"           integer,
    "crt_time"           text(30),
    "terminal_id"        integer,
    "terminal_type"      integer,
    "sub_terminal_type"  integer,
    "info_version"       integer,
    "reserved1"          integer,
    "detect_obj_num"     integer,
    "detect_obj_byte"    integer,
    "track_tws_tas_flag" integer,
    "reserved"           integer,
    "timestamp"          integer,
    "update_header_id"   integer,
    CONSTRAINT "radar_point_track_header_pkey" PRIMARY KEY ("id")
);

-- autel_radar_setting definition

DROP TABLE IF EXISTS "autel_radar_setting";
CREATE TABLE "autel_radar_setting"
(
    "id"                      integer NOT NULL,
    "info_sycn"               integer,
    "info_type"               integer,
    "info_length"             integer,
    "frame_id"                integer,
    "crt_time"                text(30),
    "terminal_id"             integer,
    "terminal_type"           integer,
    "sub_terminal_type"       integer,
    "info_version"            integer,
    "reserved1"               integer,
    "tr_switch_ctrl"          text(20),
    "work_mode"               integer,
    "work_wave_code"          text(20),
    "work_freq_code"          integer,
    "prf_period"              integer,
    "accu_num"                integer,
    "noise_coef"              real,
    "clutter_coef"            real,
    "cfar_coef"               real,
    "focus_range_min"         integer,
    "focus_range_max"         integer,
    "clutter_curve_num"       integer,
    "lobe_comp_coef"          real,
    "cohesion_vel_thre"       integer,
    "cohesion_rgn_thre"       integer,
    "clutter_map_switch"      integer,
    "clutter_map_update_coef" integer,
    "azi_calc_slope"          integer,
    "azi_calc_phase"          integer,
    "ele_calc_slope"          integer,
    "ele_calc_phase"          integer,
    "azi_scan_center"         integer,
    "azi_scan_scope"          integer,
    "ele_scan_center"         integer,
    "ele_scan_scope"          integer,
    "coherent_detect_switch"  integer,
    "reserve"                 integer,
    "reserved2"               integer,
    "crc"                     integer,
    "data_from"               integer,
    "timestamp"               integer,
    CONSTRAINT "radar_setting_pkey" PRIMARY KEY ("id")
);

-- autel_radar_statu definition

DROP TABLE IF EXISTS "autel_radar_statu";
CREATE TABLE "autel_radar_statu"
(
    "id"                integer NOT NULL,
    "info_sync"         integer,
    "info_type"         integer,
    "info_length"       integer,
    "frame_id"          integer,
    "crt_time"          text(6),
    "terminal_id"       integer,
    "terminal_type"     integer,
    "sub_terminal_type" integer,
    "info_version"      integer,
    "reserved1"         integer,
    "is_fail_flag"      integer,
    "fail_bit_data1"    integer,
    "fail_bit_data2"    integer,
    "battery_power"     real,
    "reserve"           integer,
    "reserved2"         integer,
    "crc"               integer,
    "timestamp"         integer,
    "udp_header_uid"    integer,
    CONSTRAINT "radar_fault_statu_pkey" PRIMARY KEY ("id")
);

-- autel_radar_udp_header definition

DROP TABLE IF EXISTS "autel_radar_udp_header";
CREATE TABLE "autel_radar_udp_header"
(
    "id"                    integer NOT NULL,
    "packet_flag"           integer,
    "total_packet_num"      integer,
    "packet_length"         integer,
    "send_info_count"       integer,
    "terminal_type"         integer,
    "sub_terminal_type"     integer,
    "info_type"             integer,
    "info_packet_num"       integer,
    "cur_info_packet_order" integer,
    "reserved"              integer,
    "uid"                   integer,
    CONSTRAINT "radar_udp_header_pkey" PRIMARY KEY ("id")
);

-- autel_radar_wave_control definition

DROP TABLE IF EXISTS "autel_radar_wave_control";
CREATE TABLE "autel_radar_wave_control"
(
    "id"                         integer NOT NULL,
    "info_sycn"                  integer,
    "info_type"                  integer,
    "info_length"                integer,
    "frame_id"                   integer,
    "crt_time"                   text(30),
    "terminal_id"                integer,
    "terminal_type"              integer,
    "sub_terminal_type"          integer,
    "info_version"               integer,
    "reserved1"                  integer,
    "azi_beam_id"                integer,
    "ele_beam_id"                integer,
    "azi_beam_sin"               real,
    "ele_beam_sin"               real,
    "tas_beam_total"             integer,
    "tas_beam_cnt_cur"           integer,
    "tas_obj_id"                 integer,
    "tas_obj_filter_num"         integer,
    "tas_obj_range"              integer,
    "sample_pnt_start"           integer,
    "sample_pnt_depth"           integer,
    "beam_switch_time"           integer,
    "whole_space_scan_cycle_cnt" integer,
    "track_tws_tas_flag"         integer,
    "reserve"                    integer,
    "reserved2"                  integer,
    "crc"                        integer,
    "timestamp"                  integer,
    CONSTRAINT "radar_wave_control_pkey" PRIMARY KEY ("id")
);

-- drone_white_list definition

DROP TABLE IF EXISTS "drone_white_list";
CREATE TABLE "drone_white_list"
(
    "id"        integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "vendor"    text      NOT NULL,
    "model"     text      NOT NULL,
    "frequency" text      NOT NULL,
    "sn"        text      NOT NULL,
    "role"      integer   NOT NULL,
    created_at  timestamp not null,
    updated_at  timestamp not null,
    CONSTRAINT "drone_white_list_unique" UNIQUE ("sn")
);


-- date_markers definition  时间标记

DROP TABLE IF EXISTS "date_markers";
CREATE TABLE "date_markers"
(
    "id"         integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "time_stamp" text    not null,
    "level"      integer not null,
    "tips"       text,
    "creat_time" integer,

    CONSTRAINT "date_markers_unique" UNIQUE ("id")
);
-- sfl_detect_info  云台侦测、打击信息

DROP TABLE IF EXISTS "sfl_detect_info";
CREATE TABLE "sfl_detect_info"
(
    "id"             integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "sn"             text not null,
    "vendor"         text,
    "detect_time"    integer,
    "hit_time"       integer,
    "counter_time"   integer,
    "freq"           integer,
    "direction"      integer,
    "pilot_long_lat" text,
    CONSTRAINT "sfl_detect_info_unique" UNIQUE ("id")
);


-- dev_date_schedule definition  数据回放，存储某个设备某天是否有数据

DROP TABLE IF EXISTS "dev_date_schedule";
CREATE TABLE "dev_date_schedule"
(
    "id"          integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "sn"          text,
    "date"        text(8),
    "information" integer,

    CONSTRAINT "dev_date_schedule_unique" UNIQUE ("id")
);

-- dev_date_schedule definition  数据回放，存储某个设备某天是否有数据

-- DROP TABLE IF EXISTS "radar_replay_detect";
-- CREATE TABLE "radar_replay_detect"
-- (
--     "id"       integer PRIMARY KEY AUTOINCREMENT NOT NULL,
--     "sn"       text                              NOT NULL,
--     "x"        real                              NOT NULL,
--     "y"        real                              NOT NULL,
--     "z"        real                              NOT NULL,
--     "velocity" real                              NOT NULL,
--     created_at timestamp                         NOT null,
--     CONSTRAINT "radar_replay_detect" UNIQUE ("id")
--
-- );
-- CREATE INDEX created_at_index ON radar_replay_detect (created_at);

-- log_status definition
DROP TABLE IF EXISTS "log_status";
CREATE TABLE "log_status"
(
    "id"     integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "sn"     text    NOT NULL,
    "status" integer NOT NULL,
    "path"   text    NOT NULL,
    "proid"  integer NOT NULL,
    CONSTRAINT "log_status_unique" UNIQUE ("sn")
);
-- log_cloud_status definition

-- nsf400_config definition
DROP TABLE IF EXISTS "nsf4000_config";
CREATE TABLE "nsf4000_config"
(
    "id"                     integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "sn"                     text NOT NULL,
    "radius"                 integer,
    "power"                  integer,
    "defense_level_speed"    integer,
    "defense_vertical_speed" integer,
    "longitude"              real,
    "latitude"               real,
    "height"                 integer,
    "drive_level_speed"      integer,
    "drive_vertical_speed"   integer,
    CONSTRAINT "nsf4000_config_unique" UNIQUE ("sn")
);
-- nsf400_config definition


DROP TABLE IF EXISTS "log_cloud_status";
CREATE TABLE "log_cloud_status"
(
    "id"     integer PRIMARY KEY NOT NULL,
    "path"   text                NOT NULL,
    "status" integer             NOT NULL,
    "proid"  integer             NOT NULL,

    CONSTRAINT "log_cloud_status_unique" UNIQUE ("id")
);
-- c2_license definition

DROP TABLE IF EXISTS "c2_license";
CREATE TABLE "c2_license"
(
    "license_id"   text PRIMARY KEY NOT NULL,
    "mac_addr"     text             NOT NULL,
    "start_time"   text             NOT NULL,
    "stop_time"    text             NOT NULL,
    "last_time"    text             NOT NULL,
    "expires"      integer          NOT NULL,
    "license_type" text             NOT NULL,
    "user_name"    text             NOT NULL,
    "user_phone"   text             NOT NULL,
    "user_email"   text             NOT NULL,
    CONSTRAINT "c2_license_unique" UNIQUE ("license_id")
);

-- log_id definition

DROP TABLE IF EXISTS "log_id";
CREATE TABLE "log_id"
(
    "id"     integer PRIMARY KEY NOT NULL,
    "log_id" text                NOT NULL,
    CONSTRAINT "log_id_unique" UNIQUE ("log_id")
);

-- log_id definition

DROP TABLE IF EXISTS "c2_id";
CREATE TABLE "c2_id"
(
    "id"    integer PRIMARY KEY NOT NULL,
    "c2_id" text                NOT NULL,
    CONSTRAINT "c2_id_unique" UNIQUE ("c2_id")
);


-- equip_list definition

DROP TABLE IF EXISTS "equip_list";
CREATE TABLE "equip_list"
(
    "id"              integer NOT NULL,
    "reverse"         varchar,
    "terminal_id"     text(32) NOT NULL,
    "etype"           text(10),
    "tcp_port"        integer,
    "udp_port"        integer,
    "ip"              text(255),
    "crt_time"        text(30),
    "status"          text(255),
    "update_time"     text(30),
    "frequency"       TEXT,
    "model"           TEXT,
    "protocol"        TEXT,
    "vendor"          TEXT,
    "name"            text(255),
    "connect_str"     text(255),
    "content"         text(255),
    "sub_type"        varchar,
    "local_ip"        varchar,
    "local_udp_port"  int,
    "is_enable"       INTEGER NOT NULL DEFAULT (1),
    "sn"              TEXT    NOT NULL UNIQUE,
    "is_online"       INTEGER NOT NULL,
    "radar_relevance" int,
    "dev_version"     text,
    CONSTRAINT "equip_list_pkey" PRIMARY KEY ("id")
);


-- equip_list_backup  definition
DROP TABLE IF EXISTS "equip_list_backup";
CREATE TABLE "equip_list_backup"
(
    "id"              integer NOT NULL,
    "reverse"         varchar,
    "terminal_id"     text(32) NOT NULL,
    "etype"           text(10),
    "tcp_port"        integer,
    "udp_port"        integer,
    "ip"              text(255),
    "crt_time"        text(30),
    "status"          text(255),
    "update_time"     text(30),
    "frequency"       TEXT,
    "model"           TEXT,
    "protocol"        TEXT,
    "vendor"          TEXT,
    "name"            text(255),
    "connect_str"     text(255),
    "content"         text(255),
    "sub_type"        varchar,
    "local_ip"        varchar,
    "local_udp_port"  int,
    "is_enable"       INTEGER NOT NULL DEFAULT (1),
    "sn"              TEXT    NOT NULL UNIQUE,
    "is_online"       INTEGER NOT NULL,
    "radar_relevance" int,
    CONSTRAINT "equip_list_backup_pkey" PRIMARY KEY ("id")
);

-- equip_source_id definition

DROP TABLE IF EXISTS "equip_source_id";
CREATE TABLE "equip_source_id"
(
    "id"          INTEGER NOT NULL,
    "sn"          TEXT    NOT NULL,
    "source_id"   INTEGER NOT NULL,
    "create_time" TEXT    NOT NULL,
    "update_time" TEXT    NOT NULL,
    CONSTRAINT "equip_source_id_pkey" PRIMARY KEY ("id")
);

-- event_list definition

DROP TABLE IF EXISTS "event_list";
CREATE TABLE "event_list"
(
    "id"         integer NOT NULL,
    "eid"        text    NOT NULL,
    "vendor"     text,
    "model"      text,
    "begin_time" text,
    "end_time"   text,
    "duration"   real,
    "altitude"   real,
    "frequency"  real,
    "protocol"   text,
    "status"     integer NOT NULL, -- -1事件结束，1事件开始
    "source"     integer NOT NULL, -- 1雷达，2枪
    "obj_id"     integer,
    "serial_num" text,
    CONSTRAINT "event_list_pkey" PRIMARY KEY ("id")
);

-- log definition

DROP TABLE IF EXISTS "log";
CREATE TABLE "log"
(
    "id"       integer NOT NULL,
    "user_id"  integer,
    "type"     integer,
    "command"  integer,
    "lastip"   text(20),
    "os"       text(20),
    "osvesion" text(30),
    "crt_time" text(30),
    "reserve"  text,
    CONSTRAINT "log_pkey" PRIMARY KEY ("id")
);
-- flight_list definition

DROP TABLE IF EXISTS "flight_list";
CREATE TABLE "flight_list"
(
    "id"              integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "drone_name"      text,
    "vendor"          text,
    "freq"            real,
    "dev_type"        integer,
    "serial_num"      text,
    "begin_time"      real,
    "end_time"        real,
    "duration_time"   real,
    "height"          real,
    "protocol"        text,
    "drone_yaw_angle" real,
    CONSTRAINT "flight_list" UNIQUE ("id")
);
-- statistic_list definition

DROP TABLE IF EXISTS "statistic_list";
CREATE TABLE "statistic_list"
(
    "id"        integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "fly_count" integer,
    "last_time" integer,

    CONSTRAINT "statistic_list" UNIQUE ("id")
);

INSERT INTO statistic_list (id, fly_count, last_time)
VALUES (1, 0, 0);
-- record_list definition

DROP TABLE IF EXISTS "record_list";
CREATE TABLE "record_list"
(
    "id"                integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "dev_type"          integer,
    "detect_table_name" text NOT NULL UNIQUE,
    CONSTRAINT "record_list" UNIQUE ("id")
);
-- remote_alarm definition

DROP TABLE IF EXISTS "remote_alarm";
CREATE TABLE "remote_alarm"
(
    "id"         integer NOT NULL,
    "phone"      text,
    "email"      text,
    "open"       integer,
    "alarm_time" integer,
    CONSTRAINT "remote_alarm_pkey" PRIMARY KEY ("id")
);

-- "role" definition

DROP TABLE IF EXISTS "role";
CREATE TABLE "role"
(
    "id"          integer NOT NULL,
    "name"        text(20),
    "status"      text(5),
    "crt_time"    text(30),
    "update_time" text(30),
    "remark"      text(50),
    CONSTRAINT "role_pkey" PRIMARY KEY ("id")
);

-- sms definition

DROP TABLE IF EXISTS "sms";
CREATE TABLE "sms"
(
    "id"         integer NOT NULL,
    "phone"      text,
    "request_id" text,
    "message"    text,
    "biz_id"     text,
    "code"       text,
    CONSTRAINT "sms_pkey" PRIMARY KEY ("id")
);

-- track_waveforms definition

DROP TABLE IF EXISTS "track_waveforms";
CREATE TABLE "track_waveforms"
(
    "id"                      integer NOT NULL,
    "waveform"                text(20),
    "max_distance_target"     real,
    "max_target_time_delay"   real,
    "signal_bandwidth"        integer,
    "sampl_points"            integer,
    "sampl_window_time"       real,
    "sweep_fallback_time"     real,
    "effective_bandwidth"     real,
    "modulation_period"       real,
    "pulse_repetition_period" real,
    "differential_beat_echo"  real,
    "wave_dwell_time"         real,
    CONSTRAINT "track_waveforms_pkey" PRIMARY KEY ("id")
);

-- radar_tcp_track_info

DROP TABLE IF EXISTS "radar_tcp_track_info";
CREATE TABLE radar_tcp_track_info
(
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    uid            INTEGER,
    sn             TEXT,
    reserved       INTEGER,
    track_obj_num  INTEGER,
    track_tws_num  INTEGER,
    track_tas_num  INTEGER,
    track_obj_byte INTEGER,
    received_time  INTEGER
);

CREATE INDEX radar_tcp_track_info_uid_index ON radar_tcp_track_info (uid);

-- radar_tcp_track_target

DROP TABLE IF EXISTS "radar_tcp_track_target";
CREATE TABLE "radar_tcp_track_target"
(
    "id"                integer PRIMARY KEY AUTOINCREMENT,
    "sn"                TEXT,
    "obj_id"            integer,
    "header_uid"        INTEGER,
    "azimuth"           real,
    "obj_dist_interpol" real,
    "elevation"         real,
    "velocity"          real,
    "doppler_chn"       integer,
    "mag"               real,
    "ambiguous"         integer,
    "classification"    integer,
    "classfy_prob"      real,
    "existing_prob"     real,
    "abs_vel"           real,
    "orientation_angle" real,
    "alive"             integer,
    "tws_tas_flag"      integer,
    "x"                 real,
    "y"                 real,
    "z"                 real,
    "vx"                real,
    "vy"                real,
    "vz"                real,
    "ax"                real,
    "ay"                real,
    "az"                real,
    "x_variance"        real,
    "y_variance"        real,
    "z_variance"        real,
    "vx_variance"       real,
    "vy_variance"       real,
    "vz_variance"       real,
    "ax_variance"       real,
    "ay_variance"       real,
    "az_variance"       real,
    "state_type"        integer,
    "motion_type"       integer,
    "forcast_frame_num" integer,
    "association_num"   integer,
    "assoc_bit0"        integer,
    "assoc_bit1"        integer,
    "reserve"           integer,
    "reserved2"         integer,
    "crc"               integer,
    "create_time"       text(6),
    "vendor"            text(255),
    "frequency"         text(255),
    "model"             text(255),
    "is_whitelist"      text(5)
);

CREATE INDEX radar_tcp_track_target_header_uid_index ON radar_tcp_track_target (header_uid);

-- radar_tcp_posture_info

DROP TABLE IF EXISTS "radar_tcp_posture_info";
CREATE TABLE radar_tcp_posture_info
(
    id                     INTEGER PRIMARY KEY AUTOINCREMENT,
    sn                     TEXT,
    reserved               INTEGER,
    heading                REAL,
    pitching               REAL,
    rolling                REAL,
    longitude              REAL,
    latitude               REAL,
    altitude               REAL,
    velocity_navi          REAL,
    sig_proc_relative_time REAL
);

-- radar_tcp_heart

DROP TABLE IF EXISTS "radar_tcp_heart";
CREATE TABLE radar_tcp_heart
(
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    sn          TEXT,
    electricity INTEGER,
    status      INTEGER,
    is_online   INTEGER,
    ip          TEXT,
    serial_num  TEXT
);

-- gun_tcp_heart

DROP TABLE IF EXISTS "gun_tcp_heart";
CREATE TABLE gun_tcp_heart
(
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    header_id       INTEGER,
    time_stamp      INTEGER,
    screen_status   INTEGER,
    electricity     INTEGER,
    signal_strength INTEGER,
    work_status     INTEGER,
    alarm_level     INTEGER,
    hit_freq        INTEGER,
    detect_freq     INTEGER,
    x               INTEGER,
    y               INTEGER,
    z               INTEGER,
    gun_longitude   real,
    gun_latitude    real,
    gun_altitude    INTEGER,
    satellites_num  INTEGER,
    gun_direction   real,
    elevation       real,
    u_drone_num     INTEGER,
    received_time   INTEGER
);

CREATE INDEX gun_tcp_heart_header_id_index ON gun_tcp_heart (header_id);

-- gun_tcp_heart_uav

DROP TABLE IF EXISTS "gun_tcp_heart_uav";
CREATE TABLE gun_tcp_heart_uav
(
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    header_id            INTEGER,
    product_type         INTEGER,
    drone_name           TEXT,
    serial_num           TEXT,
    drone_longitude      real,
    drone_latitude       real,
    drone_height         real,
    drone_yaw_angle      real,
    drone_speed          real,
    drone_vertical_speed real,
    pilot_longitude      real,
    pilot_latitude       real,
    u_freq               real,
    u_distance           INTEGER,
    u_danger_levels      INTEGER
);

CREATE INDEX gun_tcp_heart_uav_header_id_index ON gun_tcp_heart_uav (header_id);

-- tracer_tcp_heart

DROP TABLE IF EXISTS "tracer_tcp_heart";
CREATE TABLE tracer_tcp_heart
(
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    header_id       INTEGER,
    time_stamp      INTEGER,
    screen_status   INTEGER,
    electricity     INTEGER,
    signal_strength INTEGER,
    work_status     INTEGER,
    alarm_level     INTEGER,
    hit_freq        INTEGER,
    detect_freq     INTEGER,
    elevation       real,
    gun_longitude   real,
    gun_latitude    real,
    gun_altitude    INTEGER,
    satellites_num  INTEGER,
    gun_direction   real,
    sn              TEXT,
    u_drone_num     INTEGER,
    received_time   INTEGER
);

CREATE INDEX tracer_tcp_heart_header_id_index ON tracer_tcp_heart (header_id);

-- tracer_tcp_heart_uav

DROP TABLE IF EXISTS "tracer_tcp_heart_uav";
CREATE TABLE tracer_tcp_heart_uav
(
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    header_id            INTEGER,
    product_type         INTEGER,
    drone_name           TEXT,
    serial_num           TEXT,
    drone_longitude      real,
    drone_latitude       real,
    drone_height         real,
    drone_yaw_angle      real,
    drone_speed          real,
    drone_vertical_speed real,
    operator_longitude   real,
    operator_latitude    real,
    drone_horizon        real,
    drone_pitch          real,
    freq                 real,
    distance             INTEGER,
    danger_levels        INTEGER,
    waypoint_longitude   real,
    waypoint_latitude    real
);


-- tracer_tcp_heart_uav

DROP TABLE IF EXISTS "tracer_detect_info";
CREATE TABLE tracer_detect_info
(
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    detect_id            INTEGER,
    product_type         INTEGER,
    drone_name           TEXT,
    serial_num           TEXT,
    drone_longitude      real,
    drone_latitude       real,
    drone_height         real,
    drone_yaw_angle      real,
    drone_speed          real,
    drone_vertical_speed real,
    operator_longitude   real,
    operator_latitude    real,
    freq                 real,
    distance             INTEGER,
    danger_levels        INTEGER,
    received_time        INTEGER
);

CREATE INDEX tracer_tcp_heart_uav_header_id_index ON tracer_tcp_heart_uav (header_id);

-- device_comm_log

DROP TABLE IF EXISTS "device_comm_log";
CREATE TABLE device_comm_log
(
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    device_type INTEGER,
    sn          TEXT,
    msg_id      INTEGER,
    request     TEXT,
    response    TEXT,
    remark      TEXT,
    create_time INTEGER
);

-- system_config definition

DROP TABLE IF EXISTS "system_config";
CREATE TABLE "system_config"
(
    "id"             integer NOT NULL,
    "longitude"      real,
    "latitude"       real,
    "heading"        integer,
    "arch"           integer,
    "terminal_id"    text(255),
    "etype"          text(50),
    "warning_radius" real,
    "counter_radius" real,
    "fence_radius"   real,
    "scanner_radius" real,
    "height"         real,
    "c2_longitude"   real,
    "c2_latitude"    real,
    CONSTRAINT "system_config_pkey" PRIMARY KEY ("id")
);

INSERT INTO system_config (id, longitude, latitude, heading, arch, terminal_id, etype, warning_radius, counter_radius,
                           fence_radius, scanner_radius, height, c2_longitude, c2_latitude)
VALUES (1, -180, -180, 180, 60, '1', '28', 3000.0, 500.0, 200.0, 900.0, 250, -180, -180);


-- user_base definition

DROP TABLE IF EXISTS "user_base";
CREATE TABLE "user_base"
(
    "id"               integer NOT NULL,
    "role"             text(20),
    "name"             text(20) NOT NULL UNIQUE,
    "nick_name"        text(20),
    "gender"           text(5),
    "mobile"           text(20),
    "email"            text(20),
    "crt_time"         text(30),
    "push_token"       text(20),
    "password"         text(20),
    "update_time"      text(30),
    "updater"          text(20),
    "is_delete"        text(5),
    "last_sms_time"    text(30),
    "daily_send_times" integer,
    CONSTRAINT "user_base_pkey" PRIMARY KEY ("id")
);

INSERT INTO user_base (id, "role", name, nick_name, gender, mobile, email, crt_time, push_token, password, update_time,
                       updater, is_delete)
VALUES (1, '1', 'demo', 'xiaoming', 'f', '', '995570953@qq.com', '2022-10-19 20:39:33.1471407', 'fsdf8787dfs', 'fae0b27c451c728867a567e8c1bb4e53',
        '2022-11-18 15:56:29.6270324', NULL, '0');


INSERT INTO remote_alarm (id, phone, email, "open", "alarm_time")
VALUES (1, '', '', 0, 0);
-- hour_constants

DROP TABLE IF EXISTS "hour_constants";
CREATE TABLE "hour_constants"
(
    "id"   INTEGER PRIMARY KEY AUTOINCREMENT,
    "time" text NOT NULL
);

INSERT INTO hour_constants (time)
VALUES ('00');
INSERT INTO hour_constants (time)
VALUES ('01');
INSERT INTO hour_constants (time)
VALUES ('02');
INSERT INTO hour_constants (time)
VALUES ('03');
INSERT INTO hour_constants (time)
VALUES ('04');
INSERT INTO hour_constants (time)
VALUES ('05');
INSERT INTO hour_constants (time)
VALUES ('06');
INSERT INTO hour_constants (time)
VALUES ('07');
INSERT INTO hour_constants (time)
VALUES ('08');
INSERT INTO hour_constants (time)
VALUES ('09');
INSERT INTO hour_constants (time)
VALUES ('10');
INSERT INTO hour_constants (time)
VALUES ('11');
INSERT INTO hour_constants (time)
VALUES ('12');
INSERT INTO hour_constants (time)
VALUES ('13');
INSERT INTO hour_constants (time)
VALUES ('14');
INSERT INTO hour_constants (time)
VALUES ('15');
INSERT INTO hour_constants (time)
VALUES ('16');
INSERT INTO hour_constants (time)
VALUES ('17');
INSERT INTO hour_constants (time)
VALUES ('18');
INSERT INTO hour_constants (time)
VALUES ('19');
INSERT INTO hour_constants (time)
VALUES ('20');
INSERT INTO hour_constants (time)
VALUES ('21');
INSERT INTO hour_constants (time)
VALUES ('22');
INSERT INTO hour_constants (time)
VALUES ('23');

VACUUM;
