package uploadcloud

import (
	"fmt"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/cloudPlatform"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	broker2 "go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"
)

func (ctrl *CloudTcpCli) ReportAgxMsg() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	_, _ = mq.AgxMsgBroker.Subscribe(mq.AgxTopic, func(event broker2.Event) error {
		comCli := &client.ClientReport{}
		err := proto.Unmarshal(event.Message().Body, comCli)
		if err != nil {
			logger.Error("agx heart Cli Unmarshal err:", err)
			return err
		}
		switch comCli.MsgType {
		case common.ClientMsgIdAgxHeartData:
			ctrl.ReportAgxHeart(comCli.Data)
		case common.ClientMsgIdAgxDetectData:
			ctrl.ReportAgxUav(comCli.Data)
		case common.ClientMsgIdAgxDevStatusData:
			ctrl.ReportAgxDev(comCli.Data)
		case common.ClientMsgIdAgxPTZStatusData:
			ctrl.ReportAgxPtzState(comCli.Data)
		case common.ClientMsgIdAgxTransferSflDetectMsg:
			ctrl.ReportAgxTransferSflDetectMsg(comCli.Data)
		case common.ClientMsgIdAgxTransferSflHeartMsg:
			ctrl.ReportAgxTransferSflHeartMsg(comCli.Data)
		}
		return nil
	})
}

func (c *CloudTcpCli) ReportAgxTransferSflHeartMsg(info []byte) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.SflHeartInfo{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		logger.Error("report sfl proto Unmarshal error: %v", err)
		return
	}
	logger.Debug("start Unmarshal")
	agxSn := hb.Header.Sn //AGX  SN号
	sflSn := hb.Data.Sn   //SFL  SN号)

	//给云端发送
	hbData := make([]*cloudPlatform.AgxTransferSflHeartData, 0)
	hbData = append(hbData, &cloudPlatform.AgxTransferSflHeartData{
		Sn:            agxSn,
		SflSn:         sflSn,
		CreateTime:    time.Now().UnixMilli(),
		WorkStatus:    hb.Data.WorkStatus,
		Online:        reverseOnline(hb.Data.IsOnline),
		DetectFreq:    hb.Data.DetectFreq,
		Elevation:     hb.Data.Elevation,
		GunDirection:  hb.Data.GunDirection,
		GunLongitude:  hb.Data.GunLongitude,
		GunLatitude:   hb.Data.GunLatitude,
		GunAltitude:   int32(hb.Data.GunAltitude),
		SatellitesNum: hb.Data.SatellitesNum,
		FaultLevel:    hb.Data.FaultLevel,
		CtrlFault:     hb.Data.CtrlFault,
		AeagFault:     hb.Data.AeagFault,
		TracerFault:   hb.Data.TracerFault,
	})
	logger.Debug("hbData = ", hbData)
	data := &cloudPlatform.AgxTransferSflHeartList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       AgxTransferSflHeartURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return
	}
	return
}

func (c *CloudTcpCli) ReportAgxTransferSflDetectMsg(info []byte) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	oriData := client.SflDetectInfo{}
	err := proto.Unmarshal(info, &oriData)
	if err != nil {
		logger.Error("Protobuf 解码失败:", err)
		return
	}

	umData := oriData.Data
	agxSn := oriData.Header.Sn //AGX  SN号
	sflSn := oriData.Data.Sn   //SFL  SN号
	droneList := umData.List
	//给云端发送侦测到的无人机小组
	dData := make([]*cloudPlatform.AgxTransferSflUavData, 0)
	for _, drone := range droneList {
		dData = append(dData, &cloudPlatform.AgxTransferSflUavData{
			Sn:                 agxSn,
			SflSn:              sflSn,
			ProductType:        drone.ProductType,
			DroneName:          drone.DroneName,
			SerialNum:          drone.SerialNum,
			DroneLongitude:     drone.DroneLongitude,
			DroneLatitude:      drone.DroneLatitude,
			DroneHeight:        drone.DroneHeight,
			DroneYawAngle:      drone.DroneYawAngle,
			DroneSpeed:         drone.DroneSpeed,
			DroneVerticalSpeed: drone.DroneVerticalSpeed,
			SpeedDirection:     drone.SpeedDirection,
			DroneSailLongitude: drone.DroneSailLongitude,
			DroneSailLatitude:  drone.DroneSailLatitude,
			PilotLongitude:     drone.PilotLongitude,
			PilotLatitude:      drone.PilotLatitude,
			DroneHorizon:       drone.DroneHorizon,
			DronePitch:         drone.DronePitch,
			UFreq:              drone.UFreq,
			UDistance:          drone.UDistance,
			UDangerLevels:      drone.UDangerLevels,
			Role:               drone.Role,
			DetectionNum:       umData.DetectionNum,
			CreateTime:         time.Now().UnixMilli(),
		})
	}
	Message := &cloudPlatform.AgxTransferSflUavList{
		Body: dData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(Message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       AgxTransferSflUavURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	logger.Debug("<----->message = ", message)
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	logger.Debug("encodedMessage = ->", encodedMessage)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return
	}

	_, err = c.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return
	}
	return
}
func (ctrl *CloudTcpCli) ReportAgxPtzState(data []byte) {
	agxPtz := &client.AgxPTZStateInfo{}
	err := proto.Unmarshal(data, agxPtz)
	if err != nil {
		logger.Error("agx Ptz Unmarshal err:", err)
		return
	}
	//给云端发送
	ptzData := make([]*cloudPlatform.AgxPtzStateData, 0)
	ptzData = append(ptzData, &cloudPlatform.AgxPtzStateData{
		Sn:           agxPtz.Header.Sn,
		TimeStamp:    agxPtz.Data.TimeStamp,
		PtzLongitude: agxPtz.Data.PtzLongitude,
		PtzLatitude:  agxPtz.Data.PtzLatitude,
		PtzHeight:    agxPtz.Data.PtzHeight,
		Azimuth:      agxPtz.Data.Azimuth,
		Elevation:    agxPtz.Data.Elevation,
		OmegaAz:      agxPtz.Data.OmegaAz,
		OmegaEl:      agxPtz.Data.OmegaEl,
		Zoom:         agxPtz.Data.Zoom,
		CreateTime:   time.Now().UnixMilli(),
	})
	logger.Debug("ptzData =", ptzData)
	ptzMessage := &cloudPlatform.AgxPtzStateList{
		Body: ptzData,
	}
	// encodedMessage
	encodedMessage, err := proto.Marshal(ptzMessage)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       AgxPTZState,
			Sn:        ctrl.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   ctrl.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if ctrl.Conn == nil || ctrl.IsLogin == false {
		return
	}
	_, err = ctrl.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return
	}
}

func (ctrl *CloudTcpCli) ReportAgxHeart(data []byte) {
	heart := &client.AgxHeartBeatInfo{}
	err := proto.Unmarshal(data, heart)
	if err != nil {
		logger.Error("agx heart Unmarshal err:", err)
		return
	}
	if heart.Data.IsOnline == 0 {
		heart.Data.IsOnline = 1
	} else if heart.Data.IsOnline == 1 {
		heart.Data.IsOnline = 2
	}
	//给云端发送
	heartData := make([]*cloudPlatform.AgxHeartData, 0)
	heartData = append(heartData, &cloudPlatform.AgxHeartData{
		Sn:          heart.Header.Sn,
		Online:      heart.Data.IsOnline,
		Electricity: heart.Data.Electricity,
		CreateTime:  time.Now().UnixMilli(),
	})
	logger.Debug("heartData =", heartData)
	heartMessage := &cloudPlatform.AgxHeartList{
		Body: heartData,
	}
	// encodedMessage
	encodedMessage, err := proto.Marshal(heartMessage)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       AgxHeartURL,
			Sn:        ctrl.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   ctrl.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if ctrl.Conn == nil || ctrl.IsLogin == false {
		return
	}
	_, err = ctrl.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return
	}
}

func (ctrl *CloudTcpCli) ReportAgxUav(data []byte) {
	uav := &client.AgxDetectInfo{}
	err := proto.Unmarshal(data, uav)
	if err != nil {
		logger.Error("agx Uav Unmarshal err:", err)

	}
	//给云端发送
	uavData := make([]*cloudPlatform.AgxUavData, 0)
	for _, uavInfo := range uav.Data {
		uavData = append(uavData, &cloudPlatform.AgxUavData{
			ObjId:        int32(uavInfo.ObjId),
			Sn:           uav.Header.Sn,
			X:            uavInfo.X,
			Y:            uavInfo.Y,
			Z:            uavInfo.Z,
			Velocity:     uavInfo.Velocity,
			Azimuth:      uavInfo.Azimuth,
			Alive:        int32(uavInfo.Alive),
			ExistingProb: float64(uavInfo.ExistingProb),
			StateType:    uavInfo.StateType,
			CreateTime:   time.Now().UnixMilli(),
			PtzLock:      uavInfo.AssocBit1,
		})
	}

	logger.Debug("uavData =", uavData)
	uavMessage := &cloudPlatform.AgxUavList{
		Body: uavData,
	}
	// encodedMessage
	encodedMessage, err := proto.Marshal(uavMessage)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       AgxUavURL,
			Sn:        ctrl.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   ctrl.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if ctrl.Conn == nil || ctrl.IsLogin == false {
		return
	}
	_, err = ctrl.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return
	}
}

func (ctrl *CloudTcpCli) ReportAgxDev(data []byte) {
	dev := &client.AgxDevStateInfo{}
	err := proto.Unmarshal(data, dev)
	if err != nil {
		logger.Error("agx Dev Unmarshal err:", err)
		return
	}
	//给云端发送
	devList := make([]*cloudPlatform.AgxDevSn, 0)
	for _, devInfo := range dev.Data.List {
		devList = append(devList, &cloudPlatform.AgxDevSn{
			DevType: devInfo.DevType,
			DevSn:   devInfo.DevSn,
		})
	}
	devData := make([]*cloudPlatform.AgxDevData, 0)
	devData = append(devData, &cloudPlatform.AgxDevData{
		Sn:         dev.Header.Sn,
		List:       devList,
		CreateTime: time.Now().UnixMilli(),
	})
	logger.Debug("DevData =", devData)
	uavMessage := &cloudPlatform.AgxDevList{
		Body: devData,
	}
	// encodedMessage
	encodedMessage, err := proto.Marshal(uavMessage)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       AgxDevListURL,
			Sn:        ctrl.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   ctrl.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if ctrl.Conn == nil || ctrl.IsLogin == false {
		return
	}
	_, err = ctrl.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return
	}
}
