package uploadcloud

import (
	"fmt"
	"strings"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/cloudPlatform"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	jsoniter "github.com/json-iterator/go"
	broker2 "go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"
)

var (
	//GRfIsOffline 全局变量，用于表示RF设备是否在线，RF设备相对于其他设备
	//通过消息队列发送的心跳中少了是否在线的字段，需要额外做特殊处理
	//等后面设备接入端有上报该字段的时候，这部分代码就可以去掉了
	GRfIsOffline = false
)

// var droneModel = map[string]string{"dragonfish lite": "Autel lite", "dragonfish pro ": "Autel lite"}
// Autel lite
const (
	aushow    = "Autel lite"
	djshow    = "DJI"
	othershow = "Drone"
)

var autelLite = []string{
	"dragonfish lite",
	"dragonfish pro",
	"dragonfish standard",
	"evo ii",
	"evo lite/lite+",
	"evo max",
	"evo nano",
	"evo ii v2",
	"evo ii 行业版v3",
	"evo ii dual 640t v3",
	"evo ii rtk系列v3",
	"evo ii pro v3",
	"evo ii 行业版v2",
	"evo ii dual 640t v2",
	"evo ii rtk系列v2",
	"evo ii pro v2",
	"evo ii v3",
	"evoⅱ v3（抗干扰版）",
	"max 4t",
	"max 4t（防务版）",
}

// DJI ..
var DJI = []string{
	"agras t30",
	"agras t40",
	"avata",
	"inspire 3",
	"m30",
	"m30 dock version",
	"matrice 200 v2",
	"matrice 200",
	"matrice 600 pro",
	"matrice 600",
	"matrice 100",
	"m300 rtk",
	"m30t",
	"matrice 350 rtk",
	"m3e",
	"m3m",
	"m3t",
	"air 2s",
	"air 3",
	"dji fpv",
	"inspire 1",
	"inspire 2",
	"mavic 2",
	"inspire 1 raw",
	"inspire 1 pro",
	"mavic 2 ent",
	"mavic 2 ent adv",
	"mavic 3",
	"mavic 3 classic",
	"mavic 3 pro",
	"mavic 3e",
	"mavic air",
	"mavic air2",
	"mavic mini",
	"mavic pro",
	"mavic pro铂金版",
	"mavic 3 多光谱版",
	"mini 2",
	"mini 3 pro",
	"phantom 3",
	"phantom 3 4k",
	"phantom 3 pro",
	"phantom 3 se",
	"phantom 3 std",
	"phantom 4",
	"phantom 3 adv",
	"phantom 4 adv",
	"phantom 4 pro",
	"phantom 4 pro v2.0",
	"phantom 4 rtk",
	"phantom 2 vsion+",
	"phantom 2 vsion",
	"phantom 4fc40",
	"phantom",
	"phantom 4 series",
	"spark",
	"phantom4 v2",
	"air 2",
	"mini 4 pro",
	"mini 3",
	"mini 2 se",
	"mini se",
	"inspire 3",
	"mg-1s advanced",
	"mg-1s",
	"mg-1p/rtk",
	"mg-1",
	"mg-1s rtk",
	"t-50",
	"t-25",
	"t-40",
	"t-20",
	"t-16",
	"phantom 4 多光谱版",
	"t-10",
	"t-30",
	"t-20p",
	"flycart 30",
	"tello",
}

// ReportTracerRF360DeviceStatusH 数据上报  -> handler 层
func (c *CloudTcpCli) ReportTracerRF360DeviceStatusH() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	_, _ = mq.RFURDBroker.Subscribe(mq.RFURD360StatusTopic, func(event broker2.Event) error {
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		logger.Debug("event.Message().Body = ", event.Message().Body)
		if err != nil {
			return fmt.Errorf("report Radar Posture Unmarshal error: %v", err)
		}
		infoJSON, _ := jsoniter.Marshal(entity.MsgType)
		var MsgType int
		logger.Debug("start Unmarshal")
		err = jsoniter.Unmarshal(infoJSON, &MsgType)
		if err != nil {
			if EnableLogInvildJSON {
				logger.Debug("report   Unmarshal info error: %v", err)
			}
			return fmt.Errorf("report   Unmarshal info error: %v", err)
		}
		sn := entity.Sn
		info := entity.Info
		ip := entity.Name

		return c.TracerRFurd360DeviceStatus(sn, info, ip)

	})
}

// ReportTracerRF360DroneInfoH 数据上报  -> handler 层
func (c *CloudTcpCli) ReportTracerRF360DroneInfoH() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	_, _ = mq.RFURDBroker.Subscribe(mq.RFURD360DroneInfoTopic, func(event broker2.Event) error {
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		logger.Debug("event.Message().Body = ", event.Message().Body)
		if err != nil {
			return fmt.Errorf("report Radar Posture Unmarshal error: %v", err)
		}
		infoJSON, _ := jsoniter.Marshal(entity.MsgType)
		var MsgType int
		logger.Debug("start Unmarshal")
		err = jsoniter.Unmarshal(infoJSON, &MsgType)
		if err != nil {
			if EnableLogInvildJSON {
				logger.Debug("report   Unmarshal info error: %v", err)
			}
			return fmt.Errorf("report  Unmarshal info error: %v", err)
		}
		sn := entity.Sn
		info := entity.Info

		return c.ReportTracerRF360DroneInfo(sn, info)

	})
}

// ReportTracerRF360UrdSpectrumH 数据上报  -> handler 层
func (c *CloudTcpCli) ReportTracerRF360UrdSpectrumH() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	_, _ = mq.RFURDBroker.Subscribe(mq.RFURD360SpecturmTopic, func(event broker2.Event) error {
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		logger.Debug("event.Message().Body = ", event.Message().Body)
		if err != nil {
			return fmt.Errorf("report Radar Posture Unmarshal error: %v", err)
		}
		infoJSON, _ := jsoniter.Marshal(entity.MsgType)
		var MsgType int
		logger.Debug("start Unmarshal")
		err = jsoniter.Unmarshal(infoJSON, &MsgType)
		if err != nil {
			if EnableLogInvildJSON {
				logger.Debug("report  Unmarshal info error: %v", err)
			}
			return fmt.Errorf("report    Unmarshal info error: %v", err)
		}
		sn := entity.Sn
		info := entity.Info

		return c.ReportTracerRF360UrdSpectrum(sn, info)

	})
}

// TracerRFurd360DeviceStatus 上报设备信息 -> logic
func (c *CloudTcpCli) TracerRFurd360DeviceStatus(sn string, info interface{}, ip string) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	infoJSON, _ := jsoniter.Marshal(info)
	hb := handler.UrdDeviceInfoUpload{}
	logger.Debug("start Unmarshal")
	err := jsoniter.Unmarshal(infoJSON, &hb)
	if err != nil {
		if EnableLogInvildJSON {
			logger.Debug("report  Unmarshal info error: %v", err)
		}
		return fmt.Errorf("report   Unmarshal info error: %v", err)
	}

	//给云端发送
	hbData := make([]*cloudPlatform.TracerRfHeartData, 0)
	// logger.Debug("hb.name = ", hb.Name)
	// logger.Debug("len (hb.Name) = ", len(hb.Name))
	hbName := strings.TrimRight(hb.Name, "\x00")
	logger.Debug("hbName = ", hbName)
	hbData = append(hbData, &cloudPlatform.TracerRfHeartData{
		Sn:                sn,
		Name:              hbName,
		Longitude:         hb.Longitude,
		Latitude:          hb.Latitude,
		Height:            hb.Height,
		Status:            int32(hb.Status),
		Azimuth:           float64(hb.Azimuth),
		Type:              hb.Type,
		CompassStatus:     int32(hb.CompassStatus),
		GpsStatus:         int32(hb.GpsStatus),
		ReceiverStatus:    int32(hb.ReceiverStatus),
		AntennaStatus:     int32(hb.AntennaStatus),
		AntennaCoverRange: hb.AntennaCoverRange,
		CreateTime:        time.Now().UnixMilli(),
		Ip:                ip,
	})

	logger.Debug("hbData = ", hbData)
	data := &cloudPlatform.TracerRfHeartList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       TracerRFurdStatusURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	return nil
}

func processTarget(target string) string {
	lowertarget := strings.ToLower(target)
	ok := strings.Contains(lowertarget, strings.ToLower("autel"))
	if ok {
		return aushow
	}
	ok = strings.Contains(lowertarget, strings.ToLower("dji"))
	if ok {
		return djshow
	}
	targetList := strings.Split(lowertarget, "/")
	intersectionAutel := 0
	intersectionDji := 0
	for _, t := range autelLite {
		for _, ta := range targetList {
			if t == ta {
				intersectionAutel++
			}
		}
	}
	for _, t := range DJI {
		for _, ta := range targetList {
			if t == ta {
				intersectionDji++
			}
		}
	}
	if intersectionAutel != 0 && intersectionDji != 0 {
		if intersectionAutel >= intersectionDji {
			return aushow
		}
		return othershow
	}
	if intersectionAutel != 0 {
		return aushow
	}
	if intersectionDji != 0 {
		return djshow
	}

	return othershow

}

// ReportTracerRF360DroneInfo 车载TracerRFurd360  频谱侦测无人机信息
func (c *CloudTcpCli) ReportTracerRF360DroneInfo(sn string, info interface{}) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	infoJSON, _ := jsoniter.Marshal(info)
	report := handler.UrdDroneInfoUpload{}
	logger.Debug("start Unmarshal")
	err := jsoniter.Unmarshal(infoJSON, &report)
	if err != nil {
		if EnableLogInvildJSON {
			logger.Debug("  Unmarshal info error: %v", err)
		}
		return fmt.Errorf(" Unmarshal info error: %v", err)
	}

	logger.Debug("report.UniqueId = %s", report.UniqueId)
	logger.Debug("len(report.UniqueId ) = ", len(report.UniqueId))
	UniqueID := strings.TrimRight(report.UniqueId, "\x00")

	logger.Debug("report.TargetInfo = ", report.TargetInfo)
	logger.Debug("len(report.TargetInfo) = ", len(report.TargetInfo))
	// TargetInfoTrim := strings.TrimRight(report.TargetInfo, "\x00")
	TargetInfoTrim := strings.ReplaceAll(report.TargetInfo, "\x00", "")
	TargetInfo := processTarget(TargetInfoTrim)
	logger.Debug("TargetInfo = ", TargetInfo)
	//给云端发送侦测到的无人机小组
	dData := make([]*cloudPlatform.TracerRfData, 0)
	dData = append(dData, &cloudPlatform.TracerRfData{
		Sn:               sn,
		UniqueId:         UniqueID,
		TargetInfoLength: report.TargetInfoLength,
		TargetInfo:       TargetInfo,
		StationId:        report.StationId,
		TargetAzimuth:    report.TargetAzimuth,
		TargetRange:      report.TargetRange,
		Latitude:         report.Latitude,
		Height:           report.Height,
		Frequency:        report.Frequency,
		Bandwidth:        report.Bandwidth,
		SignalStrength:   report.SignalStrength,
		Trust:            int32(report.Trust),
		Time:             report.Time,
		DataType:         int32(report.DataType),
		Modulation:       int32(report.Modulation),
		DroneId:          report.Id,
	})

	Message := &cloudPlatform.TracerRfUavList{
		Body: dData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(Message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       TracerRFurdUavURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	return nil
}

// ReportTracerRF360UrdSpectrum 频谱
func (c *CloudTcpCli) ReportTracerRF360UrdSpectrum(sn string, info interface{}) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	infoJSON, _ := jsoniter.Marshal(info)
	report := handler.UrdSpectrumReport{}
	logger.Debug("start Unmarshal")
	err := jsoniter.Unmarshal(infoJSON, &report)
	if err != nil {
		if EnableLogInvildJSON {
			logger.Debug("  Unmarshal info error: %v", err)
		}
		return fmt.Errorf(" Unmarshal info error: %v", err)
	}
	RX := report.X
	RY := report.Y
	util := cloudPlatform.UrdSpectrum{
		X: RX,
		Y: RY,
	}
	dData := make([]*cloudPlatform.TracerRfPostureData, 0)
	dData = append(dData, &cloudPlatform.TracerRfPostureData{
		Sn:         sn,
		Util:       &util,
		CreateTime: time.Now().UnixMilli(),
	})

	Message := &cloudPlatform.TracerRfPostureList{
		Body: dData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(Message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       TracerRFurdspuctrumURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	return nil
}
