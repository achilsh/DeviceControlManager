package udp

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"net"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/entity/config"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

type Adaptor struct {
	host string
	conn *net.UDPConn
}

// 发送udp包通用字段定义
const (
	startBits   uint32 = 0x8A808988
	protocolVer uint32 = 9002
	stopFlag    uint32 = 0x8B8A8089
	sunCode     uint32 = 0x01
	reserved    uint32 = 0x00
	extraLength uint32 = 20
)

// Zoom 会使用到系统编号
const (
	sysCode uint32 = 0x0
)

// 自增序列号
var (
	sequence uint32 = 0
	mutex    sync.Mutex
)

func incrementSeq() uint32 {
	mutex.Lock()
	defer mutex.Unlock()
	sequence++
	return sequence
}

func timestamp() uint64 {
	return uint64(time.Now().Unix())
}

// NewUDPHandler UDP handler
func NewUDPHandler() *Adaptor {
	a := new(Adaptor)
	var serverAddr string
	logger.Debug("config.GetGlobalConfig().AgxPTZConfig = ", config.GetGlobalConfig().AgxPTZ)
	if config.GetGlobalConfig().AgxPTZ != nil && len(config.GetGlobalConfig().AgxPTZ.UDPURL) != 0 {
		logger.Debug("config.GetGlobalConfig().AgxPTZConfig.UDPURL = ", config.GetGlobalConfig().AgxPTZ.UDPURL)
		serverAddr = config.GetGlobalConfig().AgxPTZ.UDPURL
	} else {
		serverAddr = "192.168.1.4:9966" //default configuration
	}

	udpAddr, err := net.ResolveUDPAddr("udp", serverAddr)
	if err != nil {
		logger.Debug("解析服务器地址出错：", err)
		serverAddr = "192.168.1.4:9966"
	}
	a.host = serverAddr
	// 建立UDP连接
	conn, err := net.DialUDP("udp", nil, udpAddr)
	if err != nil {
		logger.Debug("建立UDP连接出错：", err)
	}
	logger.Debugf("UDP connect successful,host = %s", a.host)
	// defer conn.Close()
	a.conn = conn
	return a
}

func (a *Adaptor) sendPkg(payload []byte, len uint32, sum uint64, cmd uint32) {
	logger.Debug("len = ", len)
	logger.Debug("cmd = ", cmd)
	buf := new(bytes.Buffer)
	pkgLen := len + extraLength
	binary.Write(buf, binary.LittleEndian, startBits)
	binary.Write(buf, binary.LittleEndian, protocolVer)
	binary.Write(buf, binary.LittleEndian, pkgLen)
	binary.Write(buf, binary.LittleEndian, cmd)
	binary.Write(buf, binary.LittleEndian, timestamp())
	buf.Write(payload)
	sequence++
	binary.Write(buf, binary.LittleEndian, incrementSeq())
	// checksum := uint32(uint64(packetLength+command+sequence+msgCode+msgCmd+msgLevel+msgType+msgResver)+msgTimeStamp+timestamp) & 0xFFFFFFFF
	checksum := uint32(sum + uint64(pkgLen))
	binary.Write(buf, binary.LittleEndian, checksum)
	binary.Write(buf, binary.LittleEndian, stopFlag)
	// return buf.Bytes()
	bufByte := buf.Bytes()
	logger.Debug("pkgLen = ", pkgLen)
	for _, v := range bufByte {
		fmt.Printf("%02x ", v)
	}
	_, err := a.conn.Write(bufByte)
	if err != nil {
		logger.Debug("发送数据出错：", err)
	}
}

// DoDirectionlSet  方向设置
func (a *Adaptor) DoDirectionlSet(pkgCmd, ChildCmd, speed, movement uint32) {
	logger.Debug("pkgCmd  = ", pkgCmd)
	logger.Debug("child = ", ChildCmd)
	logger.Debug("speed = ", speed)
	logger.Debug("movement = ", movement)
	len := 28
	payload := make([]byte, len)
	ts := timestamp()
	binary.LittleEndian.PutUint32(payload[0:4], sunCode)
	binary.LittleEndian.PutUint64(payload[4:12], ts)
	binary.LittleEndian.PutUint32(payload[12:16], ChildCmd)
	binary.LittleEndian.PutUint32(payload[16:20], speed)
	binary.LittleEndian.PutUint32(payload[20:24], movement)
	binary.LittleEndian.PutUint32(payload[24:28], reserved)
	sum := uint64(sunCode+ChildCmd+speed+movement+reserved) + ts
	a.sendPkg(payload, uint32(len), sum, pkgCmd)
}

// DoZoomSet  放大缩小等设置(Zoom)
func (a *Adaptor) DoZoomSet(pkgCmd, ChildCmd, focus, zoomsite, focusSite uint32) {
	logger.Debug("pkgCmd = ", pkgCmd)
	logger.Debug("ChildCmd  = ", ChildCmd)
	logger.Debug("focus = ", focus)
	logger.Debug("zoomsite = ", zoomsite)
	logger.Debug("focusSite = ", focusSite)
	len := 36
	payload := make([]byte, len)
	ts := timestamp()
	binary.LittleEndian.PutUint32(payload[0:4], sunCode)

	binary.LittleEndian.PutUint32(payload[4:8], sysCode)
	binary.LittleEndian.PutUint64(payload[8:16], ts)
	binary.LittleEndian.PutUint32(payload[16:20], ChildCmd)
	binary.LittleEndian.PutUint32(payload[20:24], focus)
	binary.LittleEndian.PutUint32(payload[24:28], zoomsite)
	binary.LittleEndian.PutUint32(payload[28:32], focusSite)
	binary.LittleEndian.PutUint32(payload[32:36], reserved)
	sum := uint64(sunCode+sysCode+ChildCmd+focus+zoomsite+focusSite+reserved) + ts

	a.sendPkg(payload, uint32(len), sum, pkgCmd)
}
