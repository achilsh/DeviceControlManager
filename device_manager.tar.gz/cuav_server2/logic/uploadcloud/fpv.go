package uploadcloud

import (
	"fmt"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/cloudPlatform"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	broker2 "go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"
)

// ReportFpv 数据上报
func (c *CloudTcpCli) ReportFpv() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	_, _ = mq.FpvMsgBroker.Subscribe(mq.FpvTopic, func(event broker2.Event) error {
		// entity := common.EquipmentMessageBoxEntity{}
		entity := client.ClientReport{}
		err := proto.Unmarshal(event.Message().Body, &entity)
		logger.Debug("event.Message().Body = ", event.Message().Body)
		if err != nil {
			return fmt.Errorf("report Radar Posture Unmarshal error: %v", err)
		}

		MsgType := entity.MsgType
		data := entity.Data
		switch MsgType {
		case common.ClientMsgIDFPVHeartBeat:
			return c.ReportFpvHeartBeat(data)
		case common.ClientMsgIDFPVFreq:
			return c.ReportFpvFreqDetectDescription(data)
		default:
			err := fmt.Errorf("unrecognized msg type: %v", MsgType)
			logger.Error(err)
			return err
		}
	})
}

// ReportFpvHeartBeat 上报车载fpv心跳
func (c *CloudTcpCli) ReportFpvHeartBeat(data []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	hb := client.FpvHeartInfo{}
	err := proto.Unmarshal(data, &hb)
	if err != nil {
		return fmt.Errorf("report fpv proto Unmarshal error: %v", err)
	}
	// hb.Sn = sn
	// mu.Lock()
	// defer mu.Unlock()

	//给云端发送
	hbData := make([]*cloudPlatform.FpvHeartData, 0)
	hbData = append(hbData, &cloudPlatform.FpvHeartData{
		Sn:            hb.Header.Sn,
		Online:        hb.Data.IsOnline,
		Electricity:   hb.Data.Electricity,
		CreateTime:    int64(hb.Data.TimeStamp),
		BatteryStatus: hb.Data.BatteryStatus,
		WorkMode:      hb.Data.WorkMode,
		WorkStatus:    hb.Data.WorkStatus,
		Fault:         0,
		AlarmLevel:    hb.Data.AlarmLevel,
		Buzzer:        0,
		Vibration:     0,
		StealthMode:   0,
	})
	logger.Debug("hb.Sn, = ", hb.Header.Sn)
	logger.Debug("hbData = ", hbData)

	sendData := &cloudPlatform.FpvHeartList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(sendData)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       FpvHeartURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	return nil
}

// ReportFpvFreqDetectDescription 车载fpv 频谱侦测无人机信息
func (c *CloudTcpCli) ReportFpvFreqDetectDescription(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	// infoJSON, _ := jsoniter.Marshal(info)
	// report := mavlink.FpvFreqDetectReport{}
	// logger.Debug("start Unmarshal")
	// err := jsoniter.Unmarshal(infoJSON, &report)
	// if err != nil {
	// 	if EnableLogInvildJSON {
	// 		logger.Debug("  Unmarshal info error: %v", err)
	// 	}
	// 	return fmt.Errorf(" Unmarshal info error: %v", err)
	// }

	// tmp, _ := jsoniter.Marshal(report.Description)
	// desc := mavlink.FpvFreqDetectDescriptionReport{}
	// err = jsoniter.Unmarshal(tmp, &desc)
	// if err != nil {
	// 	if EnableLogInvildJSON {
	// 		logger.Debug("  Unmarshal info error: %v", err)
	// 	}
	// 	return fmt.Errorf(" Unmarshal info error: %v", err)
	// }
	report := &client.FpvDetectInfo{}
	err := proto.Unmarshal(info, report)
	if err != nil {
		return fmt.Errorf("report fpv proto Unmarshal error: %v", err)
	}
	drone := report.Data.List
	//给云端发送侦测到的无人机小组
	dData := make([]*cloudPlatform.FpvUavData, 0)
	for _, v := range drone {
		dData = append(dData, &cloudPlatform.FpvUavData{
			Sn:            report.Header.Sn,
			QxPower:       report.Data.QxPower,
			DxPower:       report.Data.DxPower,
			DxHorizon:     report.Data.DxHorizon,
			UavNumber:     v.UavNumber,
			DroneName:     v.DroneName,
			DroneHorizon:  v.DroneHorizon,
			UFreq:         v.UFreq,
			UDangerLevels: int32(v.UDangerLevels),
			CreateTime:    time.Now().UnixMilli(),
		})
	}

	Message := &cloudPlatform.FpvUavList{
		Body: dData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(Message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       FpvUavURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	return nil
}
