package uploadcloud

import (
	"errors"
	"fmt"
	"strconv"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/golang/protobuf/proto"
	broker2 "go-micro.dev/v4/broker"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	videostore "adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/videoStore"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/cloudPlatform"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

// radar
// DroneID
// Fpv
// Sfl
// Spoofer
// tracerRF
// Agx,
// RF
const (
	StrDeviceTypeSFL      = "Sfl"
	StrDeviceTypeDroneID  = "DroneID"
	StrDeviceTypeFpv      = "Fpv"
	StrDeviceTypeSpooofer = "Spoofer"
	StrDeviceTypeTracerRF = "tracerRF"
	StrDeviceTypeAgx      = "Agx"
	StrDeviceTypeRF       = "RF"
)

// 1: 设备状态事件; subEventType: 10: 上线， 11 离线
// 2: 侦测状态事件; subEventType: 100: 出现无人机; 101： 无人机消息； 102： 通知视频流跟踪
// 3. 打击状态事件; 200: 成功， 201： 打击失败
// 4. ptz打击事件; 300: 成功， 301： 失败
const (
	EnumEventDeviceStatus = iota + 1
	EnumEventDetect       = 2
	EnumEventHit          = 3
	EnumEventPtzLock      = 4
)
const (
	EnumSubEventDeviceOnLine  = 10
	EnumSubEventDeviceOffLine = 11
	//
	EnumSubEventDetectAppear    = 100
	EnumSubEventDetectDisAppear = 101
	EnumSubEventPushVideoDone   = 102
	//
	EnumSubEventHitSucc = 200
	EnumSubEventHitFail = 201
	//
	EnumSubEventPtzLockSucc = 300
	EnumSubEventPtzLockFail = 301
)

func TracerLonLat() (lon, lat float32, err error) {
	cfg, exist := handler.C2Config.Get("c2config")
	if exist == false {
		return 0.0, 0.0, nil
	}
	return float32(cfg.Longitude), float32(cfg.Latitude), nil
}
func (c *CloudTcpCli) ReportTracerStatusEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.DroneStatusInfo{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		return fmt.Errorf("report sfl proto Unmarshal error: %v", err)
	}
	// hb := mavlink.SflHeartReport{}
	logger.Debug("start Unmarshal TracerStatusEvent")

	EventType, SubEventType := int32(EnumEventDeviceStatus), int32(EnumSubEventDeviceOnLine)
	EventId := hb.Data.GetEventId()

	lon, lat, e := TracerLonLat()
	if e != nil {
		logger.Errorf("get tracer lon, lat fail, sn: %v, e: %v", hb.Header.Sn, e)
	}

	var bodyData []byte
	if hb.Header.MsgType == mavlink.TracerEventOnLine {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOnLine

		logger.Infof("receive tracer online event.")

		bodyDataPtr := &cloudPlatform.DeviceOnLineDesc{
			Longitude: lon,
			Latitude:  lat,
		}
		//
		bodyDataBin, err := proto.Marshal(bodyDataPtr)
		if err == nil {
			bodyData = bodyDataBin
		}

	} else if hb.Header.MsgType == mavlink.TracerEventOffLine {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOffLine

		logger.Infof("receive tracer offline event.")

	} else {
		return nil
	}

	//给云端发送
	hbData := make([]*cloudPlatform.ReportEventData, 0)
	hbData = append(hbData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           hb.Header.Sn,
		DevType:      StrDeviceTypeDroneID,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("hbData = ", hbData)
	data := &cloudPlatform.ReportEventList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	logger.Infof("send tracer event report to cloud succ, msg: %v", message)
	return nil
}
func (c *CloudTcpCli) ReportTracerDetectEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	detect := &client.TracerDetectInfo{}
	err := proto.Unmarshal(info, detect)
	if err != nil {
		return fmt.Errorf("report tracer proto Unmarshal error: %v", err)
	}

	logger.Debug("start detect Unmarshal")

	EventType, SubEventType := int32(EnumEventDetect), int32(EnumSubEventDetectAppear)
	var bodyData []byte

	if detect.Header.MsgType == mavlink.TracerEventDetectAppear {
		if detect.Data == nil {
			logger.Errorf("detect uav is empty")
			return errors.New("detect uav is empty")
		}

		bodyDataPtr := &cloudPlatform.DetectUavDesc{}
		for _, v := range detect.GetData().GetInfo() {
			uav := &cloudPlatform.EventDetectUav{
				ProductType: v.ProductType,
				Name:        v.DroneName,
				SerialNum:   v.SerialNum,
				Longitude:   float32(v.DroneLongitude),
				Latitude:    float32(v.DroneLatitude),
				Role:        v.Role,
			}
			bodyDataPtr.Body = append(bodyDataPtr.Body, uav)
		}

		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectAppear

		bodyDataBin, err := proto.Marshal(bodyDataPtr)
		if err == nil {
			bodyData = bodyDataBin
		} else {
			logger.Errorf("marshal detect fail, e: %v", err)
			return errors.New("marshal fail")
		}
		logger.Infof("receive detect uav event report")
	} else if detect.Header.MsgType == mavlink.TracerEventDetectDisappear {
		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectDisAppear

		logger.Infof("receive tracer detect disappear event.")
	} else {
		logger.Infof("not support msgType: %v", detect.Header.MsgType)
	}
	EventId := detect.GetData().GetEventId()

	//给云端发送
	detectUav := make([]*cloudPlatform.ReportEventData, 0)
	detectUav = append(detectUav, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           detect.Header.Sn,
		DevType:      StrDeviceTypeDroneID,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("detectData = ", detectUav)
	data := &cloudPlatform.ReportEventList{
		Body: detectUav,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	//
	logger.Infof("report detect event to cloud success, %v", message)
	return nil
}

func (c *CloudTcpCli) EventReport() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	_, _ = mq.EventReportBroker.Subscribe(mq.EventReportTopic, func(event broker2.Event) error {
		entity := client.ClientReport{}
		err := proto.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("report sfl proto Unmarshal error: %v", err)
		}
		MsgType := entity.MsgType
		info := entity.Data
		switch MsgType {
		case common.ClientMsgTracerStatusEventData:
			return c.ReportTracerStatusEvent(info)
		case common.ClientMsgTracerDetectEventData:
			return c.ReportTracerDetectEvent(info)

		case common.ClientMsgSFlStatusEventData:
			return c.ReportSflStatusEvent(info)
		case common.ClientMsgSFlDetectEventData:
			return c.ReportSflDetectEvent(info)
		case common.ClientMsgSflHitEventData:
			return c.ReportSflHitStatusEvent(info)

		case common.ClientMsgAgxStatusEventData:
			return c.ReportAgxStatusEvent(info)
		case common.ClientMsgAgxDetectEventData:
			return c.ReportAgxDetectEvent(info)
		case common.ClientMsgAgzPtzLockEventData:
			return c.ReportAgxPtzLockUavEvent(info)

		default:
			err := fmt.Errorf("unrecognized msg type: %v", MsgType)
			logger.Error(err)
			return err
		}
	})
}
func (c *CloudTcpCli) ReportSflHitStatusEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hitStatus := &client.SflHitStateInfo{}
	err := proto.Unmarshal(info, hitStatus)
	if err != nil {
		return fmt.Errorf("report sfl proto Unmarshal error: %v", err)
	}
	logger.Debugf("start Unmarshal, SFL hit state: %v", hitStatus)

	sflHitStatusEventItems := []*cloudPlatform.SflHitStatusEventItem{}
	sflHitStatusEventItems = append(sflHitStatusEventItems, &cloudPlatform.SflHitStatusEventItem{
		SerialNum:      hitStatus.Data.SerialNum,
		DroneName:      hitStatus.Data.DroneName,
		DroneLongitude: hitStatus.Data.DroneLongitude,
		DroneLatitude:  hitStatus.Data.DroneLatitude,
		DroneHeight:    hitStatus.Data.DroneHeight,
		DroneYawAngle:  hitStatus.Data.DroneYawAngle,
	})

	sflHitStatusEventDesc := &cloudPlatform.SflHitStatusEventDesc{
		Body: sflHitStatusEventItems,
	}
	bodyData, err := proto.Marshal(sflHitStatusEventDesc)
	if err != nil {
		logger.Errorf("marsh hit  status data fail, e: %v", err)
	}

	EventType, SubEventType := int32(EnumEventHit), int32(EnumSubEventHitSucc)
	EventId := hitStatus.Data.GetEventId()
	if hitStatus.Header.MsgType == mavlink.SflEventHitSucc {

		EventType = int32(EnumEventHit)
		SubEventType = EnumSubEventHitSucc

		logger.Infof("receive sfl hit succ event.")

	} else if hitStatus.Header.MsgType == mavlink.SflEventHitFail {
		EventType = int32(EnumEventHit)
		SubEventType = EnumSubEventHitFail
		logger.Infof("receive sfl hit uav fail event.")
	}

	//给云端发送
	hitStatusCloudData := make([]*cloudPlatform.ReportEventData, 0)
	hitStatusCloudData = append(hitStatusCloudData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           hitStatus.Header.Sn,
		DevType:      StrDeviceTypeSFL,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("hit status = ", hitStatusCloudData)
	data := &cloudPlatform.ReportEventList{
		Body: hitStatusCloudData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	logger.Infof("send sfl hit status event to cloud success, data: %v", data)
	return nil
}
func (c *CloudTcpCli) ReportSflDetectEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	detect := &client.SflDetectInfo{}
	err := proto.Unmarshal(info, detect)
	if err != nil {
		return fmt.Errorf("report sfl proto Unmarshal error: %v", err)
	}
	logger.Debugf("start Unmarshal, data: %v", detect.Data)

	var bodyData []byte
	if detect.Header.MsgType == mavlink.SflEventDetectAppear {
		if detect.Data == nil || len(detect.Data.List) <= 0 {
			logger.Infof("has not any uav detect")
			return nil
		}

		var uavDetect []*cloudPlatform.EventDetectUav
		var dataDetect *cloudPlatform.DetectUavDesc
		var err error
		for _, v := range detect.Data.List {
			uavDetect = append(uavDetect, &cloudPlatform.EventDetectUav{
				ProductType: v.ProductType,
				Name:        v.DroneName,
				SerialNum:   v.SerialNum,
				Longitude:   float32(v.DroneLongitude),
				Latitude:    float32(v.DroneLatitude),
				Role:        v.Role,
			})
		}

		dataDetect = &cloudPlatform.DetectUavDesc{
			Body: uavDetect,
		}

		bodyData, err = proto.Marshal(dataDetect)
		if err != nil {
			logger.Errorf("marsh detect uav fail, e: %v", err)
			return nil
		}
		logger.Infof("sfl detect uas: %v", uavDetect)
	}

	EventType, SubEventType := int32(EnumEventDetect), int32(EnumSubEventDetectAppear)
	EventId := detect.Data.GetEventId()
	if detect.Header.MsgType == mavlink.SflEventDetectAppear {

		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectAppear

		logger.Infof("receive sfl detect uav appear event.")

	} else if detect.Header.MsgType == mavlink.SflEventDetectDisappear {
		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectDisAppear
		logger.Infof("receive sfl detect uav disappear event.")
	}

	//给云端发送
	detectData := make([]*cloudPlatform.ReportEventData, 0)
	detectData = append(detectData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           detect.Header.Sn,
		DevType:      StrDeviceTypeSFL,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("detect = ", detectData)
	data := &cloudPlatform.ReportEventList{
		Body: detectData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	logger.Infof("send sfl detect event to cloud success, data: %v", data)
	return nil
}

func (c *CloudTcpCli) ReportSflStatusEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.SflHeartInfo{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		return fmt.Errorf("report sfl proto Unmarshal error: %v", err)
	}
	logger.Debug("start Unmarshal SflStatus")

	EventType, SubEventType := int32(EnumEventDeviceStatus), int32(EnumSubEventDeviceOnLine)
	EventId := hb.Data.GetEventId()

	var bodyData []byte
	if hb.Header.MsgType == mavlink.SflEventMsgOnline {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOnLine

		bodyDataPtr := &cloudPlatform.DeviceOnLineDesc{
			Longitude: float32(hb.Data.GunLongitude),
			Latitude:  float32(hb.Data.GunLatitude),
		}
		//
		bodyDataBin, err := proto.Marshal(bodyDataPtr)
		if err == nil {
			bodyData = bodyDataBin
		}

		logger.Infof("receive sfl online event, data: %v", bodyDataPtr)

	} else if hb.Header.MsgType == mavlink.SflEventMsgOffLine {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOffLine

		logger.Infof("receive sfl offline event.")

	} else {
		return nil
	}

	//给云端发送
	hbData := make([]*cloudPlatform.ReportEventData, 0)
	hbData = append(hbData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           hb.Header.Sn,
		DevType:      StrDeviceTypeSFL,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("hbData = ", hbData)
	data := &cloudPlatform.ReportEventList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		logger.Errorf("report cloud platform conn is nil")
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	return nil
}

func (c *CloudTcpCli) ReportAgxStatusEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.AgxHeartBeatInfo{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		return fmt.Errorf("report sfl proto Unmarshal error: %v", err)
	}
	// hb := mavlink.SflHeartReport{}
	logger.Debug("start Unmarshal")

	// mu.Lock()
	// defer mu.Unlock()

	EventType, SubEventType := int32(EnumEventDeviceStatus), int32(EnumSubEventDeviceOnLine)
	EventId := hb.Data.GetEventId()

	var bodyData []byte
	if hb.Header.MsgType == mavlink.AgxEventOnLine {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOnLine

		logger.Infof("receive agx online event.")
		bodyDataPtr := &cloudPlatform.DeviceOnLineDesc{
			//Longitude: float32(hb.Data.GunLongitude),
			//Latitude:  float32(hb.Data.GunLatitude),
		}
		//
		bodyDataBin, err := proto.Marshal(bodyDataPtr)
		if err == nil {
			bodyData = bodyDataBin
		}

	} else if hb.Header.MsgType == mavlink.AgxEventOffOnLine {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOffLine

		logger.Infof("agx offline event.")

	} else {
		return nil
	}

	//给云端发送
	hbData := make([]*cloudPlatform.ReportEventData, 0)
	hbData = append(hbData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           hb.Header.Sn,
		DevType:      StrDeviceTypeAgx,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("hbData = ", hbData)
	data := &cloudPlatform.ReportEventList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	return nil
}
func (c *CloudTcpCli) ReportAgxPtzLockUavEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	lockUav := &client.AgxPtzLockInfo{}
	err := proto.Unmarshal(info, lockUav)
	if err != nil {
		return fmt.Errorf("report agx proto Unmarshal error: %v", err)
	}
	logger.Debug("start Unmarshal")

	var bodyData []byte
	EventType, SubEventType := int32(EnumEventPtzLock), int32(EnumSubEventPtzLockSucc)
	EventId := lockUav.GetEventId()

	if lockUav.Header.MsgType == mavlink.AgxEventPtzLockUavSucc {
		EventType, SubEventType = int32(EnumEventPtzLock), EnumSubEventPtzLockSucc
		logger.Infof("agx ptz lock succ")

		var uavsToReport []*cloudPlatform.EventPtzLockUav
		var lockUavBody *cloudPlatform.EventPtzLockUavDesc = new(cloudPlatform.EventPtzLockUavDesc)

		for _, uavItems := range lockUav.Data {
			if uavItems == nil {
				continue
			}
			//
			uavsToReport = append(uavsToReport, &cloudPlatform.EventPtzLockUav{
				SerialNum: uavItems.SerialNum,
				Name:      uavItems.DroneName,
				Longitude: uavItems.Longitude,
				Latitude:  uavItems.Latitude,
				LockTime:  uavItems.LockedTime,
			})
		}
		logger.Infof("ptz lock uav succ, uav list: %v", uavsToReport)

		lockUavBody.Body = uavsToReport
		bodyDataBin, err := proto.Marshal(lockUavBody)
		if err == nil {
			bodyData = bodyDataBin

		} else {
			logger.Infof("marsh ptz lock uavs fail, e: %v", err)
			return fmt.Errorf("marsh detect uavs fail, e: %v", err)
		}

	} else if lockUav.Header.MsgType == mavlink.AgxEventPtzLockUavFail {
		EventType, SubEventType = int32(EnumEventPtzLock), EnumSubEventPtzLockFail
		logger.Infof("agx ptz lock fail")

	} else {
		logger.Infof("not support msg type, %v", lockUav.Header.MsgType)
		return nil
	}

	//给云端发送
	reportEventData := make([]*cloudPlatform.ReportEventData, 0)
	reportEventData = append(reportEventData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           lockUav.Header.Sn,
		DevType:      StrDeviceTypeAgx,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("ptzLock = ", reportEventData)
	data := &cloudPlatform.ReportEventList{
		Body: reportEventData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		logger.Infof("report connect is nil or is not login")
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	logger.Infof("report agx ptz lock uav report")
	return nil
}

func (c *CloudTcpCli) ReportAgxDetectEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	detect := &client.AgxDetectInfo{}
	err := proto.Unmarshal(info, detect)
	if err != nil {
		return fmt.Errorf("report agx proto Unmarshal error: %v", err)
	}

	logger.Debug("start Unmarshal")
	EventType, SubEventType := int32(EnumEventDetect), int32(EnumSubEventDetectAppear)
	EventId := detect.GetEventId()

	var bodyData []byte
	uavs := make([]*cloudPlatform.EventDetectUav, 0)

	if detect.Header.MsgType == mavlink.AgxEventDetectAppear {
		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectAppear

		logger.Infof("agx detect appear event.")
		bodyDataPtr := &cloudPlatform.DetectUavDesc{}

		for _, v := range detect.Data {
			if v == nil {
				continue
			}
			if v.Classification == 0x04 {
				logger.Infof("is bird detect type, modify: %x to 0x00", v.Classification)
				v.Classification = 0x00
			}
			uavs = append(uavs, &cloudPlatform.EventDetectUav{
				SerialNum:      strconv.FormatInt(int64(v.ObjId), 10),
				Classification: v.Classification,
				X:              float32(v.X),
				Y:              float32(v.Y),
				Z:              float32(v.Z),
			})
		}
		logger.Infof("detect uav data: %v", uavs)

		bodyDataPtr.Body = uavs
		bodyDataBin, err := proto.Marshal(bodyDataPtr)
		if err == nil {
			bodyData = bodyDataBin
		} else {
			logger.Infof("marshal detect uavs fail, e: %v", err)
			return fmt.Errorf("marshal detect uavs fail, e: %v", err)
		}

		videostore.VsSingleton.GoSaveToLocalVideoAndPushToS3(EventId, detect.Header.Sn)

	} else if detect.Header.MsgType == mavlink.AgxEventDetectDisappear {
		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectDisAppear

		logger.Infof("agx detect disappear event.")

		videostore.VsSingleton.GoCancelCaptureVideo(EventId)

	} else if detect.Header.MsgType == mavlink.AgxEventPushVideoDone {
		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventPushVideoDone
		fileURL := fmt.Sprintf("%s.mp4", EventId)
		StoreType := strconv.FormatInt(videostore.VsSingleton.S3Con.StoreType, 10)
		bodyDataPtrList := make([]*cloudPlatform.ReportCloudVideo, 0)
		bodyDataPtr := &cloudPlatform.ReportCloudVideo{
			ProtoType:  StoreType,
			BucketName: videostore.VsSingleton.S3Con.BucketName,
			FileUrl:    fileURL,
		}
		bodyDataPtrList = append(bodyDataPtrList, bodyDataPtr)
		bodyDataPtrSend := &cloudPlatform.ReportCloudVideoList{}
		bodyDataPtrSend.Body = bodyDataPtrList

		bodyDataBin, err := proto.Marshal(bodyDataPtrSend)
		if err == nil {
			bodyData = bodyDataBin
		} else {
			logger.Infof("marshal detect uavs fail, e: %v", err)
			return fmt.Errorf("marshal detect uavs fail, e: %v", err)
		}

		logger.Infof("AgxEventPushVideoDone event.")
	} else {
		logger.Infof("not support msg type: %v", detect.Header.MsgType)
		return nil
	}

	//给云端发送
	hbData := make([]*cloudPlatform.ReportEventData, 0)
	hbData = append(hbData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           detect.Header.Sn,
		DevType:      StrDeviceTypeAgx,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("hbData = ", hbData)
	data := &cloudPlatform.ReportEventList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		logger.Infof("report connect is nil or is not login")
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	logger.Infof("report agx detect report, uavs: %v", uavs)
	return nil
}
