package down

import (
	"context"
	"encoding/json"
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

// opsCode define
const (
	opsUrd360StartMonitor   = 1
	opsUrd360StopMonitor    = 2
	opsUrd360UpdateConfig   = 3
	opsUrd360GetConfig      = 4
	opsUrd360Enable         = 5
	opsUrd360StartSpectrume = 6
	opsUrd360StopSpectrum   = 7
)

func urd360PropertyTopicName() string {
	return propertySubTopic(common.TracerRFurd360)
}

func urd360PSvcTopicName() string {
	return svcSubTopic(common.TracerRFurd360)
}

// 1
type downUrd360StartMonitorResponse struct {
	Status int32  `json:"status"`
	Info   string `protobuf:"bytes,2,opt,name=info,proto3" json:"info,omitempty"`
}

// 2
type downUrd360StopMonitorResponse struct {
	Status int32  `json:"status"`
	Info   string `protobuf:"bytes,2,opt,name=info,proto3" json:"info,omitempty"`
}

// 3
type downUrd360UpdateConfigResponse struct {
	Status int32  `json:"status"`
	Info   string `protobuf:"bytes,2,opt,name=info,proto3" json:"info,omitempty"`
}

// 4
type downUrd360GetConfigResponse struct {
	Status  int32            `json:"status"`
	Info    string           `protobuf:"bytes,2,opt,name=info,proto3" json:"info,omitempty"`
	Configs []*client.Config `protobuf:"bytes,3,rep,name=configs,proto3" json:"configs,omitempty"`
}

// 6
type downUrd360StartSpectrumResponse struct {
	Status int32  `json:"status"`
	Info   string `protobuf:"bytes,2,opt,name=info,proto3" json:"info,omitempty"`
}

// 7
type downUrd360StopSpectrumResponse struct {
	Status int32  `json:"status"`
	Info   string `protobuf:"bytes,2,opt,name=info,proto3" json:"info,omitempty"`
}

func doUrd360Logic(m mqtt.Message) []byte {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	logger.Debug("m = ", m.Payload())
	p, err := decodeMessage(m.Payload())
	//json Marshal or UnMarshal error
	errJSONTypeMsg := errorMsg(jsonFail, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, jsonFailMsg)
	logger.Error("errMsg = ", errJSONTypeMsg)
	if err != nil {
		logger.Error("decodeMessage error = ", err)
		return encodeMessage(errJSONTypeMsg)
	}
	encodeOkmsg := make([]byte, 0)
	logger.Debug("p.MsgData.Data.OpsCode = ", p.MsgData.Data.OpsCode)
	switch p.MsgData.Data.OpsCode {
	case opsUrd360StartMonitor:
		req := &client.Urd360StartMonitorRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.Urd360StartMonitorResponse{}
		newresp := &downUrd360StartMonitorResponse{}

		err = handler.NewUrd360Service().StartMonitor(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		newresp.Info = resp.Info
		newresp.Status = resp.Result
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, newresp)
		// smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsUrd360StopMonitor:
		req := &client.Urd360StopMonitorRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.Urd360StopMonitorResponse{}

		err = handler.NewUrd360Service().StopMonitor(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		newresp := &downUrd360StopMonitorResponse{}
		newresp.Info = resp.Info
		newresp.Status = resp.Result
		// smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, newresp)
		encodeOkmsg = encodeMessage(smsg)
	case opsUrd360UpdateConfig:
		req := &client.Urd360UpdateConfigRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.Urd360UpdateConfigResponse{}

		err = handler.NewUrd360Service().UpdateConfig(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		newresp := &downUrd360StopMonitorResponse{}
		newresp.Info = resp.Info
		newresp.Status = resp.Result
		// smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, newresp)
		// smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsUrd360GetConfig:
		req := &client.Urd360GetConfigRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.Urd360GetConfigResponse{}
		newresp := downUrd360GetConfigResponse{}

		err = handler.NewUrd360Service().GetConfig(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		newresp.Configs = resp.Configs
		newresp.Info = resp.Info
		newresp.Status = resp.Result
		// smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, newresp)

		encodeOkmsg = encodeMessage(smsg)
	case opsUrd360Enable:
		req := &client.Urd360EnableRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.Urd360EnableResponse{}

		err = handler.NewUrd360Service().Enable(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsUrd360StartSpectrume:
		req := &client.Urd360StartSpectrumRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.Urd360StartSpectrumResponse{}
		newresp := &downUrd360StartSpectrumResponse{}
		err = handler.NewUrd360Service().StartSpectrum(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		newresp.Info = resp.Info
		newresp.Status = resp.Result
		// smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, newresp)

		encodeOkmsg = encodeMessage(smsg)
	case opsUrd360StopSpectrum:
		req := &client.Urd360StopSpectrumRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.Urd360StopSpectrumResponse{}

		err = handler.NewUrd360Service().StopSpectrum(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		newresp := &downUrd360StopSpectrumResponse{}
		newresp.Info = resp.Info
		newresp.Status = resp.Result
		// smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, newresp)
		encodeOkmsg = encodeMessage(smsg)
	default:
		unknownOps := errorMsg(unknowOpsCode, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, unknowOpsCodeMsg)
		return encodeMessage(unknownOps)
	}
	logger.Debug("encodeSmsg = ", encodeOkmsg)
	return encodeOkmsg
}
