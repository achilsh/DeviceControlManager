package down

import (
	"context"
	"encoding/json"
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/udp"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

// opsCode define
const (
	opsRadarGetBeamConfig            = 1
	opsRadarStartDetect              = 2
	opsRadarEndDetect                = 3
	opsRadarSetBeamSchedule          = 4
	opsRadarPostureCalibration       = 5
	opsRadarPostureCalibrationManual = 6
	opsRadarGetVersionInfo           = 7
	opsAgxSelectUav                  = 8
	opsAgxPtzDirection               = 9
	opsAgxPtzZoom                    = 10
	opsAgxSelectSflUav               = 11
)

const (
	statusSuccess = 1
	statusFail    = 2
)

// 备注一下：云平台不想默认为0的json不给字段，pb文件文件生成默认会有 omitempty，
// 这里给他单独加一个字段适配一下，和前端的不一样。
// 另外一个点，这里和哨兵塔的status字段也做一下匹配，1是成功，2是失败
type radarStatusResponse struct {
	Status int32 `json:"status"`
}

func agxPropertyTopicName() string {
	return propertySubTopic(common.Agx)
}

func agxSvcTopicName() string {
	return svcSubTopic(common.Agx)
}

type agxPtzDirectionRequest struct {
	Sn     string `json:"sn,omitempty"`
	Cmd    uint32 `json:"cmd"`
	Level  uint32 `json:"level"`
	Method uint32 `json:"method"`
}
type agxPtzZoomRequest struct {
	Sn        string `json:"sn,omitempty"`
	Cmd       uint32 `json:"cmd"`
	PyhFcous  uint32 `json:"pyhFcous"`
	Zoom      uint32 `json:"zoom"`
	FocusSite uint32 `json:"focusSite"`
}

type agxSelectSflUav struct {
	SflSn        string `json:"sflSn"`
	DroneName    string `json:"droneName"`
	DroneSn      string `json:"droneSn"`
	DroneHorizon int32  `json:"droneHorizon"`
	DronePitch   int32  `json:"dronePitch"`
	DroneHeight  int16  `json:"droneHeight"`
}
type agxSelectSflUavResponse struct {
	Status int32 `json:"status"`
}

type agxPtzZoomResponse struct {
	Status int32 `json:"status,omitempty"`
}
type agxPtzDirectionResponse struct {
	Status int32 `json:"status,omitempty"`
}

func doAgxLogic(m mqtt.Message) []byte {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	logger.Debug("m = ", m.Payload())
	p, err := decodeMessage(m.Payload())
	//json Marshal or UnMarshal error
	if p == nil {
		logger.Error("decodeMessage is nil")
		return nil
	}
	errJSONTypeMsg := errorMsg(jsonFail, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, jsonFailMsg)
	logger.Error("errMsg = ", errJSONTypeMsg)
	if err != nil {
		logger.Error("decodeMessage error = ", err)
		return encodeMessage(errJSONTypeMsg)
	}
	encodeOkmsg := make([]byte, 0)
	logger.Debug("p.MsgData.Data.OpsCode = ", p.MsgData.Data.OpsCode)
	switch p.MsgData.Data.OpsCode {
	case opsRadarGetBeamConfig:
		req := &client.RadarGetBeamConfigRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.RadarGetBeamConfigResponse{}

		err = handler.NewDeviceCenter().RadarGetBeamConfig(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsRadarStartDetect:
		req := &client.RadarStartDetectRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.RadarStartDetectResponse{}

		err = handler.NewDeviceCenter().RadarStartDetect(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := mqttPubMsg{}
		if resp.Status == 0 {
			resp := &radarStatusResponse{Status: statusSuccess}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)

		} else {
			resp := &radarStatusResponse{Status: statusFail}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		}
		encodeOkmsg = encodeMessage(smsg)

	case opsRadarEndDetect:
		req := &client.RadarEndDetectRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.RadarEndDetectResponse{}

		err = handler.NewDeviceCenter().RadarEndDetect(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := mqttPubMsg{}
		if resp.Status == 0 {
			resp := &radarStatusResponse{Status: statusSuccess}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)

		} else {
			resp := &radarStatusResponse{Status: statusFail}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		}
		encodeOkmsg = encodeMessage(smsg)
	case opsRadarSetBeamSchedule:
		req := &client.RadarSetBeamScheduleRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.RadarSetBeamScheduleResponse{}

		err = handler.NewDeviceCenter().RadarSetBeamSchedule(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}

		smsg := mqttPubMsg{}
		if resp.Status == 0 {
			resp := &radarStatusResponse{Status: statusSuccess}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)

		} else {
			resp := &radarStatusResponse{Status: statusFail}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		}
		encodeOkmsg = encodeMessage(smsg)

	case opsRadarPostureCalibration:
		req := &client.PostureCalibrationRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.PostureCalibrationResponse{}

		err = handler.NewDeviceCenter().PostureCalibration(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := mqttPubMsg{}
		if resp.Status == 0 {
			resp := &radarStatusResponse{Status: statusSuccess}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)

		} else {
			resp := &radarStatusResponse{Status: statusFail}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		}
		encodeOkmsg = encodeMessage(smsg)
	case opsRadarPostureCalibrationManual:
		req := &client.PostureCalibrationManualRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.PostureCalibrationManualResponse{}

		err = handler.NewDeviceCenter().PostureCalibrationManual(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := mqttPubMsg{}
		if resp.Status == 0 {
			resp := &radarStatusResponse{Status: statusSuccess}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)

		} else {
			resp := &radarStatusResponse{Status: statusFail}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		}
		encodeOkmsg = encodeMessage(smsg)
	case opsRadarGetVersionInfo:
		req := &client.RadarGetVersionInfoRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.RadarGetVersionInfoResponse{}

		err = handler.NewDeviceCenter().RadarGetVersionInfo(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsAgxSelectUav:
		req := &client.AgxSelectUavRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.AgxSelectUavResponse{}

		err = handler.NewDeviceCenter().AgxSelectUav(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := mqttPubMsg{}
		if resp.Status == 0 {
			resp := &radarStatusResponse{Status: statusSuccess}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)

		} else {
			resp := &radarStatusResponse{Status: statusFail}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		}
		encodeOkmsg = encodeMessage(smsg)
	case opsAgxPtzDirection:
		req := &agxPtzDirectionRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := agxPtzDirectionResponse{
			Status: statusSuccess,
		}
		handle := udp.UDPHandler
		if handle == nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, offlineMsg)
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		logger.Debug("req = ", req)
		handle.DoDirectionlSet(udp.DirectionCmd, req.Cmd, req.Level, req.Method)

		smsg := mqttPubMsg{}
		smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)

	case opsAgxPtzZoom:
		req := &agxPtzZoomRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := agxPtzZoomResponse{
			Status: statusSuccess,
		}
		handle := udp.UDPHandler
		if handle == nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, offlineMsg)
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		logger.Debug("req = ", req)
		handle.DoZoomSet(udp.ZoomCmd, req.Cmd, req.PyhFcous, req.Zoom, req.FocusSite)

		smsg := mqttPubMsg{}
		smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsAgxSelectSflUav:
		req := &client.AgxSelectSflUavRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.AgxSelectSflUavResponse{}

		err = handler.NewDeviceCenter().AgxSelectSflUav(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := mqttPubMsg{}
		if resp.Status == 1 {
			resp := &agxSelectSflUavResponse{Status: statusSuccess}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)

		} else {
			resp := &agxSelectSflUavResponse{Status: statusFail}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		}
		encodeOkmsg = encodeMessage(smsg)
	default:
		unknownOps := errorMsg(unknowOpsCode, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, unknowOpsCodeMsg)
		return encodeMessage(unknownOps)
	}
	logger.Debug("encodeSmsg = ", encodeOkmsg)
	return encodeOkmsg
}
