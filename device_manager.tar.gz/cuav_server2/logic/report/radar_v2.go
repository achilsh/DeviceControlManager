package report

import (
	"context"
	"fmt"
	"math"
	"sync/atomic"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/rpc/cmdhandler"
)

// TrackInfoV2 追踪目标信息上报
func TrackInfoV2(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	if sn == "" {
		logger.Errorf("TrackInfoV2 radar sn is null")
		return nil, fmt.Errorf("TrackInfoV2 radar sn is null")
	}
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_RADAR, sn)
	if cache, ok := handler.DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*handler.Device)
		dev.LastHeartTime = time.Now()
		dev.Status = common.DevOnline
	}

	radarTrackResp, ok := data.(*bizproto.RadarTrack)
	if !ok {
		logger.Errorf("TrackInfoV2 covert RadarTrack err")
		return nil, fmt.Errorf("TrackInfoV2 covert RadarTrack err")
	}
	logger.Infof("TrackInfoV2 response %#+v", radarTrackResp)

	radarTrackItems := radarTrackResp.Item
	if len(radarTrackItems) <= 0 {
		return nil, nil
	}
	plotTracks := make([]common.DbRawAutelRadarPlotTrackBodyEntity, 0)
	for i := 0; i < len(radarTrackItems); i++ {
		if radarTrackItems[i].StateType == 0 {
			continue
		}
		alive, err := float32ToUint16(radarTrackItems[i].Alive)
		if err != nil {
			logger.Errorf("TrackInfoV2 float32ToUint16 convert error %v", err)
		}
		plotTracks = append(plotTracks, common.DbRawAutelRadarPlotTrackBodyEntity{
			Obj_id: radarTrackItems[i].Id,
			//HeaderUid:         0,
			Azimuth: float64(radarTrackItems[i].Azimuth) / float64(handler.RadarReducedValue),
			//Obj_dist_interpol: 0,
			Elevation: float64(radarTrackItems[i].Elevation) / float64(handler.RadarReducedValue),
			Velocity:  float64(radarTrackItems[i].Velocity) / float64(handler.RadarReducedValue),
			//Doppler_chn:       0,
			//Mag:               0,
			Ambiguous:         int16(radarTrackItems[i].Ambiguous),
			Classification:    int16(radarTrackItems[i].Classification),
			Classfy_prob:      float64(radarTrackItems[i].ClassifyProb) / float64(handler.RadarReducedValue),
			ExistingProb:      float32(radarTrackItems[i].ExistingProb) / float32(handler.RadarReducedValue),
			Abs_vel:           float64(radarTrackItems[i].AbsVel) / float64(handler.RadarReducedValue),
			Orientation_angle: float64(radarTrackItems[i].OrientationAngle) / float64(handler.RadarReducedValue),
			Alive:             alive,
			Tws_tas_flag:      uint16(radarTrackItems[i].TwsTasFlag),
			X:                 float64(radarTrackItems[i].X) / float64(handler.RadarReducedValue),
			Y:                 float64(radarTrackItems[i].Y) / float64(handler.RadarReducedValue),
			Z:                 float64(radarTrackItems[i].Z) / float64(handler.RadarReducedValue),
			VX:                float64(radarTrackItems[i].Vx) / float64(handler.RadarReducedValue),
			VY:                float64(radarTrackItems[i].Vy) / float64(handler.RadarReducedValue),
			VZ:                float64(radarTrackItems[i].Vz) / float64(handler.RadarReducedValue),
			AX:                float64(radarTrackItems[i].Ax) / float64(handler.RadarReducedValue),
			AY:                float64(radarTrackItems[i].Ay) / float64(handler.RadarReducedValue),
			AZ:                float64(radarTrackItems[i].Az) / float64(handler.RadarReducedValue),
			X_variance:        float64(radarTrackItems[i].XVariance) / float64(handler.RadarReducedValue),
			Y_variance:        float64(radarTrackItems[i].YVariance) / float64(handler.RadarReducedValue),
			Z_variance:        float64(radarTrackItems[i].ZVariance) / float64(handler.RadarReducedValue),
			Vx_variance:       float64(radarTrackItems[i].VxVariance) / float64(handler.RadarReducedValue),
			Vy_variance:       float64(radarTrackItems[i].VyVariance) / float64(handler.RadarReducedValue),
			Vz_variance:       float64(radarTrackItems[i].VzVariance) / float64(handler.RadarReducedValue),
			Ax_variance:       float64(radarTrackItems[i].AxVariance) / float64(handler.RadarReducedValue),
			Ay_variance:       float64(radarTrackItems[i].AyVariance) / float64(handler.RadarReducedValue),
			Az_variance:       float64(radarTrackItems[i].AzVariance) / float64(handler.RadarReducedValue),
			State_type:        int16(radarTrackItems[i].StateType),
			Motion_type:       int16(radarTrackItems[i].MotionType),
			Forcast_frame_num: int16(radarTrackItems[i].ForcastFrameNum),
			Association_num:   int16(radarTrackItems[i].AssociationNum),
			Assoc_bit0:        radarTrackItems[i].AssocBit0,
			Assoc_bit1:        radarTrackItems[i].AssocBit1,
			//Reserve:           0,
			//Reserved2:         0,
			//Crc:               0,
			//Create_time:       "",
			//Vendor:            "",
			//Frequency:         "",
			//Model:             "",
			//Is_whitelist:      false,
			//Level:             0,
		})
	}
	if len(plotTracks) <= 0 {
		return nil, nil
	}
	atomic.AddInt64(&handler.RadarSpace, 1)
	temp := atomic.LoadInt64(&handler.RadarSpace)
	if temp == 9 {
		atomic.StoreInt64(&handler.RadarSpace, 0)
		logger.Info("Radar detect send ")
	} else {
		logger.Info("Radar detect space ")
		return nil, nil
	}

	radarTrackMsg := &common.EquipmentMessageBoxEntity{
		Name:      sn,
		Sn:        sn,
		Info:      plotTracks,
		EquipType: int(common.DEV_RADAR),
		MsgType:   msgid.RadarIdV2Track,
	}
	_ = mq.RadarTrackBroker.Publish(mq.RadarTrackTopic, broker.NewMessage(radarTrackMsg))

	//收到雷达侦测到无人机数据，向数据库记录当天有记录
	_, exist := handler.RadarReplayMap.Get(sn)
	if !exist {
		handler.RadarReplayMap.Set(sn, sn, true)
		time1 := time.Now()
		resTime := time1.Format("20060102")
		handler.NewDevSchedule().Insert(context.Background(), &client.DevScheduleInsertReq{Sn: sn, Date: resTime, Information: 1}, &client.DevScheduleInsertRsp{})
	}

	logger.Info("TrackInfoV2 追踪目标信息上报: %v", plotTracks)
	return radarTrackResp, nil
}

// StateInfoV2 雷达状态信息上报
func StateInfoV2(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	radarStateResp, ok := data.(*bizproto.RadarState)
	if !ok {
		logger.Errorf("covert RadarState err")
		return nil, fmt.Errorf("covert RadarState err")
	}
	logger.Infof("StateInfoV2 response %#+v", radarStateResp)

	if sn == "" {
		logger.Errorf("StateInfoV2 radar sn is null")
		return nil, fmt.Errorf("StateInfoV2 radar sn is null")
	}
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_RADAR, sn)
	if cache, ok := handler.DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*handler.Device)
		dev.LastHeartTime = time.Now()
		dev.Status = common.DevOnline
	} else {
		// 和其他设备心跳处理保持一致。
		dev := &handler.Device{
			Sn:                sn,
			Status:            common.DevOnline,
			DevType:           common.DEV_RADAR,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			IsEnable:          handler.GetDevStatus(int32(common.DEV_RADAR), sn),
			GetStatusInterval: time.Now(),
		}
		handler.DevStatusMap.Store(cacheKey, dev)
	}

	if radarStateResp != nil && radarStateResp.Attitude != nil {
		if float64(radarStateResp.Attitude.Heading)/handler.RadarPostureReduce > handler.HeadingRan {
			logger.Errorf("雷达姿态异常数据: %#+v", radarStateResp)
			return nil, fmt.Errorf("雷达姿态异常数据")
		}
	}
	// 雷达上报姿态信息
	radarPostureMsg := &common.EquipmentMessageBoxEntity{
		Name:      sn,
		Sn:        sn,
		EquipType: int(common.DEV_RADAR),
		MsgType:   mavlink.RadarIdUploadPosture,
		Info: common.RadarUploadPostureEntity{
			//Reserved:            ,
			Heading:   float64(radarStateResp.Attitude.Heading) / handler.RadarPostureReduce,
			Pitching:  float64(radarStateResp.Attitude.Pitching) / handler.RadarPostureReduce,
			Rolling:   float64(radarStateResp.Attitude.Rolling) / handler.RadarPostureReduce,
			Longitude: float64(radarStateResp.RadarLLA.Longitude) / handler.RadarPostureReduce20,
			Latitude:  float64(radarStateResp.RadarLLA.Latitude) / handler.RadarPostureReduce20,
			Altitude:  float64(radarStateResp.RadarLLA.Altitude) / handler.RadarPostureReduce7,
			//VelocityNavi:        0, // 导航速度（m/s）
			//SigProcRelativeTime: 0, // 目标时间（绝对时间）
		},
	}

	_ = mq.RadarPostureBroker.Publish(mq.RadarPostureTopic, broker.NewMessage(radarPostureMsg))

	// 雷达上传心跳包
	radarHeart := &common.RadarStatusEntity{
		Electricity: int32(radarStateResp.Electricity),
		Status:      int(radarStateResp.Status),
		IsOnline:    common.DevOnline,
		SerialNum:   sn,
		//Faults:,
	}
	// TODO: 每次姿态上报都要去查表，需要优化
	equipList := &client.EquipListRes{}
	err := handler.NewEquipList().List(ctx, &client.EquipListReq{}, equipList)
	if err != nil {
		logger.Errorf("StateInfoV2 get EquipList err: %v", err)
	}
	for _, equip := range equipList.Equips {
		if equip.Sn == sn {
			radarHeart.Ip = equip.Ip
		}
	}

	radarHeartMsg := &common.EquipmentMessageBoxEntity{
		Name:      sn,
		Sn:        sn,
		EquipType: int(common.DEV_RADAR),
		MsgType:   mavlink.RadarIdHeartbeat,
		Info:      radarHeart,
	}
	_ = mq.EquipmentStatusBroker.Publish(mq.EquipmentStatusTopic, broker.NewMessage(radarHeartMsg))

	return radarStateResp, nil
}

func float32ToUint16(alive float32) (uint16, error) {
	// 转换为int32，然后取整
	intVal := int32(alive)
	// 检查是否溢出
	if intVal < 0 || intVal > math.MaxUint16 {
		return 0, fmt.Errorf("值超出uint16的范围")
	}
	// 转换为uint16
	uintVal := uint16(intVal)
	return uintVal, nil
}

func init() {
	cmdhandler.Instance().RegisterHandler(common.DEV_RADAR, msgid.RadarIdV2Track, TrackInfoV2)
	cmdhandler.Instance().RegisterHandler(common.DEV_RADAR, msgid.RadarIdV2State, StateInfoV2)
}
