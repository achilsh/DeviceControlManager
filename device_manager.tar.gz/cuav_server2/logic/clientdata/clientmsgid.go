package clientdata

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
)

const (
	msgIDHistoryWifiConn   = 1    //启禁雷达
	wsOtaPkgDownloadStatus = 0x38 // OTA下载文件状态
	wsDeviceUpdateStatus   = 0x37 // 设备OTA状态更新
	urdDeviceInfoType      = 1    // RF设备信息上报
	urdDroneInfoType       = 3    // RF侦测无人机数据
	urdSpectrumType        = 20   // RF频谱数据
)

// 设备命令字转换成前端唯一上报ID
var (
	clientMsgID = map[common.DeviceType]map[int32]int32{
		common.DEV_RADAR: {
			mavlink.RadarIdHeartbeat:                common.ClientMsgIDRadarHeartBeat,
			msgIDHistoryWifiConn:                    common.ClientMsgIDRadarWifiConn,
			wsOtaPkgDownloadStatus:                  common.ClientMsgIDOTAPkgDownloadStatus,
			wsDeviceUpdateStatus:                    common.ClientMsgIDDeviceUpdateStatus,
			mavlink.RadarIdPostureCalibrationResult: common.ClientMsgIDRadarPosture,
			mavlink.RadarIdUploadTrackInfo:          common.ClientMsgIDRadarTrack,
			mavlink.RadarIdUploadPosture:            common.ClientMsgIDRadarUploadPosture,
		},
		common.DEV_V2DRONEID: {
			wsDeviceUpdateStatus:                 common.ClientMsgIDDeviceUpdateStatus,
			mavlink.TracerIdGetDetectRes:         common.ClientMsgIDTracerDetect,
			mavlink.TracerIdGetRemoteIdDetectRes: common.ClientMsgIDTracerRemoteDetect,
			mavlink.TracerIdGetFreqDetectRes:     common.ClientMsgIDTracerFreqDetect,
			mavlink.TracerIdGetFreqDataRes:       common.ClientMsgIDTracerFreqData,
			mavlink.DRONEIDMsgHeartbeat:          common.ClientMsgIDTracerHeartBeat,
		},
		common.DEV_AEAG: {
			wsDeviceUpdateStatus: common.ClientMsgIDDeviceUpdateStatus,
		},
		common.DEV_SCREEN: {
			wsDeviceUpdateStatus:     common.ClientMsgIDDeviceUpdateStatus,
			mavlink.SendHitResult:    common.ClientMsgIDScreenSendHit,
			mavlink.ScreenHitResult:  common.ClientMsgIDScreenHitResult,
			mavlink.AEAGMsgHeartbeat: common.ClientMsgIDAEAGHeartBeat,
		},
		common.DEV_NSF4000: {
			config.NSF4000TypeTimeSync:  common.ClientMsgIDSpooferTimeSync,
			config.NSF4000TypeEphemeris: common.ClientMsgIDSpooferEphemeris,
			config.NSF4000TypeLLH:       common.ClientMsgIDSpooferTypeLLH,
			config.NSF4000TypeGpsStatus: common.ClientMsgIDSpooferGPSStatus,
			config.NSF4000TypeWorking:   common.ClientMsgIDSpooferWork,
			config.NSF4000TypeOnline:    common.ClientMsgIDSpooferOnline,
		},
		common.DEV_URD360: {
			urdDeviceInfoType: common.ClientMsgIDRFDeviceInfo,
			urdDroneInfoType:  common.ClientMsgIDRFDroneInfo,
			urdSpectrumType:   common.ClientMsgIDRFSpectrum,
		},
		common.DEV_SFL: {
			wsDeviceUpdateStatus:          common.ClientMsgIDDeviceUpdateStatus,
			mavlink.SflHeartMsgReport:     common.ClientMsgIDSFLHeartBeat,
			mavlink.SflDetectMsgReport:    common.ClientMsgIDSFLDetect,
			mavlink.SflHitStatusMsgReport: common.ClientMsgIDSFLHitStatus,
		},
		common.DEV_FPV: {
			wsDeviceUpdateStatus:      common.ClientMsgIDDeviceUpdateStatus,
			mavlink.FpvHeartReportMsg: common.ClientMsgIDFPVHeartBeat,
			mavlink.FpvFreqReportMsg:  common.ClientMsgIDFPVFreq,
			mavlink.FpvVideoStreamMsg: common.ClientMsgIdTransferFpvVideoStream,
		},
		common.DEV_AGX: {
			mavlink.AgxMsgHeartBeat:    common.ClientMsgIdAgxHeartData,
			mavlink.AgxMsgPerception:   common.ClientMsgIdAgxPerceptionData,
			mavlink.AgxMsgDetect:       common.ClientMsgIdAgxDetectData,
			mavlink.AgxMsgDeviceStatus: common.ClientMsgIdAgxDevStatusData,
			mavlink.AgxMsgPTZStatus:    common.ClientMsgIdAgxPTZStatusData,
		},
	}
)

// GetClientMsgID 获取前端上报msgid
func GetClientMsgID(devType common.DeviceType, msgID int32) int32 {
	_, ok := clientMsgID[devType]
	if !ok {
		logger.Errorf("devType %d not register", devType)
		return -1
	}
	v, ok := clientMsgID[devType][msgID]
	if !ok {
		logger.Errorf("devType %d msgID %d not register", devType, msgID)
		return -1
	}
	return v
}
