package response

import (
	"context"
	"errors"
	"reflect"

	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	entity "adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/rpc/cmdhandler"
)

// RadarIdV2SetBeamSchedulingResponse 设置波束范围
func RadarIdV2SetBeamSchedulingResponse(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarSetBeamSchedulingRsp)
	if !ok {
		logger.Errorf("covert RadarIdV2SetBeamSchedulingResponse err")
		return nil, errors.New("covert RadarIdV2SetBeamSchedulingResponse err")
	}
	logger.Infof("RadarIdV2SetBeamSchedulingResponse %+v", rsp)
	return rsp, nil
}

// RadarIdV2SetSettingResponse 设置雷达信息
func RadarIdV2SetSettingResponse(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarSetRsp)
	if !ok {
		logger.Errorf("covert RadarIdV2SetSettingResponse err")
		return nil, errors.New("covert RadarIdV2SetSettingResponse err")
	}
	logger.Infof("RadarIdV2SetSettingResponse %+v", rsp)
	return rsp, nil
}

// RadarIdV2SetAttitudeLLAResponse 设置雷达姿态
func RadarIdV2SetAttitudeLLAResponse(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarSetAttitudeLLARsp)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert RadarIdV2SetAttitudeLLAResponse err")
		return nil, errors.New("covert RadarIdV2SetAttitudeLLAResponse err")
	}
	return rsp, nil
}

func init() {
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarIdV2SetBeamScheduling, RadarIdV2SetBeamSchedulingResponse)
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarIdV2SetSetting, RadarIdV2SetSettingResponse)
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarIdV2SetAttitudeLLA, RadarIdV2SetAttitudeLLAResponse)
}
