package handler

import (
	"errors"
	"fmt"
	"io"
	"net"
	"sync"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

var (
	UrdSpectrumStartFlag   = [4]byte{0xDD, 0xDD, 0xDD, 0xDD}
	UrdSpectrumDataFlag    = [4]byte{0xEE, 0xEE, 0xEE, 0xEE}
	UrdSpectrumEndFlag     = [4]byte{0xBB, 0xBB, 0xBB, 0xBB}
	urdSpectrumConnections sync.Map
)

// 获取设备连接
func getUrdSpectrumConnection(sn string) (net.Conn, bool) {
	conn, ok := urdSpectrumConnections.Load(sn)
	if !ok {
		return nil, false
	}
	return conn.(net.Conn), true
}

// 存储设备连接
func setUrdSpectrumConnection(sn string, conn net.Conn) {
	urdSpectrumConnections.Store(sn, conn)
}

// 删除设备连接
func deleteUrdSpectrumConnection(sn string) {
	urdSpectrumConnections.Delete(sn)
}

func checkUrdSpectrumDataStartFlag(flag []byte) bool {
	if len(flag) < 4 {
		return false
	}
	return flag[0] == UrdSpectrumStartFlag[0] && flag[1] == UrdSpectrumStartFlag[1] && flag[2] == UrdSpectrumStartFlag[2] && flag[3] == UrdSpectrumStartFlag[3]
}

func checkUrdSpectrumDataEndFlag(flag []byte) bool {
	if len(flag) < 4 {
		return false
	}

	return flag[0] == UrdSpectrumEndFlag[0] && flag[1] == UrdSpectrumEndFlag[1] && flag[2] == UrdSpectrumEndFlag[2] && flag[3] == UrdSpectrumEndFlag[3]
}

func checkUrdSpectrumDataFlag(flag []byte) bool {
	if len(flag) < 4 {
		return false
	}
	return flag[0] == UrdSpectrumDataFlag[0] && flag[1] == UrdSpectrumDataFlag[1] && flag[2] == UrdSpectrumDataFlag[2] && flag[3] == UrdSpectrumDataFlag[3]
}

// UrdSpectrum 频谱数据
type UrdSpectrum struct {
	Header [4]byte
	Data   [318]UrdSpectrumData
	Footer [4]byte
}

// UrdSpectrumData 频谱数据
type UrdSpectrumData struct {
	Header    [4]byte
	Reserved  [25]byte
	Length    int32
	Reserved2 [4]byte
	Data      [1163]byte
}

// UrdSpectrumReport 频谱数据上报
type UrdSpectrumReport struct {
	X []int32
	Y []int32
}

func getUrdSpectrumDataLength(data []byte) int32 {
	if len(data) != 4 {
		return 0
	}
	return int32(data[0]) | (int32(data[1]) << 8) | (int32(data[2]) << 16) | (int32(data[3]) << 24)
}

// StartUrdSpectrumTCPConnection 启动urd360频谱数据TCP连接
func StartUrdSpectrumTCPConnection(ip string, port int, sn string) error {
	addr := fmt.Sprintf("%s:%d", ip, port)
	conn, err := net.Dial("tcp", addr)
	if err != nil {
		return errors.New("连接失败： " + err.Error())
	}

	go handleUrdSpectrumConnection(conn, sn)
	return nil
}

// StopUrdSpectrumTCPConnection 停止urd360频谱数据TCP连接
func StopUrdSpectrumTCPConnection(sn string) error {
	conn, ok := getUrdSpectrumConnection(sn)
	if !ok {
		return errors.New("连接不存在")
	}
	conn.Close()
	return nil
}

// handleUrdSpectrumConnection 处理urd360频谱数据TCP连接
func handleUrdSpectrumConnection(conn net.Conn, sn string) {
	defer conn.Close()

	// 存储连接
	setUrdSpectrumConnection(sn, conn)
	defer deleteUrdSpectrumConnection(sn)
	logger.Infof("urd spectrum conn receive start: %s", conn.RemoteAddr())

	// 创建缓冲区接收数据
	packet := NewUrd360SpectrumPacket()
	ch := make(chan Packet, 1)
	defer close(ch)
	go func() {
		for {
			select {
			case c, ok := <-ch:
				if !ok {
					// 通道关闭，退出
					return
				}
				// 检查设备是否禁用
				if !checkDeviceEnable(sn) {
					logger.Warnf("urd device is disabled: %s", sn)
					continue
				}
				// 处理数据
				if !checkUrdSpectrumDataFlag(c.Data[:4]) {
					logger.Warnf("urd spectrum data flag is not correct: %s", sn)
					return
				}
				var spectrum UrdSpectrumReport
				for i := 0; i < c.Length; i++ {
					spectrum.X = append(spectrum.X, int32(c.Index))
					spectrum.Y = append(spectrum.Y, int32(c.Data[37+i]-180))
					c.Index += 18750
				}
				// 上报数据
				logger.Infof("urd spectrum data x: %#v", spectrum.X)
				logger.Infof("urd spectrum data y: %#v", spectrum.Y)
				msg := common.EquipmentMessageBoxEntity{
					Name:      getRemoteIP(conn),
					Sn:        sn,
					MsgType:   UrdSpectrumType,
					EquipType: int(common.DEV_URD360),
					Info:      spectrum,
				}
				_ = mq.RFURDBroker.Publish(mq.RFURD360SpecturmTopic, broker.NewMessage(msg))
			}
		}
	}()

	// 创建缓冲区读取数据
	data := make([]byte, 2048)
	for {
		// 接收数据
		n, err := conn.Read(data)
		if err != nil {
			if err == io.EOF {
				logger.Warn("urd spectrum conn receive close:", conn.RemoteAddr())
			} else {
				logger.Error("urd spectrum conn receive err:", err)
			}
			return
		}
		if n <= 0 {
			continue
		}
		// 处理数据
		packet.PacketHandler(data[:n], ch)
	}
}
