package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"fmt"
	"math/rand"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

/*
CMD状态： -> cmd -> -100：定时一直产生假数据

				   -200：关闭定时产生的假数据
				   cmd>0: 产生的假数据量
	deviceType: 设备类型
	msgType : 消息类型
*/
const (
	LoopInfin = -100
	Stop      = -200
)

const (
	urdsn = "URDsn"
)

var rg = rand.New(rand.NewSource(time.Now().UnixNano()))

// GenFakeDataLogic
func GenFakeDataLogic(req *client.GenFakeReq, resp *client.GenFakeDataResp) {
	respUtil := make([]*client.GenFakeDataRespUtil, 0)

	var sn string
	sleeps := make([]*client.GenFakeTimeUtil, 0)
	for _, u := range req.Util {
		fmt.Println(u)
		tstart := time.Now().UnixMilli()
		ststart := time.Now().Format("2006-01-02 15:04:05")
		switch u.Cmd {
		case LoopInfin:
			fmt.Println("loop gen")
		case Stop:
			fmt.Println("loop stop ")
		default:
			if u.Cmd <= 0 {
				return
			}
			switch common.DeviceType(u.DeviceType) {
			case common.DEV_URD360:
				fmt.Println("")
				switch u.MsgType {
				case UrdDeviceInfoType:
					sn, sleeps = genUrdHeartData(u.Cmd)
				case UrdDroneInfoType:
					sn, sleeps = genUrdDronData(u.Cmd)
				case UrdSpectrumType:
					sn, sleeps = genspectrumData(u.Cmd)
				}

			default:
				fmt.Println("unknow device")
			}

		}
		tend := time.Now().UnixMilli()
		stend := time.Now().Format("2006-01-02 15:04:05")
		totalTime := client.GenFakeTimeUtil{
			StartTime: fmt.Sprintf("%d__%s", tstart, ststart),
			EndTime:   fmt.Sprintf("%d__%s", tend, stend),
		}
		respUtil = append(respUtil, &client.GenFakeDataRespUtil{
			Sn:            sn,
			DeviceType:    u.DeviceType,
			MsgType:       u.MsgType,
			Totaltime:     &totalTime,
			SleepDuration: sleeps,
		})
	}
	resp.Util = respUtil
}

func forceRandSleep() *client.GenFakeTimeUtil {
	r := rg.Intn(10)
	if r > 5 {
		tstart := time.Now().UnixMilli()
		ststart := time.Now().Format("2006-01-02 15:04:05")
		time.Sleep(time.Duration(r) * time.Second)
		tend := time.Now().UnixMilli()
		stend := time.Now().Format("2006-01-02 15:04:05")
		DurationTime := client.GenFakeTimeUtil{
			StartTime: fmt.Sprintf("%d__%s", tstart, ststart),
			EndTime:   fmt.Sprintf("%d__%s", tend, stend),
		}
		return &DurationTime
	}
	time.Sleep(time.Duration(r) * time.Second)
	return nil
}

func genspectrumData(num int32) (string, []*client.GenFakeTimeUtil) {
	DurationTimes := make([]*client.GenFakeTimeUtil, 0)
	for i := int32(0); i < num; i++ {
		var spectrum UrdSpectrumReport
		var xx, yy []int32
		for i := 0; i < 4; i++ {
			xx = append(xx, rg.Int31())
			yy = append(yy, rg.Int31())
		}

		spectrum.X = xx
		spectrum.Y = yy

		msg := common.EquipmentMessageBoxEntity{
			Name:      "spectName",
			Sn:        urdsn,
			MsgType:   UrdSpectrumType,
			EquipType: int(common.DEV_URD360),
			Info:      spectrum,
		}
		logger.Infof("urd spectrum info: %+v", msg)
		sleepTime := forceRandSleep()
		if sleepTime != nil {
			DurationTimes = append(DurationTimes, sleepTime)
		}
		_ = mq.RFURDBroker.Publish(mq.RFURD360SpecturmTopic, broker.NewMessage(msg))
	}
	return urdsn, DurationTimes
}

func genUrdDronData(num int32) (string, []*client.GenFakeTimeUtil) {
	DurationTimes := make([]*client.GenFakeTimeUtil, 0)
	for i := int32(0); i < num; i++ {
		msg := common.EquipmentMessageBoxEntity{
			Name:      "urddrone",
			Sn:        urdsn,
			MsgType:   UrdDroneInfoType,
			EquipType: int(common.DEV_URD360),
			Info: UrdDroneInfoUpload{
				Id:               12345,
				UniqueId:         "uniqueid..",
				TargetInfoLength: rg.Int31(),
				TargetInfo:       "TargetInfo...",
				StationId:        rg.Int31(),
				TargetAzimuth:    rg.Int31(),
				TargetRange:      rg.Int31(),
				Longitude:        rg.Float32(),
				Latitude:         rg.Float32(),
				Height:           rg.Int31(),
				Frequency:        rg.ExpFloat64(),
				Bandwidth:        rg.ExpFloat64(),
				SignalStrength:   rg.ExpFloat64(),
				Trust:            int8(rg.ExpFloat64()),
				Time:             "time...",
				DataType:         int8(rg.ExpFloat64()),
				Modulation:       int8(rg.ExpFloat64()),
			},
		}
		logger.Infof("urd drone info: %+v", msg)
		sleepTime := forceRandSleep()
		if sleepTime != nil {
			DurationTimes = append(DurationTimes, sleepTime)
		}
		_ = mq.RFURDBroker.Publish(mq.RFURD360DroneInfoTopic, broker.NewMessage(msg))
	}
	return urdsn, DurationTimes
}

func genUrdHeartData(num int32) (string, []*client.GenFakeTimeUtil) {

	// sn := strconv.FormatInt(tn, 10)
	DurationTimes := make([]*client.GenFakeTimeUtil, 0)
	for i := int32(0); i < num; i++ {
		msg := common.EquipmentMessageBoxEntity{
			Name:      "urd360Heart",
			Sn:        urdsn,
			MsgType:   UrdDeviceInfoType,
			EquipType: int(common.DEV_URD360),
			Info: UrdDeviceInfoUpload{
				Id:                12345,
				Name:              "apple",
				Longitude:         rg.Float32(),
				Latitude:          rg.Float32(),
				Height:            rg.Int31(),
				Status:            int16(rg.Float64()),
				Azimuth:           rg.Int31(),
				Type:              rg.Int31(),
				CompassStatus:     int8(rg.ExpFloat64()),
				GpsStatus:         int8(rg.ExpFloat64()),
				ReceiverStatus:    int8(rg.ExpFloat64()),
				AntennaStatus:     int8(rg.ExpFloat64()),
				AntennaCoverRange: rg.Int31(),
			},
		}
		logger.Infof("urd device heart info: %+v", msg)
		sleepTime := forceRandSleep()
		if sleepTime != nil {
			DurationTimes = append(DurationTimes, sleepTime)
		}
		_ = mq.RFURDBroker.Publish(mq.RFURD360StatusTopic, broker.NewMessage(msg))
	}
	return urdsn, DurationTimes
}
