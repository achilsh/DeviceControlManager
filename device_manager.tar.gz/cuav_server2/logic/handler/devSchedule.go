package handler

import (
	"context"
	"errors"
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"gorm.io/gorm"
)

type DeviceSchedule struct {
}

func NewDevSchedule() *DeviceSchedule {
	return &DeviceSchedule{}
}
func (w *DeviceSchedule) Insert(ctx context.Context, req *client.DevScheduleInsertReq, res *client.DevScheduleInsertRsp) error {
	var model bean.DevSchedule

	logger.Info("Into Insert DevSchedule")
	model.Sn = req.Sn
	model.Date = req.Date
	model.Information = req.Information

	var devSchedule bean.DevSchedule
	if err := db.GetDB().Model(&bean.DevSchedule{}).Where("date = ? and sn = ?", req.Date, req.Sn).First(&devSchedule).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			if err := db.GetDB().Model(&bean.DevSchedule{}).Create(&model).Error; err != nil {
				logger.Errorf("create DevSchedule error: %v", err)
				return err
			}
			return nil
		}
		logger.Errorf("query DevSchedule error:", err)
		return err
	}

	return nil
}
func (w *DeviceSchedule) Update(ctx context.Context, req *client.DevScheduleUpdateReq, rsp *client.DevScheduleUpdateRsp) error {
	var model bean.DevSchedule

	model.Sn = req.Sn
	model.Date = req.Date
	model.Information = req.Information

	err := db.GetDB().Model(&bean.DevSchedule{}).Where("date = ? and sn = ?", req.Date, req.Sn).Updates(&model).Error
	if err != nil {
		return fmt.Errorf("update DevSchedule error: Date=%v  Sn=%v no-exist", req.Date, req.Sn)
	}

	return nil
}

func (w *DeviceSchedule) Deletes(ctx context.Context, req *client.DevScheduleDeletesReq, rsp *client.DevScheduleDeletesRsp) error {
	var model bean.DevSchedule
	err := db.GetDB().Model(&bean.DevSchedule{}).Where("sn = ?", req.Sn).Delete(&model).Error
	if err != nil {
		logger.Errorf("delete DevSchedule error: %v", err)
	}

	return nil
}

func (w *DeviceSchedule) List(ctx context.Context, req *client.DevScheduleListReq, rsp *client.DevScheduleListRsp) error {
	var list []*bean.DevSchedule
	err := db.GetDB().Model(&bean.DevSchedule{}).Where("sn = ?", req.Sn).Find(&list).Error
	if err != nil {
		return errors.New("query DevSchedule failed")
	}
	for _, v := range list {
		var model client.DevScheduleList
		w.generateRes(&model, *v)
		rsp.DevScheduleList = append(rsp.DevScheduleList, &model)
	}
	return nil
}
func (w *DeviceSchedule) generateRes(model *client.DevScheduleList, list bean.DevSchedule) {
	model.Sn = list.Sn
	model.Date = list.Date
	model.Information = list.Information

}
