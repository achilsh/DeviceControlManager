package handler

import (
	"context"
	"errors"
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"gorm.io/gorm"
)

type Nsf4000 struct {
}

func NewNsf4000() *Nsf4000 {
	return &Nsf4000{}
}
func (w *Nsf4000) InsertAndUpdate(ctx context.Context, req *client.Nsf4000InsertAndUpdateReq, res *client.Nsf4000InsertAndUpdateRsp) error {
	var model bean.Nsf4000Config
	model.Sn = req.Sn
	model.Power = req.Power
	model.DefenseLevelSpeed = req.DefenseLevelSpeed
	model.DefenseVerticalSpeed = req.DefenseVerticalSpeed
	model.Height = req.Height
	model.Latitude = req.Latitude
	model.Longitude = req.Longitude
	model.DriveLevelSpeed = req.DriveLevelSpeed
	model.DriveVerticalSpeed = req.DriveVerticalSpeed
	model.DefenseLongitude = req.DefenseLongitude
	model.DefenseLatitude = req.DefenseLatitude
	model.AreaStopLongitude = req.AreaStopLongitude
	model.AreaStopLatitude = req.AreaStopLatitude

	// check sn
	logger.Info("Into  Insert And Update Nsf4000:", model)
	var Nsf4000Config bean.Nsf4000Config
	if err := db.GetDB().Model(&bean.Nsf4000Config{}).Where("sn = ?", req.Sn).First(&Nsf4000Config).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			if err := db.GetDB().Model(&bean.Nsf4000Config{}).Create(&model).Error; err != nil {
				logger.Errorf("create Nsf4000 config error: %v", err)
				return err
			}
			return nil
		}
		logger.Errorf("query Nsf4000 config error:", err)
		return err
	}
	//update
	err := db.GetDB().Model(&bean.Nsf4000Config{}).
		Where("sn = ?", req.Sn).Updates(map[string]interface{}{
		"radius":                 req.Radius,
		"power":                  req.Power,
		"defense_level_speed":    req.DefenseLevelSpeed,
		"defense_vertical_speed": req.DefenseVerticalSpeed,
		"longitude":              req.Longitude,
		"latitude":               req.Latitude,
		"height":                 req.Height,
		"drive_level_speed":      req.DriveLevelSpeed,
		"drive_vertical_speed":   req.DriveVerticalSpeed,
		"defense_longitude":      req.DefenseLongitude,
		"defense_latitude":       req.DefenseLatitude,
		"area_stop_longitude":    req.AreaStopLongitude,
		"area_stop_latitude":     req.AreaStopLatitude,
	}).Error
	logger.Errorf("nsf err:", err)
	if err != nil {
		// check if record exists
		var count int64
		if err := db.GetDB().Model(&bean.Nsf4000Config{}).Where("sn = ?", req.Sn).Count(&count).Error; err != nil {
			logger.Errorf("query Nsf4000 config error:", err)
			return err
		}
		logger.Errorf("count : %v", count)
		if count == 0 {
			// create new record
			if err := db.GetDB().Model(&bean.Nsf4000Config{}).Create(&model).Error; err != nil {
				logger.Errorf("create Nsf4000 config error: %v", err)
				return err
			}
		} else {
			return fmt.Errorf("update Nsf4000 config error: sn=%v no-exist", req.Sn)
		}
	}
	return nil
}

func (w *Nsf4000) Delete(_ context.Context, sn string) error {
	e := db.GetDB().Where("sn = ?", sn).Delete(&bean.Nsf4000Config{}).Error
	if e != nil {
		logger.Errorf("delete nsf config from tab: nsf4000_config fail, e: %v", e)
		return e
	}
	logger.Infof("delete nsf4000 config item, for sn: %v", sn)
	return nil
}

func (w *Nsf4000) List(ctx context.Context, req *client.Nsf4000ListReq, rsp *client.Nsf4000ListRsp) error {
	var list []*bean.Nsf4000Config
	err := db.GetDB().Model(&bean.Nsf4000Config{}).Find(&list).Error
	if err != nil {
		return errors.New("query list failed")
	}
	for _, v := range list {
		var model client.NsfList
		w.generateRes(&model, *v)
		rsp.ConfigList = append(rsp.ConfigList, &model)
	}
	return nil
}
func (w *Nsf4000) generateRes(model *client.NsfList, list bean.Nsf4000Config) {
	model.Id = list.Id
	model.Sn = list.Sn
	model.Radius = list.Radius
	model.Power = list.Power
	model.DefenseLevelSpeed = list.DefenseLevelSpeed
	model.DefenseVerticalSpeed = list.DefenseVerticalSpeed
	model.Longitude = list.Longitude
	model.Latitude = list.Latitude
	model.Height = list.Height
	model.DriveLevelSpeed = list.DriveLevelSpeed
	model.DriveVerticalSpeed = list.DriveVerticalSpeed
	model.DefenseLongitude = list.DefenseLongitude
	model.DefenseLatitude = list.DefenseLatitude
	model.AreaStopLongitude = list.AreaStopLongitude
	model.AreaStopLatitude = list.AreaStopLatitude
}
