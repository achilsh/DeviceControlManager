package handler

import (
	"context"
	"errors"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
)

type Role struct {
}

func NewRole() *Role {
	return &Role{}
}

func (r *Role) GetRoles(ctx context.Context, req *client.ListReq, res *client.ListRes) error {
	var roles []bean.Role
	err := db.GetDB().Model(&bean.Role{}).Find(&roles).Error
	if err != nil {
		return errors.New("query list failed")
	}
	for _, v := range roles {
		var model client.Role
		r.generateRes(&model, &v)
		res.Roles = append(res.Roles, &model)
	}
	return nil
}

func (r *Role) GetRolesByIds(ctx context.Context, req *client.RoleIds, res *client.GetRolesRes) error {
	var roles []bean.Role
	err := db.GetDB().Model(&client.Role{}).Where("id in ?", req.Ids).Find(&roles).Error
	if err != nil {
		return err
	}
	for _, v := range roles {
		var model client.Role
		r.generateRes(&model, &v)
		res.Roles = append(res.Roles, &model)
	}
	return nil
}

func (r *Role) CreateRole(ctx context.Context, req *client.CreateReq, res *client.CreateRes) error {
	var model bean.Role
	model.Id = int(req.Id)
	model.Name = req.Name
	model.CrtTime = req.CrtTime
	model.UpdateTime = req.UpdateTime
	model.Status = int(req.Status)
	model.Remark = req.Remark
	err := db.GetDB().Model(&bean.Role{}).Create(&model).Error
	if err != nil {
		return err
	}
	return nil
}

func (r *Role) UpdateRole(ctx context.Context, req *client.UpdateRoleReq, res *client.UpdateRoleRes) error {
	err := db.GetDB().Model(&client.Role{}).Where("id = ?", req.Id).Updates(req).Error
	if err != nil {
		return err
	}
	return nil
}

func (r *Role) BatchDeleteRoleByIds(ctx context.Context, req *client.RoleIds, res *client.DeleteRes) error {
	err := db.GetDB().Model(&client.Role{}).Delete(&client.Role{}, &req.Ids).Error
	if err != nil {
		return err
	}
	return nil
}

func (r *Role) generateRes(model *client.Role, req *bean.Role) {
	model.Id = int64(req.Id)
	model.Name = req.Name
	model.Status = int32(req.Status)
	model.CrtTime = req.CrtTime
	model.UpdateTime = req.UpdateTime
	model.Remark = req.Remark
}
