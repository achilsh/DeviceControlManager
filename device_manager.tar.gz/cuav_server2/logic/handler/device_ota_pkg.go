package handler

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/awsS3"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ota"
	utils "adasgitlab.autel.com/tools/cuav_server/entity/utils/panic"
)

// DownloadOtaPkg 异步下载ota固件升级包
func (e *DeviceCenter) DownloadOtaPkg(ctx context.Context, req *client.DownloadOtaPkgRequest, rsp *client.DownloadOtaPkgResponse) error {
	logger.Info("DownloadOtaPkg req: ", req)
	defer utils.HandlePanic()
	filePath := ota.LocalOtaPkgPathMap[req.DeviceType]
	if filePath == "" {
		return errors.New("未知设备类型")
	}
	if req.PkgPath == "" {
		req.PkgPath = ota.DefaultOtaPkgPath
	}
	filePath = filepath.Join(req.PkgPath, filePath)
	logger.Info("DownloadOtaPkg filePath: ", filePath)
	_, fileName := filepath.Split(req.FileKey)
	if err := os.MkdirAll(filePath, 0666); err != nil {
		logger.Error("DownloadOtaPkg failed to os.Create, %v \n", err)
	}
	fn, ok := OtaDownloadCancelMap[fileName]
	if ok {
		fn()
		delete(OtaDownloadCancelMap, fileName)
		return nil
	}
	downloadCtx, cancelFunc := context.WithCancel(context.Background())
	logger.Info("DownloadOtaPkg fileName", fileName)
	OtaDownloadCancelMap[fileName] = cancelFunc // 保存用于通知取消的cancel方法
	go e.downloadOtaPkg(downloadCtx, req, filepath.Join(filePath, fileName))
	rsp.Status = 0

	return nil
}

// downloadOtaPkg 下载ota固件升级包
func (e *DeviceCenter) downloadOtaPkg(ctx context.Context, req *client.DownloadOtaPkgRequest, filePathName string) {
	defer utils.HandlePanic()
	logger.Info("downloadOtaPkg Start")
	f, err := os.Create(filePathName)
	if err != nil {
		logger.Errorf("failed to create download file %v", err)
		return
	}
	defer f.Close()

	// 开启协websocket同步下载状态
	_, cacheKey := filepath.Split(filePathName)
	UpdateDownLoadPkgStatus(cacheKey, &OtaFileDownloadStatus{
		Status:               Downloading,
		DownloadedPercentage: 0,
		FileName:             cacheKey,
		ErrMsg:               "",
	})
	//go OtaSyncProgress(WsOtaPkgDownloadStatus, "", cacheKey, cacheKey)
	go OtaSyncDownLoadPkgStatus(cacheKey)

	// 下载并写入文件
	e.downloadAndWriteFile(req.TestSet, f, req.FileKey, cacheKey, filePathName, "", 0, -1, ctx)
}

// PauseDownloadOtaPkg 暂停下载ota固件升级包
func (e *DeviceCenter) PauseDownloadOtaPkg(ctx context.Context, req *client.PauseDownloadOtaRequest, rsp *client.PauseDownloadOtaResponse) error {
	_, fileName := filepath.Split(req.FileKey)
	// 获取通知停止下载的cancel方法进行调用
	cancelFun, ok := OtaDownloadCancelMap[fileName]
	if !ok {
		rsp.Status = 1
		return nil
	}
	cancelFun()
	rsp.Status = 0
	return nil
}

// ContinueDownloadOtaPkg 继续下载ota固件升级包
func (e *DeviceCenter) ContinueDownloadOtaPkg(ctx context.Context, req *client.ContinueDownloadOtaRequest, rsp *client.ContinueDownloadOtaResponse) error {
	defer utils.HandlePanic()
	filePath := ota.LocalOtaPkgPathMap[req.DeviceType]
	if filePath == "" {
		return errors.New("未知设备类型")
	}
	if req.PkgPath == "" {
		req.PkgPath = ota.DefaultOtaPkgPath
	}
	filePath = filepath.Join(req.PkgPath, filePath)
	_, fileName := filepath.Split(req.FileKey)
	fallPath := filepath.Join(filePath, fileName)
	fn, ok := OtaDownloadCancelMap[fileName]
	if ok {
		fn()
		delete(OtaDownloadCancelMap, fileName)
		return nil
	}
	downloadCtx, cancelFunc := context.WithCancel(context.Background())
	OtaDownloadCancelMap[fileName] = cancelFunc // 保存用于通知取消的cancel方法
	// 定位继续下载的文件位置
	exist, _ := ota.PathOrFileExists(fallPath)
	if !exist {
		fallPath = strings.TrimSuffix(fallPath, filepath.Ext(fallPath)) + DownloadFiledSuffix
		FieldExist, _ := ota.PathOrFileExists(fallPath)
		if !FieldExist {
			// 都不存在则重新下载
			go e.downloadOtaPkg(downloadCtx, &client.DownloadOtaPkgRequest{
				FileKey:    req.FileKey,
				DeviceType: req.DeviceType,
				PkgPath:    req.PkgPath,
			}, filepath.Join(filePath, fileName))
			return nil
		}
	}
	go e.continueDownloadOtaPkg(downloadCtx, fallPath, req.FileKey, req.TestSet)
	rsp.Status = 0
	return nil
}

// continueDownloadOtaPkg 异步继续下载ota固件升级包
func (e *DeviceCenter) continueDownloadOtaPkg(ctx context.Context, fallPath, fileKey string, testEnv int32) {
	defer utils.HandlePanic()
	logger.Info("continueDownloadOtaPkg Start")
	_, fileName := filepath.Split(fileKey)
	cloudPkg, ok := ota.GetCloudOtaFilePackage(fileName)
	if !ok {
		logger.Error("not found")
		return
	}
	// 计算已下载文件的大小占云端文件的百分比
	fileInfo, _ := os.Stat(fallPath)
	offset := fileInfo.Size()
	totalSize := cloudPkg.FileSize
	if offset == int64(totalSize) {
		// 文件已下载完成
		return
	}
	permil := 1000 * int(offset) / totalSize
	UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
		Status:               Downloading,
		DownloadedPercentage: permil,
		FileName:             fileName,
		ErrMsg:               "",
	})
	// 开启协程与前端同步进度
	go OtaSyncDownLoadPkgStatus(fileName)
	// 下载的字节范围
	rangeHeader := fmt.Sprintf("bytes=%d-%d", offset, cloudPkg.FileSize-1)
	// 打开文件
	writer, _ := os.OpenFile(fallPath, os.O_APPEND|os.O_WRONLY, 0644)
	defer writer.Close()
	// 下载并写入文件
	e.downloadAndWriteFile(testEnv, writer, fileKey, fileName, fallPath, rangeHeader, offset, totalSize, ctx)
}

// downloadAndWriteFile 下载并写入文件
func (e *DeviceCenter) downloadAndWriteFile(testEnv int32, f *os.File,
	fileKey, fileName, fallPath, rangeHeader string,
	offset int64, totalSize int,
	ctx context.Context,
) {
	defer utils.HandlePanic()
	// 获取零时下载地址
	url := ota.CloudOtaDownloadPreSignUrl
	if testEnv == 1 {
		url = ota.TestCloudOtaDownloadPreSignUrl
	}
	preSignRsp, err := ota.GetOtaPreSignDownloadUrl(url, fileKey, rangeHeader)
	if err != nil {
		logger.Errorf("continueDownloadOtaPkg ota.GetOtaPreSignDownloadUrl:%v \n", err)
		UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
			Status:               DownloadField,
			DownloadedPercentage: 0,
			FileName:             fileName,
			ErrMsg:               err.Error(),
			FallPath:             fallPath,
		})
		return
	}

	logger.Infof("continueDownloadOtaPkg preSignRsp.Url:%s \n", preSignRsp.URL)
	// 下载升级包
	httpReq, _ := http.NewRequest(preSignRsp.Method, preSignRsp.URL, nil)
	for k, vs := range preSignRsp.Header {
		for _, v := range vs {
			httpReq.Header.Add(k, v)
		}
	}
	client := &http.Client{}
	otaRsp, err := client.Do(httpReq)

	if totalSize == -1 {
		totalSize = int(otaRsp.ContentLength)
	}
	defer otaRsp.Body.Close()
	buf := make([]byte, 10240)
	if err != nil {
		logger.Errorf("continueDownloadOtaPkg failed client.Get, %d:%s", otaRsp.StatusCode, otaRsp.Status)
		UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
			Status:               DownloadField,
			DownloadedPercentage: 0,
			FileName:             fileName,
			ErrMsg:               err.Error(),
			FallPath:             fallPath,
		})
		return
	}
	for {
		select {
		case <-ctx.Done():
			logger.Info("continueDownloadOtaPkg 下载被暂停")
			percent := 1000 * int(offset) / totalSize
			UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
				Status:               DownloadPause,
				DownloadedPercentage: percent,
				FileName:             fileName,
				ErrMsg:               "暂停",
				FallPath:             fallPath,
			})
			return
		default:
			cancel := time.AfterFunc(time.Second*4, func() {
				// 超过4秒没有读取到字节则关闭Body退出
				logger.Info("downloadAndWriteFile time out AfterFunc")
				_ = otaRsp.Body.Close()
			})
			n, err := otaRsp.Body.Read(buf)
			cancel.Stop()
			if n == 0 {
				if err != nil && err != io.EOF {
					percent := 1000 * int(offset) / totalSize
					UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
						Status:               DownloadNetworkErr,
						DownloadedPercentage: percent,
						FileName:             fileName,
						ErrMsg:               err.Error(),
						FallPath:             fallPath,
					})
					logger.Info("downloadAndWriteFile Body.Read err: ", err)
					return
				}
				UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
					Status:               DownloadDone,
					DownloadedPercentage: 1000,
					FileName:             fileName,
					ErrMsg:               "",
					FallPath:             fallPath,
				})
				return
			}
			if err != nil && err != io.EOF {
				// 读取报错更新状态
				UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
					Status:               DownloadField,
					DownloadedPercentage: 0,
					FileName:             fileName,
					ErrMsg:               "读取下载文件数据报错",
					FallPath:             fallPath,
				})
				return
			}
			buf2 := buf[:n]
			// 写入文件
			_, err = f.Write(buf2)
			if err != nil {
				// 写入报错更新状态
				UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
					Status:               DownloadField,
					DownloadedPercentage: 0,
					FileName:             fileName,
					ErrMsg:               "写入本地文件报错",
					FallPath:             fallPath,
				})
				return
			}
			offset += int64(n)
			// 更新状态
			percent := 1000 * int(offset) / totalSize
			// 更新状态
			if percent%10 == 0 { //进度条整数上报
				UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
					Status:               Downloading,
					DownloadedPercentage: percent,
					FileName:             fileName,
					ErrMsg:               "",
				})
			}
		}
	}
}

// GetLocalOtaPkgList 获取本地ota固件升级包列表
func (e *DeviceCenter) GetLocalOtaPkgList(ctx context.Context, req *client.GetOtaPkgListRequest, rsp *client.GetOtaPkgListResponse) error {
	logger.Debug("--->into GetLocalOta List req:", req)
	defer utils.HandlePanic()
	rsp.Status = 0
	rsp.OtaPkgList = make([]*client.OtaPkgInfo, 0)
	if req.PkgPath == "" {
		req.PkgPath = ota.DefaultOtaPkgPath
	}
	// 先查看一下是否有缓存列表
	if len(ota.CloudOtaFileMap) == 0 {
		_, _ = ota.GetOtaCloudFileList(0, req.TestSet)
	}
	if req.DeviceType == 0 {
		// 获取所有的ota升级包
		for deviceType, pkgPath := range ota.LocalOtaPkgPathMap {
			pkgList := ota.GetLocalOtaPkgInfo(filepath.Join(req.PkgPath, pkgPath), deviceType, req.PkgPath)
			if pkgList != nil {
				rsp.OtaPkgList = append(rsp.OtaPkgList, pkgList...)
			}
		}

		logger.Debug("--->End GetLocalOta List Type 0 req:", rsp.OtaPkgList)
		return nil
	} else {
		// 查询具体类型的升级包
		filePath := ota.LocalOtaPkgPathMap[req.DeviceType]
		if filePath != "" {
			rsp.OtaPkgList = ota.GetLocalOtaPkgInfo(filepath.Join(req.PkgPath, filePath), req.DeviceType, req.PkgPath)
		}
		logger.Debug("--->End GetLocalOta List req:", rsp.OtaPkgList)
		return nil
	}

}

// GetCloudOtaPkgList 获取云端ota固件升级包列表
func (e *DeviceCenter) GetCloudOtaPkgList(ctx context.Context, req *client.GetOtaPkgListRequest, rsp *client.GetOtaPkgListResponse) error {
	defer utils.HandlePanic()
	logger.Info("get cloud pkg list:", req)
	// 获取S3ota升级包列表
	result, err := ota.GetOtaCloudFileList(req.DeviceType, req.TestSet)
	if err != nil {
		return err
	}

	var upgradeList *awsS3.TracerUpgradeInfo
	upgradeList, err = awsS3.GetTracerUpgradeJson(req.DeviceType, req.PkgPath)

	rsp.Status = 0
	// 返回文件列表
	rsp.OtaPkgList = make([]*client.OtaPkgInfo, 0)
	for _, otaPackage := range result.List {
		upgradeInfo, upgradeInfoChinese, upgradeInfoEnglish, upgradeInfoRussian := "", "", "", ""
		if upgradeList != nil {
			for _, list := range upgradeList.List {
				if otaPackage.Version == list.Version {
					upgradeInfo = list.UpgradeDesc
					upgradeInfoChinese = list.UpgradeDescChinese
					upgradeInfoEnglish = list.UpgradeDescEnglish
					upgradeInfoRussian = list.UpgradeDescRussian
				}
			}
		}
		rsp.OtaPkgList = append(rsp.OtaPkgList, &client.OtaPkgInfo{
			FileName:           otaPackage.FileName,
			DeviceType:         int32(otaPackage.DeviceType),
			Version:            otaPackage.Version,
			ModTime:            otaPackage.UpdatedAt.String(),
			FileKey:            otaPackage.FileKey,
			IsLatest:           otaPackage.IsLatest == 1,
			UpgradeInfo:        upgradeInfo,
			UpgradeInfoChinese: upgradeInfoChinese,
			UpgradeInfoEnglish: upgradeInfoEnglish,
			UpgradeInfoRussian: upgradeInfoRussian,
		})

	}
	for devType, pkgPath := range ota.LocalOtaPkgPathMap {
		ota.DelLocalOtaPkgInfo(filepath.Join(req.PkgPath, pkgPath), rsp.OtaPkgList, devType)
	}
	logger.Info(" --->End get cloud pkg list:", rsp.OtaPkgList)
	return nil
}

// GetUpgradeStatus 获取固件升级状态
func (e *DeviceCenter) GetUpgradeStatus(ctx context.Context, req *client.GetUpgradeStatusRequest, rsp *client.GetUpgradeStatusResponse) error {
	cacheKey := ""
	if req.DeviceType == ota.DeviceTypeRadar {
		cacheKey = fmt.Sprintf("%d_%s", common.DEV_RADAR, req.Sn)
	} else if req.DeviceType == ota.DeviceTypeGun {
		cacheKey = fmt.Sprintf("%d_%s", common.DEV_SCREEN, req.Sn)
	}
	logger.Info(cacheKey)
	return nil
}

// CheckPkgIsLatest 检查升级包版本是否为最新
func (e *DeviceCenter) CheckPkgIsLatest(ctx context.Context, req *client.CheckPkgIsLatestRequest, rsp *client.CheckPkgIsLatestResponse) error {
	// 根据设备类型查询出最新的版本号
	pkg, err := ota.GetLatestPkg(req.DeviceType)
	if err != nil {
		return err
	}
	rsp.LatestVersion = pkg.Version
	rsp.IsLatest = req.Version == pkg.Version
	return nil
}

// CheckLatestPkgExist 检查本地是否有最新版本升级包
func (e *DeviceCenter) CheckLatestPkgExist(ctx context.Context, req *client.CheckLatestPkgExistRequest, rsp *client.CheckLatestPkgExistResponse) error {
	filePath := ota.LocalOtaPkgPathMap[req.DeviceType]
	if filePath == "" {
		return errors.New("设备类型有误")
	}
	// 根据设备类型查询出最新的版本号
	pkg, err := ota.GetLatestPkg(req.DeviceType)
	if err != nil {
		return err
	}

	rsp.LatestVersion = pkg.Version
	rsp.Exist = ota.CheckVersionExist(filepath.Join(req.PkgPath, filePath), pkg.Version)

	return nil
}

// GetLatestVersion 根据设备类型获取最新的ota升级包版本
func (e *DeviceCenter) GetLatestVersion(ctx context.Context, req *client.GetLatestVersionRequest, rsp *client.GetLatestVersionResponse) error {
	// 查询最新版本信息
	pkg, err := ota.GetLatestPkg(req.DeviceType)
	if err != nil || pkg == nil {
		rsp.LatestVersion = ""
		return nil
	}

	rsp.LatestVersion = pkg.Version
	return nil
}

// GetLatestFileName 根据设备类型获取最新的ota升级包文件名
func (e *DeviceCenter) GetLatestFileName(ctx context.Context, req *client.GetLatestFileNameRequest, rsp *client.GetLatestFileNameResponse) error {
	// 查询最新版本信息
	pkg, err := ota.GetLatestPkg(req.DeviceType)
	if err != nil || pkg == nil {
		rsp.LatestFileName = ""
		return nil
	}

	rsp.LatestFileName = pkg.FileName
	return nil
}
