package handler

import (
	"context"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"github.com/agiledragon/gomonkey"
)

func TestDeviceCenter_DownloadOtaPkg(t *testing.T) {
	test.LoggerMock()
	type args struct {
		ctx context.Context
		req *client.DownloadOtaPkgRequest
		rsp *client.DownloadOtaPkgResponse
	}
	tests := []struct {
		name    string
		e       *DeviceCenter
		args    args
		wantErr bool
	}{
		{
			name: "Case1",
			e:    &DeviceCenter{},
			args: args{
				ctx: context.Background(),
				req: &client.DownloadOtaPkgRequest{
					DeviceType: 1,
				},
				rsp: &client.DownloadOtaPkgResponse{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &DeviceCenter{}
			if err := e.DownloadOtaPkg(tt.args.ctx, tt.args.req, tt.args.rsp); (err != nil) != tt.wantErr {
				t.Errorf("DeviceCenter.DownloadOtaPkg() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestDeviceCenter_downloadOtaPkg(t *testing.T) {
	test.LoggerMock()

	patches := gomonkey.NewPatches()
	patches.ApplyFunc(OtaSyncDownLoadPkgStatus, func(key string) {
		return
	})
	defer patches.Reset()

	type args struct {
		req          *client.DownloadOtaPkgRequest
		filePathName string
		ctx          context.Context
	}
	tests := []struct {
		name string
		e    *DeviceCenter
		args args
	}{
		{
			name: "Case1",
			e:    &DeviceCenter{},
			args: args{
				req: &client.DownloadOtaPkgRequest{
					DeviceType: 1,
				},
				filePathName: "/tmp/ota_test",
				ctx:          context.Background(),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &DeviceCenter{}
			e.downloadOtaPkg(tt.args.ctx, tt.args.req, tt.args.filePathName)
		})
	}
}

func TestDeviceCenter_ContinueDownloadOtaPkg(t *testing.T) {
	test.LoggerMock()
	patches := gomonkey.NewPatches()
	patches.ApplyFunc(OtaSyncDownLoadPkgStatus, func(string) {})
	patches.Reset()

	type args struct {
		ctx context.Context
		req *client.ContinueDownloadOtaRequest
		rsp *client.ContinueDownloadOtaResponse
	}
	tests := []struct {
		name    string
		e       *DeviceCenter
		args    args
		wantErr bool
	}{
		{
			name: "Case1",
			e:    &DeviceCenter{},
			args: args{
				ctx: context.Background(),
				req: &client.ContinueDownloadOtaRequest{
					DeviceType: 1,
				},
				rsp: &client.ContinueDownloadOtaResponse{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &DeviceCenter{}
			if err := e.ContinueDownloadOtaPkg(tt.args.ctx, tt.args.req, tt.args.rsp); (err != nil) != tt.wantErr {
				t.Errorf("DeviceCenter.ContinueDownloadOtaPkg() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestDeviceCenter_continueDownloadOtaPkg(t *testing.T) {
	test.LoggerMock()
	patches := gomonkey.NewPatches()
	patches.ApplyFunc(OtaSyncDownLoadPkgStatus, func(string) {})
	patches.Reset()

	type args struct {
		fallPath string
		fileKey  string
		testSet  int32
		ctx      context.Context
	}
	tests := []struct {
		name string
		e    *DeviceCenter
		args args
	}{
		{
			name: "Case1",
			e:    &DeviceCenter{},
			args: args{
				fallPath: "",
				fileKey:  "",
				testSet:  0,
				ctx:      context.Background(),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &DeviceCenter{}
			e.continueDownloadOtaPkg(tt.args.ctx, tt.args.fallPath, tt.args.fileKey, tt.args.testSet)
		})
	}
}

func TestDeviceCenter_GetLocalOtaPkgList(t *testing.T) {
	type args struct {
		ctx context.Context
		req *client.GetOtaPkgListRequest
		rsp *client.GetOtaPkgListResponse
	}
	tests := []struct {
		name    string
		e       *DeviceCenter
		args    args
		wantErr bool
	}{
		{
			name: "Case1",
			e:    &DeviceCenter{},
			args: args{
				ctx: context.Background(),
				req: &client.GetOtaPkgListRequest{
					DeviceType: 1,
				},
				rsp: &client.GetOtaPkgListResponse{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &DeviceCenter{}
			if err := e.GetLocalOtaPkgList(tt.args.ctx, tt.args.req, tt.args.rsp); (err != nil) != tt.wantErr {
				t.Errorf("DeviceCenter.GetLocalOtaPkgList() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestDeviceCenter_GetCloudOtaPkgList(t *testing.T) {
	type args struct {
		ctx context.Context
		req *client.GetOtaPkgListRequest
		rsp *client.GetOtaPkgListResponse
	}
	tests := []struct {
		name    string
		e       *DeviceCenter
		args    args
		wantErr bool
	}{
		{
			name: "Case1",
			e:    &DeviceCenter{},
			args: args{
				ctx: context.Background(),
				req: &client.GetOtaPkgListRequest{
					DeviceType: 1,
				},
				rsp: &client.GetOtaPkgListResponse{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &DeviceCenter{}
			if err := e.GetCloudOtaPkgList(tt.args.ctx, tt.args.req, tt.args.rsp); (err != nil) != tt.wantErr {
				t.Errorf("DeviceCenter.GetCloudOtaPkgList() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
