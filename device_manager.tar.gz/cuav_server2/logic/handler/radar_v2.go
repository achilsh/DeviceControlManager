package handler

import (
	"context"
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/repo/cache"
	"adasgitlab.autel.com/tools/cuav_server/rpc/devicerpc"
)

// SetBeamScheduling 设置波束范围
func (d *Radar) SetBeamScheduling(sn string, req *bizproto.RadarSetBeamSchedulingReq) (*bizproto.RadarSetBeamSchedulingRsp, error) {
	logger.Debugf("SetBeamScheduling request: %+v", req)
	deviceResp, err := devicerpc.CallV2(sn, common.DEV_RADAR, msgid.RadarIdV2SetBeamScheduling, req)
	if err != nil {
		logger.Errorf("SetBeamScheduling rpc callV2 error: %v", err)
		return nil, err
	}
	result, ok := deviceResp.(*bizproto.RadarSetBeamSchedulingRsp)
	if !ok {
		logger.Errorf("SetBeamScheduling convert RadarSetBeamSchedulingRsp error")
		return nil, fmt.Errorf("SetBeamScheduling convert RadarSetBeamSchedulingRsp error")
	}
	// 删除缓存
	if result.Status == 0 {
		cacheKey := fmt.Sprintf("%s_beam_steer_config", d.Sn)
		_ = cache.Get().Delete(context.Background(), cacheKey)
	}
	logger.Debugf("SetBeamScheduling response: %+v", result)
	return result, nil
}

// SetRadarSetting 设置雷达信息
func (d *Radar) SetRadarSetting(sn string, req *bizproto.RadarSetReq) (*bizproto.RadarSetRsp, error) {
	logger.Debugf("SetRadarSetting request: %+v", req)
	deviceResp, err := devicerpc.CallV2(sn, common.DEV_RADAR, msgid.RadarIdV2SetSetting, req)
	if err != nil {
		logger.Errorf("SetRadarSetting rpc callV2 error: %v", err)
		return nil, err
	}
	result, ok := deviceResp.(*bizproto.RadarSetRsp)
	if !ok {
		logger.Errorf("SetRadarSetting convert RadarSetRsp error")
		return nil, fmt.Errorf("SetRadarSetting convert RadarSetRsp error")
	}
	logger.Debugf("SetRadarSetting response: %+v", result)
	return result, nil
}

// SetRadarAttitudeLLA 设置雷达姿态
func (d *Radar) SetRadarAttitudeLLA(sn string, req *bizproto.RadarSetAttitudeLLAReq) (*bizproto.RadarSetAttitudeLLARsp, error) {
	logger.Debugf("SetRadarAttitudeLLA request: %+v", req)
	deviceResp, err := devicerpc.CallV2(sn, common.DEV_RADAR, msgid.RadarIdV2SetAttitudeLLA, req)
	if err != nil {
		logger.Errorf("SetRadarAttitudeLLA rpc callV2 error: %v", err)
		return nil, err
	}
	result, ok := deviceResp.(*bizproto.RadarSetAttitudeLLARsp)
	if !ok {
		logger.Errorf("SetRadarAttitudeLLA convert RadarSetAttitudeLLARsp error")
		return nil, fmt.Errorf("SetRadarAttitudeLLA convert RadarSetAttitudeLLARsp error")
	}
	logger.Debugf("SetRadarAttitudeLLA response: %+v", result)
	return result, nil
}

// GetVersionInfo 获取雷达版本信息, TODO: req is pb struct
func (d *Radar) GetVersionInfo(sn string, req any) (uint32, string, string, string, string, error) {
	// TODO: cmd is 0
	deviceResp, err := devicerpc.CallV2(sn, common.DEV_RADAR, 0, req)
	if err != nil {
		logger.Errorf("GetVersionInfo rpc callV2 error: %v", err)
		return 0, "", "", "", "", err
	}

	// TODO: RadarSetAttitudeLLARsp
	_, ok := deviceResp.(*bizproto.RadarSetAttitudeLLARsp)
	if !ok {
		logger.Errorf("GetVersionInfo convert RadarSetAttitudeLLARsp error")
		return 0, "", "", "", "", fmt.Errorf("GetVersionInfo convert RadarSetAttitudeLLARsp error")
	}
	return 0, "", "", "", "", nil
}
