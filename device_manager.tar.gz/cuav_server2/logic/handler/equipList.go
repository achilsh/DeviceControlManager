package handler

import (
	"context"
	"errors"
	"strconv"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"gorm.io/gorm"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
)

type EquipList struct {
}

func NewEquipList() *EquipList {
	return &EquipList{}
}

func (c *EquipList) UpdateSomeFields(ctx context.Context, in *client.UpdateCondReq, out *client.UpdateCondRsp) error {
	if in == nil {
		return errors.New("input param is nil")
	}
	if err := db.GetDB().Model(&bean.EquipList{}).Where("sn=?", in.Sn).Update("etype", in.Etype).Error; err != nil {
		logger.Errorf("update table equip_list etype to: %v fail, sn: %v, err: %v", in.Sn, in.Etype, err)
		return err
	}
	return nil
}

func (c *EquipList) Insert(ctx context.Context, req *client.EquipCrudReq, res *client.EquipCrudRes) error {
	var model bean.EquipList
	err := db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", req.Sn).First(&model).Error
	if err == nil {
		logger.Error("record already exists:", req.Sn)
		return nil
	}
	if err == gorm.ErrRecordNotFound {
		c.generate(&model, req)
		err := db.GetDB().Model(&bean.EquipList{}).Create(&model).Error
		if err != nil {
			logger.Errorf("create equip list  error:%v", err)
			return err
		}
		return nil
	}
	return err
}

func (c *EquipList) Update(ctx context.Context, req *client.EquipCrudReq, res *client.EquipCrudRes) error {
	var model bean.EquipList
	err := db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", req.Sn).Error
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			return errors.New("record does not exist")
		}
	}
	c.generate(&model, req)
	err = db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", req.Sn).Updates(&model).Error
	if err != nil {
		logger.Errorf("update failed,error:%v", err)
		return err
	}
	return nil
}
func (c *EquipList) FindByIds(_ context.Context, req *client.EquipDeleteReq, res *[]*bean.EquipList) error {
	var list []*bean.EquipList
	err := db.GetDB().Model(&bean.EquipList{}).Find(&list, req.Ids).Error
	if err != nil {
		logger.Errorf("find equipment list fail, e: %v", err)
		return err
	}
	*res = list
	return nil
}

func (c *EquipList) InsetBackUp(ctx context.Context, req *bean.EquipList, res *client.CrudRes) error {
	var model bean.EquipListBackUp

	model.Id = int(req.Id)
	model.Reverse = req.Reverse
	model.TerminalId = req.TerminalId
	model.Etype = req.Etype
	model.TcpPort = int(req.TcpPort)
	model.UdpPort = int(req.UdpPort)
	model.Ip = req.Ip
	if req.CrtTime == "" {
		model.CrtTime = utils.ParseTimeToString(time.Now())
	} else {
		model.CrtTime = req.CrtTime
	}
	model.Status = req.Status
	if req.UpdateTime == "" {
		model.UpdateTime = utils.ParseTimeToString(time.Now())
	} else {
		model.UpdateTime = req.UpdateTime
	}
	model.Name = req.Name
	model.Content = req.Content
	model.SubType = req.SubType
	model.LocalIp = req.LocalIp
	model.LocalUdpPort = int(req.LocalUdpPort)
	model.Sn = req.Sn

	model.IsEnable = req.IsEnable

	err := db.GetDB().Model(&bean.EquipListBackUp{}).Create(&model).Error
	if err != nil {
		logger.Errorf("create equip list backup  error:%v", err)
		return err
	}
	return err
}
func (c *EquipList) InsertOrUpdateBackupTab(ctx context.Context, req []*bean.EquipList) error {
	utils.CheckAndCreateTab[bean.EquipListBackUp](db.GetDB(), bean.EquipListBackUp{}.TableName(), &bean.EquipListBackUp{}, 0)

	for _, item := range req {
		if item == nil {
			continue
		}
		var dst bean.EquipListBackUp
		err := db.GetDB().Model(&bean.EquipListBackUp{}).Where("sn = ?", item.Sn).First(&dst).Error
		if err != nil && errors.Is(err, gorm.ErrRecordNotFound) {
			c.InsetBackUp(ctx, item, nil)

		} else if err == nil {
			logger.Infof("sn: %v has exist in tab: %v, need to update", item.Sn, dst.TableName())

		} else {
			logger.Errorf("find item fail, e: %v, sn: %v", err, item.Sn)
		}
	}
	return nil
}

func (c *EquipList) Delete(ctx context.Context, req *client.EquipDeleteReq, res *client.EquipCrudRes) error {
	err := db.GetDB().Delete(&bean.EquipList{}, &req.Ids).Error
	if err != nil {
		logger.Errorf("delete equip list error:", err)
		return err
	}
	return nil
}
func (c *EquipList) DeleteWithSn(ctx context.Context, req *client.DeleteWithSnReq, res *client.EquipCrudRes) error {
	err := db.GetDB().Delete(&bean.EquipList{}).Where("sn = ?", &req.Sn).Error
	if err != nil {
		logger.Errorf("delete equip with sn list error:", err)
		return err
	}
	return nil
}

func (c *EquipList) List(ctx context.Context, req *client.EquipListReq, res *client.EquipListRes) error {
	var list []*bean.EquipList
	err := db.GetDB().Model(&bean.EquipList{}).Find(&list).Error
	if err != nil {
		return errors.New("query list failed")
	}
	for _, v := range list {
		var model client.List
		c.generateRes(&model, *v)
		if v.Sn == "" {
			continue
		}
		res.Equips = append(res.Equips, &model)
	}
	return nil
}

func (c *EquipList) SetEnableState(ctx context.Context, req *client.SetEnableReq, res *client.SetEnableRes) error {
	var model bean.EquipList
	if req.Sn == "" {
		return nil
	}
	err := db.GetDB().Where("sn = ?", req.Sn).First(&model).Error
	if err != nil {
		if err != gorm.ErrRecordNotFound {
			return err
		}
	}
	if err == gorm.ErrRecordNotFound {
		err := db.GetDB().Create(&bean.EquipList{
			Sn:       req.Sn,
			IsEnable: int(req.Status),
			Etype:    req.EType,
		}).Error
		if err != nil {
			logger.Errorf("SetEnableState create equip list  error:%v", err)
			return err
		}
	} else {
		model.IsEnable = int(req.Status)
		err = db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", req.Sn).Updates(&model).Error
		if err != nil {
			logger.Errorf("SetEnableState failed,error:%v", err)
			return err
		}
	}
	res.Status = 1
	return nil
}

func (c *EquipList) GetSourceId(ctx context.Context, req *client.GetSourceIdReq, res *client.GetSourceIdRes) error {
	var model bean.EquipSourceId
	if req.Sn == "" {
		return errors.New("sn is nil")
	}
	var err error
	if err = db.GetDB().Where("sn = ?", req.Sn).Last(&model).Error; err != nil && err != gorm.ErrRecordNotFound {
		return err
	}
	//不存在要判断当前最大的sourceId，然后加1
	if err == gorm.ErrRecordNotFound && req.Sn != "" {
		for i := 1; i < 16; i++ {
			var checkModel bean.EquipSourceId
			sourceId := int32(i<<4) + req.DevType
			if err = db.GetDB().Where("source_id = ?", sourceId).Last(&checkModel).Error; err != nil && err == gorm.ErrRecordNotFound {
				es := &bean.EquipSourceId{
					Sn:       req.Sn,
					SourceId: sourceId,
				}
				if err = db.GetDB().Create(es).Error; err != nil {
					logger.Errorf("GetSourceId create sourceId error:%v", err)
					return err
				}
				res.SourceId = sourceId
				res.Sn = req.Sn
				return nil
			}
		}
		return errors.New("sourceId 不足")
	}
	res.Sn = model.Sn
	res.SourceId = model.SourceId
	return nil
}

func (c *EquipList) GetSnBySourceId(ctx context.Context, req *client.GetSnBySourceIdReq, res *client.GetSnBySourceIdRes) error {
	var model bean.EquipSourceId
	err := db.GetDB().Where("source_id = ?", req.SourceId).Last(&model).Error
	if err != nil {
		return err
	}
	res.Sn = model.Sn
	res.SourceId = model.SourceId
	return nil
}

func (c *EquipList) GetStatus(ctx context.Context, req *client.GetStatusReq, res *client.GetStatusRes) error {
	var model bean.EquipList
	err := db.GetDB().Where("sn = ?", req.Sn).Last(&model).Error
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			res.IsEnable = common.DeviceEnable
			res.IsOnline = 2
			res.IsAllow = 1
			//前端组网成功前，不需要添加设备，只有获取信道的时候，不存在设备时添加
			if req.EType != "" {
				if err := db.GetDB().Create(&bean.EquipList{
					Sn:       req.Sn,
					IsEnable: common.DeviceEnable,
					IsOnline: 2,
					Etype:    req.EType,
				}).Error; err != nil {
					logger.Errorf("GetStatus create equip list  error:%v", err)
					return nil
				}
			}
			return nil
		}
		return err
	}
	res.Sn = model.Sn
	res.Name = model.Name
	res.IsEnable = int32(model.IsEnable)
	res.IsOnline = int32(model.IsOnline)
	if model.IsEnable == common.DeviceDisenable || model.IsOnline == 1 {
		res.IsAllow = 2
	} else {
		res.IsAllow = 1
	}
	return nil
}
func (c *EquipList) GetStatusNotCreat(ctx context.Context, req *client.GetStatusReq, res *client.GetStatusRes) error {
	var model bean.EquipList
	err := db.GetDB().Where("sn = ?", req.Sn).Last(&model).Error
	if err != nil {
		logger.Errorf("sn not exit:%v", req.Sn)
		return err
	}
	res.Sn = model.Sn
	res.Name = model.Name
	res.IsEnable = int32(model.IsEnable)
	res.IsOnline = int32(model.IsOnline)
	if model.IsEnable == common.DeviceDisenable || model.IsOnline == 1 {
		res.IsAllow = 2
	} else {
		res.IsAllow = 1
	}
	return nil
}

func (c *EquipList) generate(model *bean.EquipList, req *client.EquipCrudReq) {
	model.Id = int(req.Id)
	model.Reverse = req.Reverse
	model.TerminalId = req.TerminalId
	model.Etype = req.Etype
	model.TcpPort = int(req.TcpPort)
	model.UdpPort = int(req.UdpPort)
	model.Ip = req.Ip
	if req.CrtTime == "" {
		model.CrtTime = utils.ParseTimeToString(time.Now())
	} else {
		model.CrtTime = req.CrtTime
	}
	model.Status = strconv.Itoa(int(req.Status))
	if req.UpdateTime == "" {
		model.UpdateTime = utils.ParseTimeToString(time.Now())
	} else {
		model.UpdateTime = req.UpdateTime
	}
	model.Name = req.Name
	model.Content = req.Content
	model.SubType = req.SubType
	model.LocalIp = req.LocalIp
	model.LocalUdpPort = int(req.LocalUdpPort)
	model.Sn = req.Sn
	if req.IsEnable {
		model.IsEnable = common.DeviceEnable
	}
	model.DevVersion = req.DevVersion

}

func (c *EquipList) generateRes(model *client.List, list bean.EquipList) {
	model.Id = int64(list.Id)
	model.Reverse = list.Reverse
	model.TerminalId = list.TerminalId
	model.Etype = list.Etype
	model.TcpPort = int64(list.TcpPort)
	model.UdpPort = int64(list.UdpPort)
	model.Ip = list.Ip
	status, _ := strconv.Atoi(list.Status)
	model.Status = int32(status)
	model.UpdateTime = list.UpdateTime
	model.Name = list.Name
	model.Content = list.Content
	model.SubType = list.SubType
	model.LocalIp = list.LocalIp
	model.LocalUdpPort = int32(list.LocalUdpPort)
	model.Sn = list.Sn
	model.IsEnable = int32(list.IsEnable)
	model.RadarRelevance = int32(list.RadarRelevance)
	model.DevVersion = list.DevVersion
}

func (c *EquipList) DelSpooferDevice(ctx context.Context, req *client.DelSpooferDeviceReq, res *client.DelSpooferDeviceRes) error {
	err := db.GetDB().Delete(&bean.EquipList{}, "etype = ?", req.Etype).Error
	if err != nil {
		logger.Errorf("delete equip list error:", err)
		return err
	}
	return nil
}

func (c *EquipList) UpdateRadarStatus(ctx context.Context, req *client.UpdateRadarStatusReq, res *client.UpdateRadarStatusRes) error {
	logger.Info("Update Radar Status:", req)
	err := db.GetDB().Model(&bean.EquipList{}).Where(true).Update("radar_relevance", 0).Error
	if err != nil {
		logger.Errorf("update All failed, error: %v", err)
		return err
	}
	for _, devInfo := range req.List {
		err = db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", devInfo.Sn).Update("radar_relevance", 1).Error
		if err != nil {
			logger.Errorf("update radar failed,error:%v", err)
			return err
		}
	}
	return nil
}
