package handler

import (
	"time"

	"go-micro.dev/v4"
	"go-micro.dev/v4/client"
)

var (
	DbSvcName = "dbSvc"

	Opts = func(ops *client.CallOptions) {
		ops.RequestTimeout = time.Second * 30
		ops.DialTimeout = time.Second * 30
	}
)

var ()

func InitMicroClient(srv micro.Service) {
}
