package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/rpc/connmgr"
	"adasgitlab.autel.com/tools/cuav_server/rpc/tcpserver"
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"math/big"
	"os"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	jsoniter "github.com/json-iterator/go"

	common "adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/cache"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

var (
	RadarTcpPort        int64    = 10500
	RadarServerMaxCount int64    = 500
	RadarTcpServerMap   sync.Map //  map[string]*server.TcpServer = make(map[string]*server.TcpServer, 0)
	radarTcpServerLock  sync.Mutex
	radarSendLock       sync.Mutex
	deviceUsedPorts     sync.Map
	//xurong: 删除，每个链接使用私有的，不再用全局 WaitTaskMap          map[int]*WaitTaskManager = make(map[int]*WaitTaskManager, 0)
	RadarReducedValue    uint8   = 64 //2的6次方,雷达上报数值扩大值
	RadarGetSystemSn     uint8   = 1
	RadarPostureReduce   float64 = 32768.00 //2的15次方
	RadarPostureReduce20 float64 = 1000000.00
	RadarPostureReduce7  float64 = 128.00 //2的7次方
	receiveLimitRate     int64   = 60
)

type Radar struct {
	*Device
	dt          common.DeviceType
	Electricity uint8 //电量
}

func NewRadar(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager) DeviceInterface {
	radar := &Radar{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
		},
	}
	return radar
}

func (d *Radar) SizeCheck(dataSize int) error {
	if d.MsgLen < mavlink.HeaderLen+dataSize+mavlink.CrcLen {
		err := errors.New("message 长度错误")
		logger.Errorf("size check err:%#v,%#v", dataSize, d.MsgLen)
		return err
	}
	return nil
}

func (d *Radar) Deal() {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("radar deal 接收到panic:", err)
		}
	}()

	if d.MsgLen <= 0 {
		logger.Error("数据为null,不作处理:", d.Device.RemoteIp)
		return
	}
	//也可以用map的写法
	d.MsgId = int(d.Msg[mavlink.MsgIdLoc])
	switch d.MsgId {
	case mavlink.RadarIdHeartbeat: //解析心跳包
		d.UpdateStatus()
		d.Heart()
		break
	case mavlink.RadarIdSetSystemStatus:
		d.ReceiveSetSystemStatusResponse()
		break
	case mavlink.RadarIdGetSystemInfo:
		d.ReceiveGetSystemInfoResponse()
		break
	case mavlink.RadarIdSetSn:
		d.ReceiveSetSnResponse()
		break
	case mavlink.RadarIdGetCryptKey:
		d.ReceiveCryptKey()
		break
	case mavlink.RadarIdSetWifiDisConn:
		d.ReceiveSetWifiDisConn()
		break
	case mavlink.RadarIdUploadWifiStatus:
		d.ReceiveWifiStatus()
		break
	case mavlink.RadarIdRequestWifiChannel, mavlink.V2RadarIdRequestWifiChannel:
		d.ReceiveGetChannelReq()
		break
	case mavlink.RadarIdUploadDetectInfo:
		d.UpdateStatus()

		break
	case mavlink.RadarIdSetUploadMode:
		d.ReceiveSetUploadMode()
		break
	case mavlink.RadarIdUploadTrackInfo:
		d.UpdateStatus()
		d.ReceiveTrackInfo()
		break
	case mavlink.RadarIdUploadControlInfo:
		d.UpdateStatus()
		break
	case mavlink.RadarIdUploadPosture:
		d.UpdateStatus()
		d.ReceivePostureInfo()
		break
	case mavlink.RadarIdGetBeamSteerInfo:
		d.ReceiveBeamSteerConfig()
		break
	case mavlink.RadarIdStartDetect:
		d.ReceiveStartDetect()
		break
	case mavlink.RadarIdEndDetect:
		d.ReceiveEndDetect()
		break
	case mavlink.RadarIdSetBeamPos:
		d.ReceiveSetBeamPos()
		break
	case mavlink.RadarIdSetBeamSize:
		d.ReceiveSetBeamSize()
		break
	case mavlink.RadarIdPostureCalibration:
		d.ReceivePostureCalibration()
		break
	case mavlink.RadarIdPostureCalibrationResult:
		d.ReceivePostureCalibrationResult()
		break
	case mavlink.RadarIdPostureCalibrationManual:
		d.ReceivePostureCalibrationManual()
		break
	case mavlink.RadarIdGetVersionInfo:
		d.ReceiveGetVersionInfo()
		break
	case mavlink.RadarGetLogList:
		d.ReceiveGetLogList()
		break
	case mavlink.RadarGetLog:
		d.ReceiveGetLog()
		break
	case mavlink.RadarDeleteLog:
		d.ReceiveDelLog()
		break

	case mavlink.RadarIdResetSystem:
		// 系统复位
		d.ReceiveRadarResetSystem()
		break
	case mavlink.RadarIdGetUpdateWriteStatus:
		// 获取固件写入状态
		d.ReceiveRadarGetUpdateWriteStatus()
		break
	case mavlink.RadarIdRequestUpgrade:
		// 请求固件升级
		d.ReceiveRadarRequestUpgrade()
		break
	case mavlink.RadarIdSendUpdatePkg:
		d.ReceiveRadarSendUpdatePkg()
		break
	case mavlink.RadarIdVerifyImage:
		// 校验固件镜像
		d.ReceiveRadarVerifyImage()
		break
	case mavlink.RadarIdGetTimeoutRetryTime:
		// 获取运行超时重试时间
		d.ReceiveRadarGetUpdateTimeoutRetryTime()
		break
	case mavlink.RadarIdRunApp:
		// 获取运行超时重试时间
		d.ReceiveRadarRunApp()
		break
	case mavlink.RadarIdWriteUpdateData:
		// 获取运行超时重试时间
		d.ReceiveRadarWriteUpdateData()
		break
	default:
		logger.Error("未知雷达消息id:", d.MsgId)
		break
	}
}

func (d *Radar) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok && (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}

// 缓存conn 获取信道、重连后的后必须更新
func (d *Radar) cacheConn(sn string) string {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_RADAR, sn)
	cache, ok := DevStatusMap.Load(cacheKey)
	if !ok {
		//如果不存在则根据消息id创建一个,这里不做保持，在心跳那里保存
		dev := &Device{
			Sn:             sn,
			Conn:           d.Conn,
			Status:         common.DevOffline,
			RemoteIp:       d.RemoteIp,
			RemotePort:     d.RemotePort,
			LocalIp:        d.LocalIp,
			ServerPort:     d.ServerPort,
			DevType:        common.DEV_RADAR,
			FirstHeartTime: time.Now(),
			LastHeartTime:  time.Now(),
			SourceId:       uint8(common.DEV_RADAR), //d.SourceId,
			IsEnable:       d.IsEnable,
			WaitTaskMap:    d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		return sn
	}
	if d.WaitTaskMap != nil && d.Conn != nil {
		dev := cache.(*Device)
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.IsEnable = d.IsEnable
	}
	return sn
}

// 更新连接和在线状态
func (d *Radar) UpdateStatus() {
	sn := d.getSn(d.Msg[mavlink.SenderLoc])
	if sn == "" {
		logger.Error("更新雷达在线状态获取sn为空:", d.RemoteIp)
		return
	}
	d.Sn = sn
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_RADAR, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.LastHeartTime = time.Now()
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		return
	}
}

// UpdateConn 更新连接
func (d *Radar) UpdateConn(tcpServer *server.TcpServer) {
	for {
		if tcpServer.Status == server.TcpServerNormal {
			select {
			case serverCon := <-tcpServer.ConnCh:
				logger.Debugf("UpdateConn serverCon %v", serverCon.Conn)
				d.Conn = serverCon.Conn
				remoteAddr := strings.Split(serverCon.Conn.RemoteAddr().String(), ":")
				var mailBox map[int]*WaitTaskManager
				mbox, ok := GWaitTaskMap.Load(remoteAddr[0])
				if !ok {
					mailBox = make(map[int]*WaitTaskManager)
					GWaitTaskMap.Store(remoteAddr[0], mailBox)
				} else {
					mailBox = mbox.(map[int]*WaitTaskManager)
				}
				d.WaitTaskMap = mailBox
				d.cacheConn(serverCon.DevSn)

			case <-tcpServer.Ctx.Done():
				return
			}
		}
	}
}

func (d *Radar) Heart() {
	heart := &mavlink.RadarHeartbeat{}
	d.GetPacket(heart)
	devSn := d.getSn(d.Msg[mavlink.SenderLoc])
	logger.Info("接收到雷达心跳包：", heart, devSn)
	report := &common.RadarStatusEntity{}
	report.Faults = make([]string, 0)
	if heart.FaultNum > 0 {
		hLen := int(heart.Size())
		faults := heart.GetFaultMsg(d.Msg[mavlink.HeaderLen+hLen : len(d.Msg)-mavlink.CrcLen])
		logger.Info("心跳包上报错误：", faults)
		report.Faults = faults
	}
	report.SerialNum = devSn
	report.Electricity = int32(heart.Electricity)
	report.Status = int(heart.Status)
	report.IsOnline = common.DevOnline
	report.Ip = d.RemoteIp
	dbequips := &client.EquipListRes{}
	err := NewEquipList().List(context.Background(), &client.EquipListReq{}, dbequips)
	if err != nil {
		logger.Info("Get EquipList err: ", err)
	}
	for _, equip := range dbequips.Equips {
		if equip.Sn == report.SerialNum {
			report.Ip = equip.Ip
		}
	}
	if devSn == "" {
		logger.Error("radar sn is nil")
		return
	}
	entity := &common.EquipmentMessageBoxEntity{
		Name:      devSn,
		Sn:        devSn,
		MsgType:   mavlink.RadarIdHeartbeat,
		EquipType: int(common.DEV_RADAR),
		Info:      report,
	}
	_ = mq.EquipmentStatusBroker.Publish(mq.EquipmentStatusTopic, broker.NewMessage(entity))
	logger.Info("雷达心跳上报完成：", heart, devSn)
}

// 只适用与固定长度的消息
func (d *Radar) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	logger.Infof("GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("packet binary header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Errorf("%d packet binary msg err: %v", req.Header.MessageID, err)
		return nil
	}
	return req
}

func (d *Radar) SendGetSystemInfo(sn string, dataType uint8) (uint8, string, error) {
	d.MsgId = mavlink.RadarIdGetSystemInfo
	req := &mavlink.RadarGetSystemInfoRequest{
		DataType: dataType,
	}
	buff := req.CreateRadarGetSystemInfo(d.SourceId)
	if buff == nil {
		return 0, "", errors.New("获取系统信息生产发送数据为空")
	}
	n, err := d.Conn.Write(buff)
	if err != nil {
		logger.Error("发送获取系统信息错误：", err)
		return 0, "", err
	}
	logger.Info("发送获取系统信息：", dataType, n)
	waitTaskType := d.MsgId + int(dataType)
	manager, ok := d.WaitTaskMap[waitTaskType]
	if !ok {
		manager = NewWaitTaskManager(waitTaskType, true, 0)
		d.WaitTaskMap[waitTaskType] = manager
	}
	rsp, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 0, "", checkNetConnErr
		}
	}
	result := rsp.(*mavlink.RadarUploadSystemInfo)
	//如果是获取sn
	if dataType == RadarGetSystemSn {
		return result.WorkMode, result.Sn, nil
	}
	return result.WorkMode, strconv.FormatInt(int64(result.Version), 10), nil
}

func (d *Radar) SendSetSystemStatus(sn string, state, workMode uint8) (*mavlink.RadarSetSystemStatusResponse, error) {
	d.MsgId = mavlink.RadarIdSetSystemStatus
	req := &mavlink.RadarSetSystemStatusReq{
		StatusType: state,
		WorkMode:   workMode,
	}
	reqBuff := req.CreateRadarSetSystemStatus(d.SourceId)
	n, err := d.Conn.Write(reqBuff)
	if err != nil {
		logger.Error("发送设置系统状态错误：", err)
		return nil, err
	}
	logger.Info("发送设置系统状态：", state, workMode, n)
	manager, ok := d.WaitTaskMap[d.MsgId]
	if !ok {
		manager = NewWaitTaskManager(d.MsgId, true, 0)
		d.WaitTaskMap[d.MsgId] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	res := result.(*mavlink.RadarSetSystemStatusResponse)
	return res, err
}

func (d *Radar) ReceiveSetSystemStatusResponse() {
	sysStatus := &mavlink.RadarSetSystemStatusResponse{}
	d.GetPacket(sysStatus)
	logger.Info("设置系统状态：", sysStatus.Status)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdSetSystemStatus]
	if ok {
		manager.CompletedTask(sysStatus, nil)
	}
}

func (d *Radar) ReceiveGetSystemInfoResponse() {
	sysInfo := &mavlink.RadarGetSystemInfoResponse{}
	d.GetPacket(sysInfo)
	result := sysInfo.GetSystemInfo()
	logger.Info("获取系统信息：", sysInfo.DataType, result.WorkMode, result.Sn, result.Version)
	waitTaskType := int(mavlink.RadarIdGetSystemInfo + sysInfo.DataType)
	manager, ok := d.WaitTaskMap[waitTaskType]
	if ok {
		manager.CompletedTask(result, nil)
	}
}

func (d *Radar) SendExtHeartbeat() error {
	req := &mavlink.RadarHeartbeatExtRequest{}
	reqBuff := req.CreateRadarHeartbeatExt(d.SourceId)
	if d.Conn != nil {
		n, err := d.Conn.Write(reqBuff)
		logger.Info("c2发送雷达心跳结果：", n, err)
		return err
	}
	return nil
}

func (d *Radar) SendSetSn(sn string) (*mavlink.RadarSetSnResponse, error) {
	req := &mavlink.RadarSetSnRequest{}
	buff := req.CreateRadarSetSn(sn, d.SourceId)
	if err := d.Send(sn, buff); err != nil {
		logger.Info("发送设置sn请求结果：", sn, err)
		return nil, err
	}
	manager, ok := d.WaitTaskMap[mavlink.RadarIdSetSn]
	if !ok {
		manager = NewWaitTaskManager(mavlink.RadarIdSetSn, true, 0)
		d.WaitTaskMap[mavlink.RadarIdSetSn] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	return result.(*mavlink.RadarSetSnResponse), err
}

func (d *Radar) ReceiveSetSnResponse() {
	status := &mavlink.RadarSetSnResponse{}
	d.GetPacket(status)
	logger.Info("设置sn返回结果：", status.Status)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdSetSn]
	if ok {
		manager.CompletedTask(status, nil)
	}
}

func (d *Radar) SendGetCryptKey(sn string) (*mavlink.RadarGetCommSecretResponse, error) {
	req := &mavlink.RadarGetCommSecretRequest{}
	buff := req.CreateRadarGetCommSecret(sn, d.SourceId)
	if len(buff) > 0 {
		err := d.Send(sn, buff)
		logger.Info("发送获取密钥结果：", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.RadarIdGetCryptKey]
	if !ok {
		manager = NewWaitTaskManager(mavlink.RadarIdGetCryptKey, true, 0)
		d.WaitTaskMap[mavlink.RadarIdGetCryptKey] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	return result.(*mavlink.RadarGetCommSecretResponse), nil
}

func (d *Radar) ReceiveCryptKey() {
	crypt := &mavlink.RadarGetCommSecretResponse{}
	d.GetPacket(crypt)
	logger.Info("获取通信密钥结果：", len(crypt.GetSecret()))
	manager, ok := d.WaitTaskMap[mavlink.RadarIdGetCryptKey]
	if ok {
		manager.CompletedTask(crypt, nil)
	}
}

func (d *Radar) SendSetWifiDisConn(sn string) (*mavlink.RadarSetWifiConnResponse, error) {
	_, err := d.SendEndDetect(sn, false)
	d.MsgId = mavlink.RadarIdSetWifiDisConn
	rsp := &mavlink.RadarSetWifiConnResponse{
		Status: 1,
	}
	//关闭等待响应不稳定，不管发送成功与否，都主动关闭连接

	if err = d.Conn.Close(); err != nil {
		logger.Info("主动关闭雷达信息错误", err)
		return rsp, err
	}
	logger.Info("主动关闭雷达成功")

	rsp.Status = 0
	d.IsEnable = common.DeviceDisenable

	var tcpServer *server.TcpServer

	//存在且有过连接、开启时间大于50s、连接的设备已经离线时，则关闭连接，剔除缓存
	if s, ok := RadarTcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)
		if true {
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			RadarTcpServerMap.Delete(sn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}
		//往下走直接返回tcpServer,无需再重新构建
	}
	return rsp, nil
}

func (d *Radar) SendSetWifiDisConnNotDetect(sn string) (*mavlink.RadarSetWifiConnResponse, error) {
	d.MsgId = mavlink.RadarIdSetWifiDisConn
	rsp := &mavlink.RadarSetWifiConnResponse{
		Status: 1,
	}
	//关闭等待响应不稳定，不管发送成功与否，都主动关闭连接
	if d.Conn != nil {
		if err := d.Conn.Close(); err != nil {
			logger.Info("主动关闭雷达信息错误", err)
			return rsp, err
		}
	}
	logger.Info("主动关闭雷达成功")

	rsp.Status = 0
	d.IsEnable = common.DeviceDisenable
	var tcpServer *server.TcpServer

	//存在且有过连接、开启时间大于50s、连接的设备已经离线时，则关闭连接，剔除缓存
	if s, ok := RadarTcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)
		if true {
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			RadarTcpServerMap.Delete(sn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}
		//往下走直接返回tcpServer,无需再重新构建
	}
	return rsp, nil
}

func (d *Radar) ReceiveSetWifiDisConn() {
	res := &mavlink.RadarSetWifiConnResponse{}
	d.GetPacket(res)
	logger.Info("设置雷达wifi结果：", res.Status)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdSetWifiDisConn]
	if ok {
		manager.CompletedTask(res, nil)
	}
}

func (d *Radar) ReceiveWifiStatus() {
	res := &mavlink.RadarUploadWifiStatus{}
	d.GetPacket(res)
	logger.Info("雷达上报wifi状态：", res)
}

func (d *Radar) ReceiveGetChannelReq() {
	radarTcpServerLock.Lock()
	defer radarTcpServerLock.Unlock()
	var tcpServer *server.TcpServer
	devSn := d.UnMarshalGetChannelReq()
	logger.Info("ReceiveGetChannelReq devSn: ", devSn)
	if devSn == "" {
		logger.Info("雷达获取信道不能sn为空")
		return
	}
	if status := d.GetStatus(devSn); status == common.DeviceDisenable {
		logger.Infof("device %v disable", devSn)
		return
	}
	localIP := make([]string, 0)

	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("localIP:%v,", localIP)
	tcpServer = d.TcpServerCheck(devSn, localIP)
	//替换新的端口
	DevSnMap.Store(tcpServer.Port, devSn)
	d.ServerPort = tcpServer.Port

	//addr := GetLocalIp(d.RemoteIp)
	var resBuff []byte
	switch d.MsgId {
	case mavlink.V2RadarIdRequestWifiChannel:
		addr := d.LocalIp
		tcpServer.Ip = addr
		res := &mavlink.CommonGetChannelResponse{}
		resBuff = res.CreateGetChannelResponse(d.SourceId, addr, uint16(tcpServer.Port))
		break
	case mavlink.RadarIdRequestWifiChannel:
		addr := d.LocalIp
		tcpServer.Ip = addr
		res := mavlink.RadarGetChannelResponse{}
		resBuff = res.CreateGetChannelResponse(d.SourceId, addr, uint16(tcpServer.Port))
		break
	case mavlink.RadarUdpBroadcastResponse:
		logger.Info("--> receive radar Udp Broadcast Response")
		UdpBroadcastSendChannel(devSn, d.UdpIp, d.SourceId, tcpServer)
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn: devSn,
			Ip: d.UdpIp,
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
			return
		}
		return
	default:
		break
	}
	_, err = d.Conn.Write(resBuff)
	logger.Infof("%d 雷达wifi信道结果：%v", tcpServer.Port, err)
}

func (d *Radar) UnMarshalGetChannelReq() string {
	devSn := ""
	switch d.MsgId {
	case mavlink.V2RadarIdRequestWifiChannel:
		req := &mavlink.CommonGetChannelRequest{}
		d.GetPacket(req)
		devSn = strings.TrimRight(string(req.Sn[:]), string(rune(0)))
		break
	case mavlink.RadarIdRequestWifiChannel:
		req := &mavlink.RadarGetChannelRequest{}
		d.GetPacket(req)
		devSn = req.SnToString()
		break
	case mavlink.RadarUdpBroadcastResponse:
		req := &mavlink.UdpBroadcastConfirmRequest{}
		d.GetPacket(req)
		devSn = strings.TrimRight(string(req.Sn[:]), string(rune(0)))
		break
	default:
		break
	}
	return devSn
}

func (d *Radar) TcpServerCheck(devSn string, localIP []string) *server.TcpServer {
	var tcpServer *server.TcpServer
	//存在且有过连接、开启时间大于50s、连接的设备已经离线时，则关闭连接，剔除缓存
	if s, ok := RadarTcpServerMap.Load(devSn); ok {
		tcpServer = s.(*server.TcpServer)
		isAlike := false
		for _, ip := range localIP {
			if ip == tcpServer.Ip {
				isAlike = true
			}
		}
		if isAlike == false { //查找的本地IP没有与之前相同的
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			RadarTcpServerMap.Delete(devSn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}

		//往下走直接返回tcpServer,无需再重新构建
	}

	if tcpServer == nil {
		localAddr, _ := ip.GetLocalIp(d.UdpIp)
		//注册tcp服务
		port, err := ip.GetFreeTcpPort()
		if err != nil {
			logger.Error("radar tcp 获取可用端口失败：", err)
			port = d.getRandPort(RadarTcpPort, RadarTcpPort+RadarServerMaxCount)
		}
		tcpServer = server.NewTcpServer(port, Handle)
		RadarTcpServerMap.Store(devSn, tcpServer)
		tcpServer.ServerType = uint8(common.DEV_RADAR)
		tcpServer.ServerName = devSn
		tcpServer.Port = port
		tcpServer.Ip = localAddr
		tcpServer.NeedUpdateConn = true
		go tcpServer.Start()
		go d.UpdateConn(tcpServer)
		go func() {
			time.Sleep(time.Second * 2)
			if d.Conn == nil {
				return
			}
			runVer, appVer, bootVer, HwVer, protoVer, err := d.SendGetVersionInfo()
			logger.Infof("radar get  Ver: %v, %v, %v, %v, %v \n",
				runVer, appVer, bootVer, HwVer, protoVer)
			if err != nil {
				logger.Infof("radar get  Ver runVer: %v err: %v \n", runVer, err)
			}
			if appVer != "" {
				err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         devSn,
					DevVersion: appVer,
				}, &client.EquipCrudRes{})
				if err != nil {
					logger.Error("Update EquipList err: ", err)
				}
			}
		}()
	}
	return tcpServer
}

func (d *Radar) ReceiveUploadDetectInfo() {
	req := &mavlink.RadarUploadDetectInfo{}
	d.GetPacket(req)
	detectStart := int(req.Size())
	detects := req.DeserializeDetect(d.Msg[mavlink.HeaderLen+detectStart : d.MsgLen-mavlink.CrcLen])
	logger.Info("雷达上传跟踪检测结果：", req, detects)
	//解析目标
}

func (d *Radar) SendSetUploadMode(sn string, checkType, status, route, cycle uint8) (*mavlink.RadarSetUploadModeResponse, error) {
	d.MsgId = mavlink.RadarIdSetUploadMode
	req := mavlink.RadarSetUploadMode{}
	buff := req.CreateSetUploadMode(d.SourceId, checkType, status, route, cycle)
	if buff != nil && len(buff) > 0 {
		d.Send(sn, buff)
	}
	manager, ok := d.WaitTaskMap[d.MsgId]
	if !ok {
		manager = NewWaitTaskManager(d.MsgId, true, 0)
		d.WaitTaskMap[d.MsgId] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	res := result.(*mavlink.RadarSetUploadModeResponse)
	return res, nil
}

func (d *Radar) ReceiveSetUploadMode() {
	res := &mavlink.RadarSetUploadModeResponse{}
	d.GetPacket(res)
	logger.Info("设置雷达上传模式结果：", res.Status)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdSetUploadMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
}

func (d *Radar) ReceiveTrackInfo() {
	upload := &mavlink.RadarUploadTrackInfo{}
	uploadLen := upload.Size()
	d.GetPacket(upload)
	tracks := upload.DeserializeTrack(d.Msg[mavlink.HeaderLen+uploadLen : d.MsgLen-2])
	logger.Infof("雷达上传跟踪目标结果")
	if len(tracks) <= 0 {
		return
	}
	plotTracks := make([]common.DbRawAutelRadarPlotTrackBodyEntity, 0)
	for i := 0; i < len(tracks); i++ {
		if tracks[i].StateType == 0 {
			continue
		}
		plotTracks = append(plotTracks, common.DbRawAutelRadarPlotTrackBodyEntity{
			Obj_id:         uint32(tracks[i].Id),
			Classification: int16(tracks[i].Classification),
			Ambiguous:      int16(tracks[i].Ambiguous),
			Tws_tas_flag:   uint16(tracks[i].TwsTasFlag),
			Azimuth:        float64(tracks[i].Azimuth) / float64(RadarReducedValue),
			//TRange
			Elevation:         float64(tracks[i].Elevation) / float64(RadarReducedValue),
			Doppler_chn:       tracks[i].DopplerChn,
			Mag:               float64(tracks[i].Mag) / (float64(RadarReducedValue) * 10),
			Velocity:          float64(tracks[i].Velocity) / float64(RadarReducedValue),
			Classfy_prob:      float64(tracks[i].ClassifyProb) / float64(RadarReducedValue),
			ExistingProb:      float32(tracks[i].ExistingProb) / float32(RadarReducedValue),
			Abs_vel:           float64(tracks[i].AbsVel) / float64(RadarReducedValue),
			Orientation_angle: float64(tracks[i].OrientationAngle) / float64(RadarReducedValue),
			Alive:             tracks[i].Alive,
			X:                 float64(tracks[i].X) / float64(RadarReducedValue),
			Y:                 float64(tracks[i].Y) / float64(RadarReducedValue),
			Z:                 float64(tracks[i].Z) / float64(RadarReducedValue),
			VX:                float64(tracks[i].Vx) / float64(RadarReducedValue),
			VY:                float64(tracks[i].Vy) / float64(RadarReducedValue),
			VZ:                float64(tracks[i].Vz) / float64(RadarReducedValue),
			AX:                float64(tracks[i].Ax) / float64(RadarReducedValue),
			AY:                float64(tracks[i].Ay) / float64(RadarReducedValue),
			AZ:                float64(tracks[i].Az) / float64(RadarReducedValue),
			X_variance:        float64(tracks[i].XVariance) / float64(RadarReducedValue),
			Y_variance:        float64(tracks[i].YVariance) / float64(RadarReducedValue),
			Z_variance:        float64(tracks[i].ZVariance) / float64(RadarReducedValue),
			Vx_variance:       float64(tracks[i].VxVariance) / float64(RadarReducedValue),
			Vy_variance:       float64(tracks[i].VyVariance) / float64(RadarReducedValue),
			Vz_variance:       float64(tracks[i].VzVariance) / float64(RadarReducedValue),
			Ax_variance:       float64(tracks[i].AxVariance) / float64(RadarReducedValue),
			Ay_variance:       float64(tracks[i].AyVariance) / float64(RadarReducedValue),
			Az_variance:       float64(tracks[i].AzVariance) / float64(RadarReducedValue),
			Forcast_frame_num: int16(tracks[i].ForcastFrameNum),
			Association_num:   int16(tracks[i].AssociationNum),
			Assoc_bit0:        tracks[i].AssocBit0,
			Assoc_bit1:        tracks[i].AssocBit1,
			State_type:        int16(tracks[i].StateType),
			Motion_type:       int16(tracks[i].MotionType),
		})
	}
	if len(plotTracks) <= 0 {
		return
	}
	atomic.AddInt64(&RadarSpace, 1)
	temp := atomic.LoadInt64(&RadarSpace)
	if temp == 9 {
		atomic.StoreInt64(&RadarSpace, 0)
		logger.Info("Radar detect send ")
	} else {
		logger.Info("Radar detect space ")
		return
	}
	if d.Sn == "" {
		logger.Error("radar sn is nil")
		return
	}
	entity := &common.EquipmentMessageBoxEntity{
		Name:      d.Sn,
		Sn:        d.Sn,
		MsgType:   mavlink.RadarIdUploadTrackInfo,
		EquipType: int(common.DEV_RADAR),
		Info:      plotTracks,
	}
	_ = mq.RadarTrackBroker.Publish(mq.RadarTrackTopic, broker.NewMessage(entity))

	//收到雷达侦测到无人机数据，向数据库记录当天有记录
	_, exist := RadarReplayMap.Get(d.Sn)
	if exist == false {
		RadarReplayMap.Set(d.Sn, d.Sn, true)
		time1 := time.Now()
		resTime := time1.Format("20060102")
		NewDevSchedule().Insert(context.Background(), &client.DevScheduleInsertReq{Sn: d.Sn, Date: resTime, Information: 1}, &client.DevScheduleInsertRsp{})
	}

	logger.Info("雷达跟踪目标上报完成:%v", plotTracks)
}

func (d *Radar) ReceiveControlInfo() {

}

func (d *Radar) ReceivePostureInfo() {
	res := &mavlink.RadarUploadPostureInfo{}
	d.GetPacket(res)
	logger.Infof("雷达上传姿态信息:[%+v]", res)
	if float64(res.Heading)/RadarPostureReduce > HeadingRan {
		logger.Error("雷达姿态异常数据：", d.Msg)
		return
	}
	devSn := d.getSn(d.Msg[mavlink.SenderLoc])
	if devSn == "" {
		logger.Error("radar sn is nil")
		return
	}
	entity := &common.EquipmentMessageBoxEntity{
		Name:      devSn,
		Sn:        devSn,
		MsgType:   int(mavlink.RadarIdUploadPosture),
		EquipType: int(common.DEV_RADAR),
		Info: common.RadarUploadPostureEntity{
			Reserved:            res.Reserved,
			Heading:             float64(res.Heading) / RadarPostureReduce,
			Pitching:            float64(res.Pitching) / RadarPostureReduce,
			Rolling:             float64(res.Rolling) / RadarPostureReduce,
			Longitude:           float64(res.Longitude) / RadarPostureReduce20,
			Latitude:            float64(res.Latitude) / RadarPostureReduce20,
			Altitude:            float64(res.Altitude) / 128.00,     //2的7次方
			VelocityNavi:        float64(res.VelocityNavi) / 128.00, //2的7次方
			SigProcRelativeTime: float64(res.SigProcRelativeTime) / 128.00,
		},
	}
	_ = mq.RadarPostureBroker.Publish(mq.RadarPostureTopic, broker.NewMessage(entity))
	logger.Info("End Receive Posture Info devSn:", devSn)
}

func (d *Radar) SendBeamSteerConfig(sn string) (*mavlink.RadarGetBeamSteerResponse, error) {
	logger.Info("---Into Send Beam Steer Config")
	d.MsgId = mavlink.RadarIdGetBeamSteerInfo
	req := &mavlink.RadarGetBeamSteerRequest{}
	buff := req.CreateGetBeamSteer(d.SourceId)
	_, err := d.Conn.Write(buff)
	if err != nil {
		logger.Error("发送获取波控配置信息失败：", err)
		return nil, err
	}
	manager, ok := d.WaitTaskMap[d.MsgId]
	if !ok {
		manager = NewWaitTaskManager(d.MsgId, true, 0)
		d.WaitTaskMap[d.MsgId] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		logger.Error("获取波控配置信息错误，检测心跳发送：", err)
		return nil, err
	}
	beerConfig := result.(*mavlink.RadarGetBeamSteerResponse)
	//beerConfigArr, _ := jsoniter.Marshal(beerConfig)
	//if err := cache.Get().Put(context.Background(), cacheKey, string(beerConfigArr), time.Minute*10); err != nil {
	//	logger.Error("缓存波控信息异常")
	//}
	logger.Info("---End Send Beam Steer Config")
	ReoprtCloud(sn, beerConfig)
	return beerConfig, nil
}

func ReoprtCloud(sn string, config *mavlink.RadarGetBeamSteerResponse) {
	dataInfo := &client.RadarBeamSteerConfig{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_RADAR),
			MsgType:   mavlink.RadarIdGetBeamSteerInfo,
		},
		Data: &client.RadarUploadBeamConfigEntity{
			AziScanCenter: int32(config.AziScanCenter),
			AziScanScope:  int32(config.AziScanScope),
			EleScanCenter: int32(config.EleScanCenter),
			EleScanScope:  int32(config.EleScanScope),
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDRadarBeamConfigData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.RadarBeamConfigBroker.Publish(mq.RadarBeamConfigTopic, broker.NewMessage(out))

	logger.Infof("Radar Beam has reported, devSn: %v,report:%v", sn, report)
}

func (d *Radar) ReceiveBeamSteerConfig() {
	upload := &mavlink.RadarGetBeamSteerResponse{}
	d.GetPacket(upload)
	logger.Info("接收雷达波控配置信息结果：%+v", upload)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdGetBeamSteerInfo]
	if ok {
		manager.CompletedTask(upload, nil)
	}
	return
}

func (d *Radar) SendStartDetect(sn string) (*mavlink.RadarStartDetectResponse, error) {
	d.MsgId = mavlink.RadarIdStartDetect
	req := &mavlink.RadarStartDetectRequest{}
	buff := req.Create(d.SourceId)
	n, err := d.Conn.Write(buff)
	logger.Info("发送开始探测：", n, err)
	manager, ok := d.WaitTaskMap[d.MsgId]
	logger.Info("发送开始探测buff：", buff)
	if !ok {
		manager = NewWaitTaskManager(d.MsgId, true, time.Second*30)
		d.WaitTaskMap[d.MsgId] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	return result.(*mavlink.RadarStartDetectResponse), nil
}

func (d *Radar) ReceiveStartDetect() {
	upload := &mavlink.RadarStartDetectResponse{}
	d.GetPacket(upload)
	logger.Info("接收雷达开始探测结果：%+v", upload)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdStartDetect]
	if ok {
		manager.CompletedTask(upload, nil)
	}
	return
}

func (d *Radar) SendEndDetect(sn string, isNeedWait bool) (*mavlink.RadarEndDetectResponse, error) {
	d.MsgId = mavlink.RadarIdEndDetect
	req := &mavlink.RadarEndDetectRequest{}
	buff := req.Create(d.SourceId)
	n, err := d.Conn.Write(buff)
	logger.Infof("发送结束探测：%v,%v,%v", buff, n, err)
	if err != nil {
		logger.Error("Send stop Detect fail,err:", err)
	}
	if !isNeedWait {
		return nil, nil
	}
	manager, ok := d.WaitTaskMap[d.MsgId]
	if !ok {
		manager = NewWaitTaskManager(d.MsgId, true, 0)
		d.WaitTaskMap[d.MsgId] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	return result.(*mavlink.RadarEndDetectResponse), nil
}

func (d *Radar) ReceiveEndDetect() {
	upload := &mavlink.RadarEndDetectResponse{}
	d.GetPacket(upload)
	logger.Info("接收雷达结束探测结果：%+v", upload)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdEndDetect]
	if ok {
		manager.CompletedTask(upload, nil)
	}
	return
}

func (d *Radar) SendSetBeamPos() {
	req := &mavlink.RadarSetBeamPosRequest{}
	buff := req.Create(d.SourceId, 12, 66)
	n, err := d.Conn.Write(buff)
	logger.Info("发送雷达设置波控位置：", n, err)
}

func (d *Radar) ReceiveSetBeamPos() {
	upload := &mavlink.RadarSetBeamPosResponse{}
	d.GetPacket(upload)
	logger.Info("接收雷达设置波控位置结果：%+v", upload)
}

func (d *Radar) SendSetBeamSize(sn string, esCenter, esScope, aziCenter, aziScope, waveFrequencyChannel int32) (*mavlink.RadarSetBeamPosResponse, error) {
	d.MsgId = mavlink.RadarIdSetBeamSize
	req := &mavlink.RadarSetBeamSizeRequest{}
	buff := req.Create(d.SourceId, int8(esCenter), int8(aziCenter), uint8(esScope), uint8(aziScope), uint8(waveFrequencyChannel))
	_, err := d.Conn.Write(buff)
	if err != nil {
		logger.Error("发送雷达设置波控范围失败：", err)
		return nil, err
	}
	manager, ok := d.WaitTaskMap[d.MsgId]
	if !ok {
		manager = NewWaitTaskManager(d.MsgId, true, 0)
		d.WaitTaskMap[d.MsgId] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	res := result.(*mavlink.RadarSetBeamPosResponse)
	// 删除缓存
	if res.Status == 0 {
		cacheKey := fmt.Sprintf("%s_beam_steer_config", d.Sn)
		_ = cache.Get().Delete(context.Background(), cacheKey)
	}
	return res, nil
}

func (d *Radar) ReceiveSetBeamSize() {
	upload := &mavlink.RadarSetBeamPosResponse{}
	d.GetPacket(upload)
	logger.Info("接收雷达设置波控范围结果：%+v", upload)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdSetBeamSize]
	if ok {
		manager.CompletedTask(upload, nil)
	}
	return
}

func (d *Radar) CreateSteamSteerData() {
	req := &mavlink.RadarUploadPostureInfo{}
	req.CreateUploadPosture(d.SourceId)
}

func (d *Radar) Send(sn string, reqBuff []byte) error {
	radarSendLock.Lock()
	defer radarSendLock.Unlock()
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_RADAR, sn)
	cache, ok := DevStatusMap.Load(cacheKey)
	if !ok {
		return errors.New("设备未连接")
	}
	dev := cache.(*Device)
	//检查状态
	if dev.Status != common.DevOnline {
		return errors.New("设备离线")
	}
	if _, err := dev.Conn.Write(reqBuff); err != nil {
		return err
	}
	return nil
}

func (d *Radar) GetStatus(sn string) int32 {
	statusRes := &client.GetStatusRes{}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: "radar"}, statusRes)
	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}

	return statusRes.IsEnable
}

func (d *Radar) GetStatusNotCreat(sn string) (bool, error) {
	statusRes := &client.GetStatusRes{}
	err := NewEquipList().GetStatusNotCreat(context.Background(), &client.GetStatusReq{Sn: sn, EType: "radar"}, statusRes)
	if err != nil {
		return false, err
	}
	d.IsEnable = statusRes.IsEnable
	d.cacheConn(sn)
	if d.IsEnable == common.DeviceEnable {
		return true, nil
	}
	return false, nil
}

func (d *Radar) CreateDeviceSourceId(sn string, sourceId int32) (uint8, error) {
	//获取信道的时候，都会更新一遍sn
	res := &client.GetSourceIdRes{}
	err := NewEquipList().GetSourceId(context.Background(), &client.GetSourceIdReq{Sn: sn, DevType: int32(common.DEV_RADAR)}, res)
	if err != nil {
		logger.Error("获取sourceId错误：", err)
		return 0, err
	}
	return uint8(res.SourceId), nil
}

func (d *Radar) getSn(sourceId uint8) string {
	if sn, ok := DevSnMap.Load(d.ServerPort); ok {
		return sn.(string)
	}
	return ""
}

func (d *Radar) LogOperator(req, resp interface{}, err error) {
	reqJson, _ := jsoniter.Marshal(req)
	res := ""
	remark := ""
	if err != nil {
		remark = err.Error()
	}
	if resp != nil {
		resJson, _ := jsoniter.Marshal(resp)
		res = string(resJson)
	}
	msg := common.DeviceEventEntity{
		DeviceType: int(common.DEV_RADAR),
		Sn:         d.Sn,
		MsgId:      uint8(d.MsgId),
		Request:    string(reqJson),
		Response:   res,
		Remark:     remark,
	}
	_ = mq.DeviceCommEventBroker.Publish(mq.DeviceCommEventTopic, broker.NewMessage(common.EquipmentMessageBoxEntity{
		Info: msg,
	}))
}

func SendRadarExtHeart() {
	ticker := time.NewTicker(time.Second * 3)
	defer ticker.Stop()
	for range ticker.C {
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if dev.DevType == common.DEV_RADAR && dev.Status == common.DevOnline {
				reqMode := &Radar{
					Device: dev,
					dt:     common.DEV_RADAR,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}

func RadarOfflineReport(sn, remoteIp string) {
	connmgr.Instance().CloseConn(sn)

	if s := tcpserver.TcpServerMgrInstance().GetServer(sn); s != nil {
		tcpserver.TcpServerMgrInstance().DelServer(sn)
		//必须要先从映射关系中删除服务节点，然后在停掉tcp服务； 如果顺序反了，组网时就再也组网不成功。
		s.Stop()
		cacheRadarKey := fmt.Sprintf("%d_%s", common.DEV_RADAR, sn)
		logger.Infof("del key: %v from devStatusMap", cacheRadarKey)
		DevStatusMap.Delete(cacheRadarKey)
	}

	msg := common.EquipmentStatusEntity{
		Name: sn,
		Sn:   sn,
		Info: common.RadarStatusEntity{
			Electricity: 0,
			Status:      common.DevOffline,
			IsOnline:    common.DevOffline,
			Faults:      make([]string, 0),
			Ip:          remoteIp,
		},
		MsgType:   mavlink.RadarIdHeartbeat,
		EquipType: int(common.DEV_RADAR),
	}
	_ = mq.EquipmentStatusBroker.Publish(mq.EquipmentStatusTopic, broker.NewMessage(msg))
	logger.Info("send radar offline:", msg)
}

func (d *Radar) PostureCalibration() (*mavlink.PostureCalibrationResponse, error) {
	req := &mavlink.PostureCalibrationRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("发送雷达姿态开始标定指令失败: ", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.RadarIdPostureCalibration]
	if !ok {
		manager = NewWaitTaskManager(mavlink.RadarIdPostureCalibration, true, 0)
		d.WaitTaskMap[mavlink.RadarIdPostureCalibration] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, err
		}
		return nil, err
	}
	logger.Debugf("雷达姿态开始标定结果：%#v", result.(*mavlink.PostureCalibrationResponse))
	return result.(*mavlink.PostureCalibrationResponse), nil
}

func (d *Radar) ReceivePostureCalibration() {
	res := &mavlink.PostureCalibrationResponse{}
	d.GetPacket(res)
	logger.Debugf("接收雷达姿态开始标定结果：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdPostureCalibration]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Radar) ReceivePostureCalibrationResult() {
	upload := &mavlink.PostureCalibrationResultResponse{}
	d.GetPacket(upload)
	logger.Debugf("接收雷达姿态校准结果：%#v", upload)
	entity := common.EquipmentMessageBoxEntity{
		Name:      d.Sn,
		Sn:        d.Sn,
		MsgType:   mavlink.RadarIdPostureCalibrationResult,
		EquipType: int(common.DEV_RADAR),
		Info: common.RadarUploadPostureEntity{
			Heading:   float64(upload.UHeading) / RadarPostureReduce,
			Pitching:  float64(upload.UPitching) / RadarPostureReduce,
			Rolling:   float64(upload.URolling) / RadarPostureReduce,
			Longitude: float64(upload.ULongitude) / RadarPostureReduce,
			Latitude:  float64(upload.ULatitude) / RadarPostureReduce,
			Altitude:  float64(upload.UAltitude) / RadarPostureReduce,
		},
	}
	_ = mq.EquipMessageBoxBroker.Publish(mq.EquipMessageBoxTopic, broker.NewMessage(entity))
}

func (d *Radar) PostureCalibrationManual(req *mavlink.PostureCalibrationManualRequest) (*mavlink.PostureCalibrationManualResponse, error) {
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("发送雷达姿态手动校准数据失败: ", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.RadarIdPostureCalibrationManual]
	if !ok {
		manager = NewWaitTaskManager(mavlink.RadarIdPostureCalibrationManual, true, 0)
		d.WaitTaskMap[mavlink.RadarIdPostureCalibrationManual] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, err
		}
		return nil, err
	}
	logger.Debugf("雷达姿态手动校准数据结果：%#v", result.(*mavlink.PostureCalibrationManualResponse))
	return result.(*mavlink.PostureCalibrationManualResponse), nil
}

func (d *Radar) ReceivePostureCalibrationManual() {
	res := &mavlink.PostureCalibrationManualResponse{}
	d.GetPacket(res)
	logger.Debugf("接收雷达姿态手动校准数据结果：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdPostureCalibrationManual]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Radar) SendGetVersionInfo() (uint32, string, string, string, string, error) {
	logger.Info("SendGetVersionInfo Start")
	req := &mavlink.GetVersionInfoRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("SendGetVersionInfo 发送获取雷达版本信息失败: ", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.RadarIdGetVersionInfo]
	if !ok {
		manager = NewWaitTaskManager(mavlink.RadarIdGetVersionInfo, true, 0)
		d.WaitTaskMap[mavlink.RadarIdGetVersionInfo] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 0, "", "", "", "", checkNetConnErr
		}
		return 0, "", "", "", "", err
	}
	res := result.(*mavlink.GetVersionInfoResponse)
	logger.Debugf("SendGetVersionInfo 获取雷达版本信息结果：%#v", res)
	logger.Info("SendGetVersionInfo End")
	return res.RunVersion,
		d.TrimStringSpace(res.AppVersion[:]),
		d.TrimStringSpace(res.BootVersion[:]),
		d.TrimStringSpace(res.HwVersion[:]),
		d.TrimStringSpace(res.ProtocolVersion[:]),
		nil
}

func (d *Radar) ReceiveGetVersionInfo() {
	res := &mavlink.GetVersionInfoResponse{}
	d.GetPacket(res)
	logger.Debugf("接收到雷达版本信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdGetVersionInfo]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Radar) TrimStringSpace(strArr []byte) string {
	tmp := make([]byte, 0)
	for _, v := range strArr {
		if v == 0x00 {
			break
		}
		tmp = append(tmp, v)
	}
	return string(tmp)
}

func (d *Radar) deviceDiscover(sn string) bool {
	return true
}

// SendGetLogList -----------------------------日志列表-----------------------------------------------
// 发送请求雷达日志列表指令
func (d *Radar) SendGetLogList(sn string) (*mavlink.RadarGetLogListResponseAll, error) {
	logger.Info("-->Into Send Get LogList To Radar")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Radar Get LogList occurred:", r)
			return
		}
	}()
	req := mavlink.RadarGetLogListRequest{}
	reqBuff := req.CreateRadarGetLogList()
	if err := d.Send(sn, reqBuff); err != nil {
		logger.Error("-->Send Get LogList To Radar fail !,err is : ", err)
		return nil, err
	}
	manager, ok := d.WaitTaskMap[mavlink.RadarGetLogList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.RadarGetLogList, true, time.Second*10)
		d.WaitTaskMap[mavlink.RadarGetLogList] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		logger.Error("-->Wait err:", err)
		return nil, err
	}
	logger.Info("-->Send Get LogList To Radar End")
	return result.(*mavlink.RadarGetLogListResponseAll), nil
}

// ReceiveGetLogList 接收雷达日志列表返回，组包
func (d *Radar) ReceiveGetLogList() {
	logger.Info("-->into Revceive Get LogList Radar")

	var PkgTotalNum uint32
	var PkgCurNum uint32
	var LogNameLen uint32
	var LogDataLen uint32
	var LogName []byte

	err := mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen:]), binary.LittleEndian, &PkgTotalNum, 4)
	logger.Debug("PkgTotalNum : ", PkgTotalNum)

	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+4:]), binary.LittleEndian, &PkgCurNum, 4)
	logger.Debug("PkgCurNum : ", PkgCurNum)

	if err != nil {
		logger.Error("msg Decode err:%v", err)
		return
	}
	msg := &mavlink.RadarGetLogListResponse{}
	index := mavlink.HeaderLen + 8

	for {
		//退出条件
		if len(d.Msg)-index < mavlink.CrcLen+1 {
			break
		}
		//解析LogNameLen
		err = mavlink.Read(bytes.NewReader(d.Msg[index:]), binary.LittleEndian, &LogNameLen, 4)
		if err != nil {
			logger.Error("msg Decode LogNameLen err:%v", err)
			return
		}
		//解析LogDataLen
		index = index + 4
		err = mavlink.Read(bytes.NewReader(d.Msg[index:]), binary.LittleEndian, &LogDataLen, 4)
		if err != nil {
			logger.Error("msg Decode LogDataLen err:%v", err)
			return
		}
		//解析LogName
		index = index + 4
		LogName = make([]byte, LogNameLen)
		err = mavlink.Read(bytes.NewReader(d.Msg[index:]), binary.LittleEndian, &LogName, int(LogNameLen))
		if err != nil {
			logger.Error("msg Decode LogName err:%v", err)
			return
		}

		logger.Debug("LogName : ", string(LogName))
		index = index + int(LogNameLen)

		if strings.Contains(string(LogName), ".txt") || strings.Contains(string(LogName), ".log") {
			msg.RadarLogInfo = append(msg.RadarLogInfo, mavlink.RadarLogInfo{
				LogNameLen: LogNameLen,
				LogDataLen: LogDataLen,
				LogName:    LogName,
			})
		}
	}

	var i interface{} = msg
	if PkgTotalNum != PkgTotalNum {
		logger.Info("-->Revceive ing Radar")
		mavlink.RadarResAll.SetData(i.(*mavlink.RadarGetLogListResponse))
	} else {
		mavlink.RadarResAll.SetData(i.(*mavlink.RadarGetLogListResponse))
		logger.Info("Radar Loglist res is %v", msg)
		manager, ok := d.WaitTaskMap[mavlink.RadarGetLogList]
		if ok {
			manager.CompletedTask(&mavlink.RadarResAll, nil)
		}
		logger.Info("-->Revceive Get LogList end Radar")
	}
}

// SendGetLog -----------------------------请求日志-----------------------------------------------
// 发送请求雷达日志指令
func (d *Radar) SendGetLog(sn, filePath string, logInfo DeviceLogList) (*mavlink.RadarGetLogMsgResponse, error) {
	logger.Info("-->Into Send Get Log To Radar")
	logger.Info("Radar LogName : ", logInfo.LogName)
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Radar Get Log occurred:", r)
			return
		}
	}()
	var num uint32
	binary.Read(rand.Reader, binary.LittleEndian, &num)

	req := mavlink.RadarGetLogRequestAll{}
	logreq := make([]*mavlink.RadarGetLogRequest, 0)

	logfile := &mavlink.RadarLogFileInfo{
		LogId:      num,
		LogNameLen: uint32(len(logInfo.LogName)),
		LogName:    []byte(logInfo.LogName),
	}
	logreq = append(logreq, &mavlink.RadarGetLogRequest{
		LogNum:      1,
		LogFileInfo: [1]mavlink.RadarLogFileInfo{*logfile},
	})

	FileNameMap.Set(num, logInfo.LogName, filePath+"/radar/"+sn+"/"+logInfo.LogName)

	reqBuff := req.CreateRadarGetLog(logreq)

	//创建文件夹
	dirpath := ""
	if strings.Contains(logInfo.LogName, "/") {
		index := strings.LastIndex(logInfo.LogName, "/")
		dirpath = filePath + "/radar/" + sn + "/" + logInfo.LogName[:index]
	} else {
		dirpath = filePath + "/radar/" + sn
	}
	err := helper.CreateDirIfNotExist(dirpath)
	if err != nil {
		logger.Error("Create directory error : ", err)
	} else {
		logger.Info("Directory created successfully.")
	}

	logger.Info("-->File Path is :", filePath+"/radar/"+sn+"/"+logInfo.LogName)

	if err = d.Send(sn, reqBuff); err != nil {
		logger.Error("-->Send Get Log To Gun Fail,err : ", err)
		return nil, err
	}
	logger.Info("Send Get File To Radar")

	manager, ok := d.WaitTaskMap[mavlink.RadarGetLog]
	if !ok {
		manager = NewWaitTaskManager(mavlink.RadarGetLog, true, time.Second*600)
		d.WaitTaskMap[mavlink.RadarGetLog] = manager
	}
	// TODO 处理包序
	result, err := manager.Wait()
	if err != nil {
		logger.Error("-->Wait Fail,err : ", err)
		return nil, err
	}
	logger.Info("-->Send Get Radar Log End")
	return result.(*mavlink.RadarGetLogMsgResponse), nil
}

// ReceiveGetLog 接收雷达日志文件返回
func (d *Radar) ReceiveGetLog() {
	logger.Info("-->into Receive Get Log")

	var PkgTotalNum uint32
	var PkgCurNum uint32
	var LogId uint32

	err := mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen:mavlink.HeaderLen+4]), binary.LittleEndian, &LogId, 4)
	logger.Debug("LogId : ", LogId)

	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+4:mavlink.HeaderLen+8]), binary.LittleEndian, &PkgTotalNum, 4)
	logger.Debug("PkgTotalNum : ", PkgTotalNum)

	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+8:mavlink.HeaderLen+12]), binary.LittleEndian, &PkgCurNum, 4)
	logger.Debug("PkgCurNum : ", PkgCurNum)

	if err != nil {
		logger.Error("msg Decode err:%v", err)
		return
	}
	if PkgCurNum == 0 && PkgTotalNum == 0 { //空包不进行处理
		return
	}
	var msg string

	msg = string(d.Msg[mavlink.HeaderLen+16 : len(d.Msg)-mavlink.CrcLen])

	fileInfo, isExit := FileNameMap.Get(LogId)
	if isExit != true {
		logger.Error("File Name Map Get err")
	}

	if PkgCurNum == 1 {
		manager, ok := d.WaitTaskMap[mavlink.RadarGetLog]
		if ok {
			manager.CompletedTask(&mavlink.RadarLogMsgAll, nil)
		}
		file, err := os.Create(fileInfo.FilePath)
		if err != nil {
			logger.Error(err)
		}
		defer file.Close()
		logger.Debug("文件已创建")
	}

	mavlink.RadarLogMsgAll.SetData(msg)
	if PkgCurNum != PkgTotalNum {
		logger.Debug("-->Revceive log ing")
		if PkgCurNum%PackNum == 0 { //200个包写入一次  一个包16k  //测试  90s 传280M日志文件
			if PkgCurNum == PackNum {
				//新建文件写入
				err = os.WriteFile(fileInfo.FilePath, []byte(strings.Join(mavlink.RadarLogMsgAll.GetData(), "")), 0644)
				if err != nil {
					logger.Error("Log Store Fail,err:", err)
				}
			} else {
				//追加写入
				file, err := os.OpenFile(fileInfo.FilePath, os.O_APPEND|os.O_WRONLY, 0644)
				if err != nil {
					logger.Error(err)
				}
				file.WriteString(strings.Join(mavlink.RadarLogMsgAll.GetData(), ""))
				defer file.Close()
			}
			mavlink.RadarLogMsgAll.DeleteData()
		}
	} else {
		if PkgTotalNum == 1 {
			//新建文件写入
			err = os.WriteFile(fileInfo.FilePath, []byte(strings.Join(mavlink.RadarLogMsgAll.GetData(), "")), 0644)
			if err != nil {
				logger.Error("Log Store Fail,err:", err)
			}
		} else {
			//追加写入
			file, err := os.OpenFile(fileInfo.FilePath, os.O_APPEND|os.O_WRONLY, 0644)
			if err != nil {
				logger.Error(err)
			}
			file.WriteString(strings.Join(mavlink.RadarLogMsgAll.GetData(), ""))
			defer file.Close()
		}

		mavlink.RadarLogMsgAll.DeleteData()
		FileNameMap.Del(LogId)
	}
	logger.Info("-->Receive Get Log  end")
}

// SendDelLog -----------------------------删除日志-----------------------------------------------
// 发送删除枪日志指令
func (d *Radar) SendDelLog(sn string, logDir string) (*mavlink.RadarDelLogResponse, error) {
	logger.Info("-->Into Send Del Log")
	req := mavlink.RadarDelLogRequestAll{}
	reqBuff := req.CreateRadarDelLog(logDir)
	if err := d.Send(sn, reqBuff); err != nil {
		logger.Error("-->Send Del Log To Radar Fail,err : ", err)
		return nil, err
	}
	manager, ok := d.WaitTaskMap[mavlink.RadarDeleteLog]
	if !ok {
		manager = NewWaitTaskManager(mavlink.RadarDeleteLog, true, 0)
		d.WaitTaskMap[mavlink.RadarDeleteLog] = manager
	}
	// TODO 处理包序
	result, err := manager.Wait()
	if err != nil {
		logger.Error("-->Send Del Log Wait err : ", err)
		return nil, err
	}
	logger.Info("-->Send Del Log End")
	return result.(*mavlink.RadarDelLogResponse), nil
}

// ReceiveDelLog 接收雷达日志文件返回
func (d *Radar) ReceiveDelLog() {
	logger.Info("-->into Receive Del Log")
	res := &mavlink.RadarDelLogResponse{}
	d.GetPacket(res)
	logger.Info("Del Log response : ", res.Status)
	manager, ok := d.WaitTaskMap[mavlink.RadarDeleteLog]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->Receive Del Log end")
}

// RadarResetSystem 系统复位
func (d *Radar) RadarResetSystem(rq *client.ResetSystemRequest) (int32, error) {
	logger.Info("RadarResetSystem Start")
	req := &mavlink.RadarResetSystemRequest{
		ResetCode: mavlink.RadarOtaReSetCode,
		Type:      uint16(rq.Type),
	}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("RadarResetSystem 发送雷达系统复位信息失败: ", err)
		return 1, err
	}
	logger.Info("RadarResetSystem End")
	return 0, nil
}

// ReceiveRadarResetSystem 获取系统复位响应
func (d *Radar) ReceiveRadarResetSystem() {
	res := &mavlink.RadarResetSystemResponse{}
	d.GetPacket(res)
	logger.Debugf("系统复位回复信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdResetSystem]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// RadarGetUpdateWriteStatus 获取固件写入状态
func (d *Radar) RadarGetUpdateWriteStatus() (*mavlink.RadarGetUpdateWriteStatusResponse, error) {
	logger.Info("RadarGetUpdateWriteStatus Start")
	req := &mavlink.RadarGetUpdateWriteStatusRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.RadarIdGetUpdateWriteStatus]
	if !ok {
		manager = NewWaitTaskManager(mavlink.RadarIdGetUpdateWriteStatus, true, 20*time.Second)
		d.WaitTaskMap[mavlink.RadarIdGetUpdateWriteStatus] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("RadarGetUpdateWriteStatus 发送获取固件写入状态信息失败: ", err)
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	res := result.(*mavlink.RadarGetUpdateWriteStatusResponse)
	logger.Debugf("RadarGetUpdateWriteStatus 获取固件写入状态信息结果：%#v", res)
	logger.Info("RadarGetUpdateWriteStatus End")
	return res, nil
}

// ReceiveRadarGetUpdateWriteStatus 获取固件写入状态回复结果
func (d *Radar) ReceiveRadarGetUpdateWriteStatus() {
	res := &mavlink.RadarGetUpdateWriteStatusResponse{}
	d.GetPacket(res)
	logger.Debugf("获取固件写入状态回复信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdGetUpdateWriteStatus]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// RadarGetUpdateTimeoutRetryTime 获取固件升级超时重试时间
func (d *Radar) RadarGetUpdateTimeoutRetryTime() (*mavlink.RadarGetUpdateTimeoutRetryTimeResponse, error) {
	req := &mavlink.RadarGetUpdateTimeoutRetryTimeRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.RadarIdGetTimeoutRetryTime]
	if !ok {
		manager = NewWaitTaskManager(mavlink.RadarIdGetTimeoutRetryTime, true, 20*time.Second)
		d.WaitTaskMap[mavlink.RadarIdGetTimeoutRetryTime] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("发送获取固件升级超时重试时间信息失败: ", err)
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	res := result.(*mavlink.RadarGetUpdateTimeoutRetryTimeResponse)
	logger.Debugf("获取固件升级超时重试时间信息结果：%#v", res)

	return res, nil
}

// ReceiveRadarGetUpdateTimeoutRetryTime 获取固件升级超时重试时间响应
func (d *Radar) ReceiveRadarGetUpdateTimeoutRetryTime() {
	res := &mavlink.RadarGetUpdateTimeoutRetryTimeResponse{}
	d.GetPacket(res)
	logger.Debugf("获取固件升级超时重试时间回复信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdGetTimeoutRetryTime]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// RadarRequestUpgrade 请求固件升级
func (d *Radar) RadarRequestUpgrade(data [256]byte, tryCount int) (int32, error) {
	logger.Info("RadarRequestUpgrade Start")
	var req = &mavlink.RadarRequestUpgradeRequest{
		Data: data,
	}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.RadarIdRequestUpgrade]
	if !ok {
		manager = NewWaitTaskManager(mavlink.RadarIdRequestUpgrade, true, 20*time.Second)
		d.WaitTaskMap[mavlink.RadarIdRequestUpgrade] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("RadarRequestUpgrade 发送雷达系统复位信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("RadarRequestUpgrade WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.RadarRequestUpgradeResponse)
	logger.Debugf("RadarRequestUpgrade 获取雷达版本信息结果：%#v", res)
	logger.Info("RadarRequestUpgrade End")
	// 嵌入是boot有个bug第一次请求A7有一定概率会返回1;睡眠2两秒再重试
	if res.Status != 0 {
		if tryCount > 0 {
			tryCount--
			time.Sleep(2 * time.Second)
			return d.RadarRequestUpgrade(data, tryCount)
		}
	}
	return int32(res.Status), nil
}

// ReceiveRadarRequestUpgrade 获取请求固件升级响应
func (d *Radar) ReceiveRadarRequestUpgrade() {
	res := &mavlink.RadarRequestUpgradeResponse{}
	d.GetPacket(res)
	logger.Debugf("获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdRequestUpgrade]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// RadarVerifyImage 校验固件镜像
func (d *Radar) RadarVerifyImage() (int32, error) {

	logger.Info("RadarVerifyImage Start")
	req := &mavlink.RadarVerifyImageRequest{}
	buff := req.Create()
	logger.Debugf("RadarVerifyImage buff: %v", buff)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.RadarIdVerifyImage]
	if !ok {
		manager = NewWaitTaskManager(mavlink.RadarIdVerifyImage, true, 30*time.Second)
		d.WaitTaskMap[mavlink.RadarIdVerifyImage] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("RadarVerifyImage 发送校验固件镜像信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("RadarVerifyImage WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.RadarVerifyImageResponse)
	logger.Debugf("RadarVerifyImage 获取校验固件镜像信息结果：%#v", res)
	logger.Info("RadarVerifyImage End")
	return int32(res.Status), nil
}

// ReceiveRadarVerifyImage 获取校验固件镜像响应
func (d *Radar) ReceiveRadarVerifyImage() {
	res := &mavlink.RadarVerifyImageResponse{}
	d.GetPacket(res)
	logger.Debugf("获取校验固件镜像响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdVerifyImage]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// RadarRunApp 运行固件App
func (d *Radar) RadarRunApp() (int32, error) {
	logger.Info("RadarRunApp Start")
	req := &mavlink.RadarRunAppRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.RadarIdRunApp]
	if !ok {
		manager = NewWaitTaskManager(mavlink.RadarIdRunApp, true, 20*time.Second)
		d.WaitTaskMap[mavlink.RadarIdRunApp] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("RadarRunApp 发送运行固件App信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("RadarRunApp WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.RadarRunAppResponse)
	logger.Debugf("RadarRunApp 获取运行固件App信息结果：%#v", res)
	logger.Info("RadarRunApp End")
	return int32(res.Status), nil
}

// ReceiveRadarRunApp 获取运行固件App响应
func (d *Radar) ReceiveRadarRunApp() {
	res := &mavlink.RadarRunAppResponse{}
	d.GetPacket(res)
	logger.Debugf("获取运行固件App响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdRunApp]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// RadarWriteUpdateData 写入固件数据
func (d *Radar) RadarWriteUpdateData() (int32, error) {
	logger.Info("RadarWriteUpdateData Start")
	req := &mavlink.RadarWriteUpdateDataRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.RadarIdWriteUpdateData]
	if !ok {
		manager = NewWaitTaskManager(mavlink.RadarIdWriteUpdateData, true, 20*time.Second)
		d.WaitTaskMap[mavlink.RadarIdWriteUpdateData] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("RadarWriteUpdateData 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("RadarWriteUpdateData WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.RadarWriteUpdateDataResponse)
	logger.Debugf("RadarWriteUpdateData 获取写入固件数据信息结果：%#v", res)
	logger.Info("RadarWriteUpdateData End")
	return int32(res.Status), nil
}

// ReceiveRadarWriteUpdateData 获取写入固件数据响应
func (d *Radar) ReceiveRadarWriteUpdateData() {
	res := &mavlink.RadarWriteUpdateDataResponse{}
	d.GetPacket(res)
	logger.Debugf("获取写入固件数据响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdWriteUpdateData]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// RadarSendUpdatePkg 发送升级固件数据
func (d *Radar) RadarSendUpdatePkg(offset uint32, imageData []uint8) (*mavlink.RadarSendUpdatePkgResponse, error) {
	logger.Info("RadarSendUpdatePkg Start")
	req := &mavlink.RadarSendUpdatePkgRequest{
		ImageOffset: offset,
		ImageLength: uint32(len(imageData)),
		ImageData:   imageData,
	}
	buff, err := req.Create()
	if err != nil {
		return nil, err
	}

	// 超时重发
	result, err := d.TimeOutRepeatSendBuff(buff, 3, 10*time.Second, mavlink.RadarIdSendUpdatePkg)
	if err != nil {
		logger.Errorf("RadarSendUpdatePkg 获取发送升级固件数据信息结果报错：%#v", err)
		logger.Errorf("RadarSendUpdatePkg Err buff: %v", buff)
		logger.Errorf("RadarWriteUpdateData WaitTask Err %s", err.Error())
		return nil, err
	}
	res := result.(*mavlink.RadarSendUpdatePkgResponse)
	logger.Debugf("RadarSendUpdatePkg 获取发送升级固件数据信息结果：%#v", res)
	logger.Info("RadarSendUpdatePkg End")
	return res, nil
}

// ReceiveRadarSendUpdatePkg 获取发送升级固件数据响应
func (d *Radar) ReceiveRadarSendUpdatePkg() {
	res := &mavlink.RadarSendUpdatePkgResponse{}
	d.GetPacket(res)
	logger.Debugf("获取发送升级固件数据响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.RadarIdSendUpdatePkg]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TimeOutRepeatSendBuff 超时重发字节数据
func (d *Radar) TimeOutRepeatSendBuff(buff []byte, tryCount int, timeOut time.Duration, messageId int) (interface{}, error) {
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[messageId]
	if !ok {
		manager = NewWaitTaskManager(messageId, true, timeOut)
		d.WaitTaskMap[messageId] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TimeOutRepeatSendBuff 发送信息失败: ", err)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil && err.Error() == "wait time out" {
		// 超时重试
		if tryCount > 0 {
			tryCount--
			fmt.Println("TimeOutRepeatSendBuff tryCount: ", tryCount)
			return d.TimeOutRepeatSendBuff(buff, tryCount, timeOut, messageId)
		}
	}
	return result, err
}

// HandleBroadCast 处理广播消息
func (d *Radar) HandleBroadCast(ctx context.Context, req *slinkv1.UdpBroadcastConfirmRequest) (*slinkv1.UdpBroadcastConfirmResponse, error) {
	if req.GetSn() == "" {
		logger.Info("雷达获取信道不能sn为空")
		return nil, errors.New("sn must not empty")
	}
	dbequip := &client.EquipListRes{}
	err := NewEquipList().List(context.Background(), &client.EquipListReq{}, dbequip)
	if err != nil {
		logger.Error("Get EquipList err: ", err)
		return nil, err
	}

	if status := d.GetStatus(req.GetSn()); status == common.DeviceDisenable {
		logger.Infof("device %v disable", req.GetSn())
		return nil, nil
	}

	localIP := make([]string, 0)
	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}

	tcpServer := d.TcpServerCheck(req.GetSn(), localIP)
	//替换新的端口
	DevSnMap.Store(tcpServer.Port, req.GetSn())
	d.ServerPort = tcpServer.Port
	logger.Debugf("tcpServer %+v localIP:%v,", tcpServer, localIP)
	err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
		Sn: req.GetSn(),
		Ip: d.UdpIp,
	}, &client.EquipCrudRes{})
	if err != nil {
		logger.Error("Update EquipList err: ", err)
		return nil, nil
	}
	logger.Info("--> receive radar Udp Broadcast Response")
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       req.Sn,
		Addr:     ip.IPV4(tcpServer.Ip),
		Port:     uint16(tcpServer.Port),
		ConnType: 1,
	}
	logger.Info("rsp %+v,", rsp)
	return rsp, nil
}
