package handler

import (
	"context"
	"regexp"
	"strings"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/awsS3"
)

// 下载C2升级包
func (e *DeviceCenter) DownC2Apk(ctx context.Context, req *client.DownC2ApkRequest, rsp *client.DownC2ApkResponse) error {
	logger.Infof("-->Into Down C2 Apk req:%+v", req)
	if req.TestFlag == 1 {
		updata := false
		var strArr []string
		//获取S3上全部的apk名称
		//if req.Platform == "windows" {
		strArr = awsS3.TestGetBucketObject(req.IsHaveLogo, req.IsHome, req.PkgType)
		//} else {
		//	strArr = awsS3.GetBucketObject(req.IsHaveLogo, req.IsHome, req.PkgType)
		//}

		latest := GetLatestVersion(strArr)
		logger.Info("-->test Get BucketEnd Latest Version is :", latest)
		if latest == "" {
			rsp.Update = updata
			return nil
		}
		var fileName string
		for _, s := range strArr {
			if strings.Contains(s, latest) {
				fileName = s
			}
		}
		//请求最新版本
		c2DownUrl, errs := awsS3.TestPresigningDownLoadApk(fileName, req.IsHaveLogo, req.IsHome, req.PkgType, req.Platform)
		if errs != nil {
			logger.Error("test Presigning DownLoad C2 APK err:%v", errs)
			rsp.Version = req.Version
			rsp.Update = false
			return errs
		}
		//获取"c2os_v1.0.0.4.dev.apk"  中 1.0.0.4
		re := regexp.MustCompile(`(\d+\.\d+\.\d+\.\d+)`)
		version := re.FindString(latest)
		//获取最大的版本号
		versions := []string{
			version,
			req.Version,
		}
		max := MaxVersion(versions)

		if max == req.Version {
			updata = false
			rsp.Version = req.Version
		} else {
			updata = true
			rsp.Version = version
			rsp.Download = c2DownUrl
		}
		rsp.Update = updata
		upgradeDes, isForceUp, upgradeChinese, upgradeEnglish, upgradeRussian := awsS3.TestGetC2UpgradeDes(rsp.Version, req.IsHome, req.IsHaveLogo, req.PkgType, req.Platform)
		rsp.UpgradeDes = upgradeDes
		rsp.IsForceUpgrade = isForceUp
		rsp.UpgradeDesChinese = upgradeChinese
		rsp.UpgradeDesEnglish = upgradeEnglish
		rsp.UpgradeDesRussian = upgradeRussian
		logger.Info("test rsp UpgradeDes is: ", rsp.UpgradeDes)
		logger.Info("test rsp IsForceUpgrade is: ", rsp.IsForceUpgrade)
		logger.Info("test rsp version is: ", rsp.Version)
		logger.Info("test rsp Update is: ", rsp.Update)
		logger.Info("rsp upgradeChinese is: ", rsp.UpgradeDesChinese)
		logger.Info("rsp upgradeEnglish is: ", rsp.UpgradeDesEnglish)
		logger.Info("rsp upgradeRussian is: ", rsp.UpgradeDesRussian)
		logger.Info("-->test End Down C2 Apk")
	} else {
		updata := false
		var strArr []string
		//获取S3上全部的apk名称
		if req.Platform == "windows" {
			strArr = awsS3.GetBucketObjectWindows(req.IsHaveLogo, req.IsHome, req.PkgType)
		} else {
			strArr = awsS3.GetBucketObject(req.IsHaveLogo, req.IsHome, req.PkgType)
		}

		latest := GetLatestVersion(strArr)

		logger.Info("-->Get BucketEnd Latest Version is :", latest)
		if latest == "" {
			rsp.Update = updata
			return nil
		}
		var fileName string
		for _, s := range strArr {
			if strings.Contains(s, latest) {
				fileName = s
			}
		}
		//请求最新版本
		c2DownUrl, errs := awsS3.PresigningDownLoadApk(fileName, req.IsHaveLogo, req.IsHome, req.PkgType, req.Platform)
		if errs != nil {
			logger.Error("Presigning DownLoad C2 APK err:%v", errs)
			rsp.Version = req.Version
			rsp.Update = false
			return errs
		}
		//获取"c2os_v1.0.0.4.dev.apk"  中 1.0.0.4
		re := regexp.MustCompile(`(\d+\.\d+\.\d+\.\d+)`)
		version := re.FindString(latest)
		//获取最大的版本号
		versions := []string{
			version,
			req.Version,
		}
		max := MaxVersion(versions)

		if max == req.Version {
			updata = false
			rsp.Version = req.Version
		} else {
			updata = true
			rsp.Version = version
			rsp.Download = c2DownUrl
		}

		rsp.Update = updata
		upgradeDes, isForceUp, upgradeChinese, upgradeEnglish, upgradeRussian := awsS3.GetC2UpgradeDes(rsp.Version, req.IsHome, req.IsHaveLogo, req.PkgType, req.Platform)
		rsp.UpgradeDes = upgradeDes
		rsp.IsForceUpgrade = isForceUp
		rsp.UpgradeDesChinese = upgradeChinese
		rsp.UpgradeDesEnglish = upgradeEnglish
		rsp.UpgradeDesRussian = upgradeRussian
		logger.Info("rsp UpgradeDes is: ", rsp.UpgradeDes)
		logger.Info("rsp.IsForceUpgrade is: ", rsp.IsForceUpgrade)
		logger.Info("rsp version is: ", rsp.Version)
		logger.Info("rsp Update is: ", rsp.Update)
		logger.Info("rsp upgradeChinese is: ", rsp.UpgradeDesChinese)
		logger.Info("rsp upgradeEnglish is: ", rsp.UpgradeDesEnglish)
		logger.Info("rsp upgradeRussian is: ", rsp.UpgradeDesRussian)
		logger.Info("-->End Down C2 Apk")
	}
	return nil
}
