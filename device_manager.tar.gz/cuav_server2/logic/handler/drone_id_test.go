package handler

import (
	"reflect"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"github.com/bmizerany/assert"
)

func TestByteToString(t *testing.T) {
	// 定义测试用例
	testCases := []struct {
		input    []byte
		expected string
	}{
		{[]byte{72, 101, 108, 108, 111, 0, 87, 111, 114, 108, 100}, "Hello"},
		{[]byte{87, 111, 114, 108, 100}, "World"},
		{[]byte{}, ""},
	}

	// 遍历测试用例，逐个进行测试
	for _, tc := range testCases {
		// 调用被测试函数
		result := ByteToString(tc.input)

		// 断言结果是否符合预期
		assert.Equal(t, tc.expected, result)
	}
}

/*
func TestDroneID_Deal(t *testing.T) {

		// 创建一个 DroneID 实例
		droneID := &DroneID{
			Device: &Device{
				Msg:    []byte{253, 104, 0, 0, 6, 7, 187, 0, 45, 170, 0, 0, 32, 84, 82, 65, 67, 69, 82, 49, 48, 49, 66, 49, 49, 50, 48, 50, 51, 52, 57, 55, 48, 48, 49, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 2, 0, 118, 49, 48, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 98, 41},
				MsgLen: 115,
			},
			dt: 0,
		}

		// 调用 Deal() 函数
		droneID.Deal()

		// 使用断言来验证函数的行为和结果（根据具体情况进行修改）
		assert.Equal(t, 0xBB, droneID.MsgId)
	}
*/
func TestDroneID_GetPacket(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		message mavlink.Message
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   *mavlink.MavPacket
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			if got := d.GetPacket(tt.args.message); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetPacket() = %v, want %v", got, tt.want)
			}
		})
	}
}

/*
	func TestDroneID_GetStatus(t *testing.T) {
		type fields struct {
			Device *Device
			dt     common.DeviceType
		}
		type args struct {
			sn string
		}

		tests := []struct {
			name   string
			fields fields
			args   args
			want   int32
		}{
			// TODO: Add test cases.
			{
				args: args{
					sn: "drone111",
				},
			},
		}
		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				d := &DroneID{
					Device: tt.fields.Device,
					dt:     tt.fields.dt,
				}

				if got := d.GetStatus(tt.args.sn); got != tt.want {
					t.Errorf("GetStatus() = %v, want %v", got, tt.want)
				}
			})
		}
	}
*/
func TestDroneID_Heart(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.Heart()
		})
	}
}

func TestDroneID_ReceiveDelLog(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveDelLog()
		})
	}
}

func TestDroneID_ReceiveDetectRes(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveDetectRes()
		})
	}
}

func TestDroneID_ReceiveFreqDetectRes(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveFreqDetectRes()
		})
	}
}

func TestDroneID_ReceiveGetChannelReq(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveGetChannelReq()
		})
	}
}

func TestDroneID_ReceiveGetLog(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveGetLog()
		})
	}
}

func TestDroneID_ReceiveGetLogList(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveGetLogList()
		})
	}
}

func TestDroneID_ReceiveGetTime(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveGetTime()
		})
	}
}

func TestDroneID_ReceiveGetVersionInfo(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveGetVersionInfo()
		})
	}
}

func TestDroneID_ReceiveRemoteIdDetectRes(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveRemoteIdDetectRes()
		})
	}
}

func TestDroneID_ReceiveSendGetWorkMode(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveSendGetWorkMode()
		})
	}
}

func TestDroneID_ReceiveSendSetOrientationMode(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveSendSetOrientationMode()
		})
	}
}

func TestDroneID_ReceiveTracerGetUpdateWriteStatus(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveTracerGetUpdateWriteStatus()
		})
	}
}

func TestDroneID_ReceiveTracerGetVersionInfo(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveTracerGetVersionInfo()
		})
	}
}

func TestDroneID_ReceiveTracerRequestUpgrade(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveTracerRequestUpgrade()
		})
	}
}

func TestDroneID_ReceiveTracerRunApp(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveTracerRunApp()
		})
	}
}

func TestDroneID_ReceiveTracerSendUpdatePkg(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveTracerSendUpdatePkg()
		})
	}
}

func TestDroneID_ReceiveTracerVerifyImage(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveTracerVerifyImage()
		})
	}
}

func TestDroneID_ReceiveTracerWriteUpdateData(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			d.ReceiveTracerWriteUpdateData()
		})
	}
}

func TestDroneID_Send(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		sn      string
		reqBuff []byte
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			if err := d.Send(tt.args.sn, tt.args.reqBuff); (err != nil) != tt.wantErr {
				t.Errorf("Send() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestDroneID_SendDelLog(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		sn     string
		logDir string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *mavlink.DroneIdDelLogResponse
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			got, err := d.SendDelLog(tt.args.sn, tt.args.logDir)
			if (err != nil) != tt.wantErr {
				t.Errorf("SendDelLog() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("SendDelLog() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_SendExtHeartbeat(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name    string
		fields  fields
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			if err := d.SendExtHeartbeat(); (err != nil) != tt.wantErr {
				t.Errorf("SendExtHeartbeat() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestDroneID_SendGetLog(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		sn       string
		filePath string
		logInfo  DeviceLogList
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *mavlink.DroneIdGetLogMsgResponse
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			got, err := d.SendGetLog(tt.args.sn, tt.args.filePath, tt.args.logInfo)
			if (err != nil) != tt.wantErr {
				t.Errorf("SendGetLog() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("SendGetLog() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_SendGetLogList(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		sn string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *mavlink.DroneIdGetLogListResponseAll
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			got, err := d.SendGetLogList(tt.args.sn)
			if (err != nil) != tt.wantErr {
				t.Errorf("SendGetLogList() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("SendGetLogList() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_SendGetVersionInfo(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name    string
		fields  fields
		want    *client.DroneIDGetVersionInfoResponse
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			got, err := d.SendGetVersionInfo()
			if (err != nil) != tt.wantErr {
				t.Errorf("SendGetVersionInfo() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("SendGetVersionInfo() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_SendGetWorkMode(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name    string
		fields  fields
		want    int32
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			got, err := d.SendGetWorkMode()
			if (err != nil) != tt.wantErr {
				t.Errorf("SendGetWorkMode() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("SendGetWorkMode() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_SendSetOrientationMode(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		status    uint8
		uavNumber uint8
		uamName   string
		uFreq     uint32
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    int32
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			got, err := d.SendSetOrientationMode(tt.args.status, tt.args.uavNumber, tt.args.uamName, tt.args.uFreq)
			if (err != nil) != tt.wantErr {
				t.Errorf("SendSetOrientationMode() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("SendSetOrientationMode() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_TcpServerCheck(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		devSn   string
		localIP []string
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   *server.TcpServer
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			if got := d.TcpServerCheck(tt.args.devSn, tt.args.localIP); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("TcpServerCheck() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_TracerGetUpdateWriteStatus(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name    string
		fields  fields
		want    *mavlink.TracerGetUpdateWriteStatusResponse
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			got, err := d.TracerGetUpdateWriteStatus()
			if (err != nil) != tt.wantErr {
				t.Errorf("TracerGetUpdateWriteStatus() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("TracerGetUpdateWriteStatus() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_TracerGetVersionInfo(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name    string
		fields  fields
		want    uint32
		want1   string
		want2   string
		want3   string
		want4   string
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			got, got1, got2, got3, got4, err := d.TracerGetVersionInfo()
			if (err != nil) != tt.wantErr {
				t.Errorf("TracerGetVersionInfo() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("TracerGetVersionInfo() got = %v, want %v", got, tt.want)
			}
			if got1 != tt.want1 {
				t.Errorf("TracerGetVersionInfo() got1 = %v, want %v", got1, tt.want1)
			}
			if got2 != tt.want2 {
				t.Errorf("TracerGetVersionInfo() got2 = %v, want %v", got2, tt.want2)
			}
			if got3 != tt.want3 {
				t.Errorf("TracerGetVersionInfo() got3 = %v, want %v", got3, tt.want3)
			}
			if got4 != tt.want4 {
				t.Errorf("TracerGetVersionInfo() got4 = %v, want %v", got4, tt.want4)
			}
		})
	}
}

func TestDroneID_TracerRequestUpgrade(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		data     [256]byte
		tryCount int
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    int32
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			got, err := d.TracerRequestUpgrade(tt.args.data, tt.args.tryCount)
			if (err != nil) != tt.wantErr {
				t.Errorf("TracerRequestUpgrade() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("TracerRequestUpgrade() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_TracerResetSystem(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		rq *client.ResetSystemRequest
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    int32
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			got, err := d.TracerResetSystem(tt.args.rq)
			if (err != nil) != tt.wantErr {
				t.Errorf("TracerResetSystem() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("TracerResetSystem() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_TracerRunApp(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name    string
		fields  fields
		want    int32
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			got, err := d.TracerRunApp()
			if (err != nil) != tt.wantErr {
				t.Errorf("TracerRunApp() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("TracerRunApp() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_TracerVerifyImage(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name    string
		fields  fields
		want    int32
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			got, err := d.TracerVerifyImage()
			if (err != nil) != tt.wantErr {
				t.Errorf("TracerVerifyImage() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("TracerVerifyImage() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_TracerWriteUpdateData(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name    string
		fields  fields
		want    int32
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			got, err := d.TracerWriteUpdateData()
			if (err != nil) != tt.wantErr {
				t.Errorf("TracerWriteUpdateData() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("TracerWriteUpdateData() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_TrimStringSpace(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		strArr []byte
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			if got := d.TrimStringSpace(tt.args.strArr); got != tt.want {
				t.Errorf("TrimStringSpace() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_UnMarshalGetChannelReq(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
		want   string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			if got := d.UnMarshalGetChannelReq(); got != tt.want {
				t.Errorf("UnMarshalGetChannelReq() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_UnmarshalPayload(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		data *mavlink.DroneIDHeartbeat
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			if err := d.UnmarshalPayload(tt.args.data); (err != nil) != tt.wantErr {
				t.Errorf("UnmarshalPayload() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestDroneID_UnmarshalPayloadDetectRes(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		data *mavlink.TracerDetectResult
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			if err := d.UnmarshalPayloadDetectRes(tt.args.data); (err != nil) != tt.wantErr {
				t.Errorf("UnmarshalPayloadDetectRes() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestDroneID_UnmarshalPayloadFreqDetectRes(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		data *mavlink.TracerFreqDetectResult
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			if err := d.UnmarshalPayloadFreqDetectRes(tt.args.data); (err != nil) != tt.wantErr {
				t.Errorf("UnmarshalPayloadFreqDetectRes() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestDroneID_UnmarshalPayloadRemoteDetectRes(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		data *mavlink.TracerRemoteDetectResult
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			if err := d.UnmarshalPayloadRemoteDetectRes(tt.args.data); (err != nil) != tt.wantErr {
				t.Errorf("UnmarshalPayloadRemoteDetectRes() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestDroneID_deviceDiscover(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		sn string
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			if got := d.deviceDiscover(tt.args.sn); got != tt.want {
				t.Errorf("deviceDiscover() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_getPort(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	tests := []struct {
		name   string
		fields fields
		want   int
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			if got := d.getPort(); got != tt.want {
				t.Errorf("getPort() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_getRandPort(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		min int64
		max int64
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   int
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			if got := d.getRandPort(tt.args.min, tt.args.max); got != tt.want {
				t.Errorf("getRandPort() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDroneID_updateStatus(t *testing.T) {
	type fields struct {
		Device *Device
		dt     common.DeviceType
	}
	type args struct {
		sn string
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   int32
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &DroneID{
				Device: tt.fields.Device,
				dt:     tt.fields.dt,
			}
			if got := d.updateStatus(tt.args.sn); got != tt.want {
				t.Errorf("updateStatus() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestNewDroneID(t *testing.T) {
	type args struct {
		conn       Connection
		d          []byte
		dataLen    int
		remoteIp   string
		remotePort int
		localIp    string
		serverPort int
		mailBox    map[int]*WaitTaskManager
	}
	tests := []struct {
		name string
		args args
		want DeviceInterface
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NewDroneID(tt.args.conn, tt.args.d, tt.args.dataLen, tt.args.remoteIp, tt.args.remotePort, tt.args.localIp, tt.args.serverPort, tt.args.mailBox); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("NewDroneID() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestSendDroneIDHeart(t *testing.T) {
	tests := []struct {
		name string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			SendDroneIDHeart()
		})
	}
}

func TestV2DroneIDOfflineReport(t *testing.T) {
	type args struct {
		sn   string
		port int
	}
	tests := []struct {
		name string
		args args
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			V2DroneIDOfflineReport(tt.args.sn, tt.args.port)
		})
	}
}
