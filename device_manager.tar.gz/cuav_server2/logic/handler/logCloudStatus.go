package handler

import (
	"context"
	"errors"
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"gorm.io/gorm"
)

type LogCloudStatus struct {
}

func NewLogCloudStatus() *LogCloudStatus {
	return &LogCloudStatus{}
}
func (w *LogCloudStatus) Insert(ctx context.Context, req *client.LogCloudStatusInsertReq, res *client.LogCloudStatusInsertRsp) error {
	var model bean.LogCloudStatus

	model.Status = req.Status
	model.Path = req.Path
	model.Proid = req.Proid
	logger.Info("Into Insert Log Cloud Status")

	var logcloudstat bean.LogCloudStatus
	if err := db.GetDB().Model(&bean.LogCloudStatus{}).Where("id = ?", 1).First(&logcloudstat).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			if err := db.GetDB().Model(&bean.LogCloudStatus{}).Create(&model).Error; err != nil {
				logger.Errorf("create Log Cloud Status error: %v", err)
				return err
			}
			return nil
		}
		logger.Errorf("query Log Cloud Status error:", err)
		return err
	}
	return nil
}
func (w *LogCloudStatus) Update(ctx context.Context, req *client.LogCloudStatusUpdateReq, rsp *client.LogCloudStatusUpdateRsp) error {
	var model bean.LogCloudStatus
	model.Status = req.Status
	logger.Info("model Status is:", model.Status)

	err := db.GetDB().Model(&bean.LogCloudStatus{}).Where("id = ?", 1).Updates(&model).Error
	if err != nil {
		return fmt.Errorf("update Log cloud Status error: id=%v no-exist", 1)
	}

	return nil
}

func (w *LogCloudStatus) Deletes(ctx context.Context, req *client.LogCloudStatusDeletesReq, rsp *client.LogCloudStatusDeletesRsp) error {
	var model bean.LogCloudStatus
	err := db.GetDB().Model(&bean.LogCloudStatus{}).Where("status = ?", model.Status).Delete(&model).Error
	if err != nil {
		logger.Errorf("delete Log Cloud Status error: %v", err)
	}

	return nil
}

func (w *LogCloudStatus) List(ctx context.Context, req *client.LogCloudStatusListReq, rsp *client.LogCloudStatusListRsp) error {
	var model bean.LogCloudStatus
	err := db.GetDB().Model(&bean.LogCloudStatus{}).Find(&model).Error
	if err != nil {
		return errors.New("query Log Cloud Status failed")
	}
	rsp.Status = model.Status
	rsp.Path = model.Path
	rsp.Proid = model.Proid
	return nil
}
