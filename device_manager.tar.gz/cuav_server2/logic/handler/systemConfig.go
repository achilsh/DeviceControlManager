package handler

import (
	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"context"
	"errors"
	"fmt"
	"google.golang.org/protobuf/proto"
	"reflect"
	"strings"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"gorm.io/gorm"
)

const (
	SysConfigFpv     int32 = 1
	SysConfigTracerS int32 = 2
)

type SystemConfig struct {
}

func NewSystemConfig() *SystemConfig {
	return &SystemConfig{}
}

func (s *SystemConfig) Insert(ctx context.Context, req *client.CrudReq, res *client.CrudRes) error {
	var model bean.SystemConfig
	err := db.GetDB().Model(&bean.SystemConfig{}).Where("id = ?", req.Id).First(&model).Error
	if err == nil {
		return errors.New("record already exists")
	}
	if err == gorm.ErrRecordNotFound {
		s.generate(&model, req)
		err := db.GetDB().Model(&bean.SystemConfig{}).Create(&model).Error
		if err != nil {
			logger.Errorf("create system config error:%v", err)
			return err
		}
		return nil
	}
	return err
}

func (s *SystemConfig) Update(ctx context.Context, req *client.CrudReq, res *client.CrudRes) error {
	var model bean.SystemConfig
	s.generate(&model, req)
	err := db.GetDB().Model(&bean.SystemConfig{}).Where("id = ?", req.Id).Save(&model).Error
	if err != nil {
		logger.Errorf("update failed,error:%v", err)
		return err
	}
	var sysconfig bean.SystemConfig
	err = db.GetDB().Model(&bean.SystemConfig{}).First(&sysconfig).Error
	if err != nil {
		logger.Errorf("query system config failed,err:%v", err)
		return err
	}
	config := config.C2ConfigStr{
		Id:            int64(sysconfig.Id),
		Longitude:     sysconfig.Longitude,
		Latitude:      sysconfig.Latitude,
		Heading:       int64(sysconfig.Heading),
		WarningRadius: sysconfig.WarningRadius,
		CounterRadius: sysconfig.CounterRadius,
		FenceRadius:   sysconfig.FenceRadius,
		ScannerRadius: sysconfig.ScannerRadius,
		Height:        sysconfig.Height,
		C2Longitude:   sysconfig.C2Longitude,
		C2Latitude:    sysconfig.C2Latitude,
	}
	C2Config.Set("c2config", config)
	//if fpv is online, then write down config info.
	s.NotifyFpvConfig(req)
	//
	//logger.Infof("update c2 config, req: %v", req.String())
	s.NotifyTracerSConfig(req)

	return nil
}

func (s *SystemConfig) Delete(ctx context.Context, req *client.CrudReq, res *client.CrudRes) error {
	var model bean.SystemConfig
	s.generate(&model, req)
	err := db.GetDB().Model(&bean.SystemConfig{}).Where("id = ?", model.Id).Delete(&model).Error
	if err != nil {
		logger.Errorf("delete failed,error:%v", err)
		return err
	}
	return nil
}

func (s *SystemConfig) GetSystemConfig(ctx context.Context, req *client.ConfigReq, res *client.ConfigRes) error {
	var model bean.SystemConfig
	err := db.GetDB().Model(&bean.SystemConfig{}).First(&model).Error
	if err != nil {
		logger.Errorf("query system config failed,err:%v", err)
		return err
	}
	res.Id = model.Id
	res.Latitude = model.Latitude
	res.Heading = model.Heading
	res.Arch = model.Arch
	res.EType = model.Etype
	res.TerminalId = model.TerminalId
	res.CounterRadius = model.CounterRadius
	res.WarningRadius = model.WarningRadius
	res.FenceRadius = model.FenceRadius
	res.Longitude = model.Longitude
	res.ScannerRadius = model.ScannerRadius
	res.Height = model.Height
	res.C2Longitude = model.C2Longitude
	res.C2Latitude = model.C2Latitude
	return nil
}
func (s *SystemConfig) generate(model *bean.SystemConfig, req *client.CrudReq) {
	model.Id = req.Id
	model.Longitude = req.Longitude
	model.TerminalId = req.TerminalId
	model.Latitude = req.Latitude
	model.Arch = req.Arch
	model.Heading = req.Heading
	model.Etype = req.EType
	model.CounterRadius = req.CounterRadius
	model.WarningRadius = req.WarningRadius
	model.FenceRadius = req.FenceRadius
	model.ScannerRadius = req.ScannerRadius
	model.Height = req.Height
	model.C2Longitude = req.C2Longitude
	model.C2Latitude = req.C2Latitude
}

type NotifySysCfgData struct {
	lk                sync.Mutex
	NotifyFpvInterval time.Time
}

var notifySysCfgItem *NotifySysCfgData = &NotifySysCfgData{
	NotifyFpvInterval: time.Now(),
}
var notifyTracerSSysCfgItem *NotifySysCfgData = &NotifySysCfgData{
	NotifyFpvInterval: time.Now(),
}

func (p *NotifySysCfgData) Lock() {
	p.lk.Lock()
}
func (p *NotifySysCfgData) Unlock() {
	p.lk.Unlock()
}
func (p *NotifySysCfgData) GetTime() time.Time {
	return p.NotifyFpvInterval
}
func (p *NotifySysCfgData) UpdateTime(tm time.Time) {
	p.NotifyFpvInterval = tm
}

func (s *SystemConfig) NotifyFpvConfig(req *client.CrudReq) {
	if req == nil {
		return
	}
	if !FvpOnLineStatus.IsOnLine() {
		return
	}

	notifySysCfgItem.Lock()
	defer notifySysCfgItem.Unlock()

	if time.Since(notifySysCfgItem.GetTime()) < 1*time.Second {
		return
	}
	logger.Infof("update since: %v second", time.Since(notifySysCfgItem.GetTime())/time.Second)

	notifySysCfgItem.UpdateTime(time.Now())
	itemData, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("marshal sys req msg fail, e: %v", err)
		return
	}

	toWriteDownCfg := &client.SystemConfigInfo{
		MsgType: SysConfigFpv,
		Data:    itemData,
	}

	out, err := proto.Marshal(toWriteDownCfg)
	if err != nil {
		logger.Error("marshal fpv sys config err:", err)
		return
	}

	_ = mq.FpvMsgBroker.Publish(mq.FpvSysConfig, broker.NewMessage(out))
	logger.Infof("has fvp config sys, devSn: %v", "")
}

func GetOnlineTracerSSn() []string {
	var TracerSDevStatus map[string]any = make(map[string]any)
	DevStatusMap.Range(func(k any, v any) bool {
		if reflect.ValueOf(k).Kind() != reflect.String {
			return true
		}
		TracerSDevStatus[k.(string)] = v
		return true
	})

	snList := []string{}
	var tracerSnPrefix string = fmt.Sprintf("%d_", common.DEV_V2DRONEID)
	for k, v := range TracerSDevStatus {
		if len(k) <= 0 {
			continue
		}
		index := strings.Index(k, tracerSnPrefix)
		if index <= -1 || index > 0 {
			continue
		}

		droneId, ok := v.(*Device)
		if !ok || droneId == nil {
			continue
		}

		if droneId.WorkMode == 2 || droneId.WorkMode == 3 {
			sns := strings.Split(k, tracerSnPrefix)
			if len(sns) <= 1 || len(sns) > 2 {
				continue
			}
			snList = append(snList, sns[1])
		}
	}
	return snList
}
func (s *SystemConfig) NotifyTracerSConfig(req *client.CrudReq) {
	if req == nil {
		return
	}

	if len(GetOnlineTracerSSn()) <= 0 {
		//logger.Infof("has not any online tracerS device.")
		return
	}
	//logger.Infof("need to send sys config for tracerS, as has online tracerS")

	notifyTracerSSysCfgItem.Lock()
	defer notifyTracerSSysCfgItem.Unlock()

	if time.Since(notifyTracerSSysCfgItem.GetTime()) < 1*time.Second {
		return
	}
	logger.Infof("update since: %v second", time.Since(notifyTracerSSysCfgItem.GetTime())/time.Second)

	notifyTracerSSysCfgItem.UpdateTime(time.Now())
	itemData, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("marshal sys req msg fail, e: %v", err)
		return
	}

	toWriteDownCfg := &client.SystemConfigInfo{
		MsgType: SysConfigTracerS,
		Data:    itemData,
	}

	out, err := proto.Marshal(toWriteDownCfg)
	if err != nil {
		logger.Error("marshal tracerS sys config err:", err)
		return
	}

	_ = mq.FpvMsgBroker.Publish(mq.FpvSysConfig, broker.NewMessage(out))
	logger.Infof("has tracerS config sys, devSn: %v", "")
}
