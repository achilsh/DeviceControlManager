package handler

import (
	"context"
	"errors"
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
)

type C2License struct {
}

func NewC2License() *C2License {
	return &C2License{}
}
func (w *C2License) Insert(ctx context.Context, req *client.C2LicenseInsertReq, res *client.C2LicenseInsertRsp) error {
	var model bean.C2License

	model.LicenseId = req.LicenseId
	model.MacAddr = req.MacAddr
	model.StartTime = req.StartTime
	model.StopTime = req.StopTime
	model.LastTime = req.LastTime
	model.LicenseType = req.LicenseType
	model.Expires = req.Expires
	model.UserName = req.UserName
	model.UserPhone = req.UserPhone
	model.UserEmail = req.UserEmail

	logger.Info("Into Insert C2 License")

	var c2license bean.C2License
	db.GetDB().Model(&bean.C2License{}).Where("mac_addr = ?", req.MacAddr).First(&c2license)
	if c2license.LicenseId != "" {
		c2license.LastTime = req.LastTime
		err := db.GetDB().Model(&bean.C2License{}).Where("mac_addr = ?", req.MacAddr).Updates(&c2license).Error
		if err != nil {
			logger.Error("Updates c2license err:", err)
		}
	} else {
		err := db.GetDB().Model(&bean.C2License{}).Create(&model).Error
		if err != nil {
			logger.Error("Create c2license err:", err)
		}
	}
	return nil
}
func (w *C2License) Update(ctx context.Context, req *client.C2LicenseUpdateReq, rsp *client.C2LicenseUpdateRsp) error {
	var model bean.C2License

	model.StartTime = req.StartTime
	model.StopTime = req.StopTime
	model.LastTime = req.LastTime

	err := db.GetDB().Model(&bean.C2License{}).Where("mac_addr = ?", req.MacAddr).Updates(&model).Error
	if err != nil {
		return fmt.Errorf("update C2 License error: MacAddr=%v no-exist", req.MacAddr)
	}

	return nil
}

func (w *C2License) Deletes(ctx context.Context, req *client.C2LicenseDeletesReq, rsp *client.C2LicenseDeletesRsp) error {
	var model bean.C2License
	err := db.GetDB().Model(&bean.C2License{}).Where("mac_addr = ?", req.MacAddr).Delete(&model).Error
	if err != nil {
		logger.Errorf("delete C2 License error: %v", err)
	}

	return nil
}

func (w *C2License) List(ctx context.Context, req *client.C2LicenseListReq, rsp *client.C2LicenseListRsp) error {
	var list []*bean.C2License
	err := db.GetDB().Model(&bean.C2License{}).Find(&list).Error
	if err != nil {
		return errors.New("query C2 License failed")
	}
	for _, v := range list {
		var model client.LicenseList
		w.generateRes(&model, *v)
		rsp.LicenseList = append(rsp.LicenseList, &model)
	}
	return nil
}
func (w *C2License) generateRes(model *client.LicenseList, list bean.C2License) {
	model.LicenseId = list.LicenseId
	model.MacAddr = list.MacAddr
	model.StartTime = list.StartTime
	model.StopTime = list.StopTime
	model.LastTime = list.LastTime
	model.LicenseType = list.LicenseType
	model.Expires = list.Expires
	model.UserName = list.UserName
	model.UserPhone = list.UserPhone
	model.UserEmail = list.UserEmail
}
