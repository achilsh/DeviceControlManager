package handler

import (
	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	"adasgitlab.autel.com/tools/cuav_plugin/broker/memory"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
	"context"
	"fmt"
	jsoniter "github.com/json-iterator/go"
	"strconv"
	"sync"
	"testing"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	gbroker "go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"
)

type demoOne struct {
	A int32 `json:"a"`
}

func TestProtoMashing(t *testing.T) {
	d := &client.EquipmentMessageBoxEntity{
		Name: "11111",
	}

	v, _ := proto.Marshal(d)

	var g client.EquipmentMessageBoxEntity
	e := proto.Unmarshal(v, &g)
	t.Logf("e: %v, g: %v", e, g)

}

func TestCreateBusiHeartTable(t *testing.T) {
	sn := "111_test_1231"
	heartEntities := make([]bean.FpvReplayHeartData, 0, batchSize)
	dataInfo := client.FpvHeartInfo{
		Data: &client.FpvHeartInfoReport{
			TimeStamp:     111111,
			Electricity:   1,
			Sn:            sn,
			IsOnline:      1,
			BatteryStatus: 1,
			WorkMode:      1,
			WorkStatus:    1,
			AlarmLevel:    1,
		},
	}

	heartEntities = append(heartEntities, bean.FpvReplayHeartData{
		Sn:            sn,
		IsOnline:      helper.TranBaseType[int, int32](dataInfo.GetData().GetIsOnline()),
		BatteryStatus: helper.TranBaseType[int, int32](dataInfo.GetData().GetBatteryStatus()),
		Electricity:   helper.TranBaseType[int, int32](dataInfo.GetData().GetElectricity()),
		WorkMode:      helper.TranBaseType[int, int32](dataInfo.GetData().GetWorkMode()),
		WorkStatus:    helper.TranBaseType[int, int32](dataInfo.GetData().GetWorkStatus()),
		AlarmLevel:    helper.TranBaseType[int, int32](dataInfo.GetData().GetAlarmLevel()),
		CreateTime:    time.Now().UnixMilli(),
	})

	createBusiHeartTable[bean.FpvReplayHeartData](db.GetDB(), sn, 0)
	if err := db.GetDB().Table(bean.FpvReplayHeartData{}.GetTableName(sn)).Create(&heartEntities).Error; err != nil {
		logger.Errorf("consume fpv heart data, write to db fail, e: %v", err)
	}
	time.Sleep(1 * time.Second)

	delBusiHeartTable[bean.FpvReplayHeartData](db.GetDB(), sn)
}

type RadarDataSrcGenerator struct {
	ctx context.Context
	cf  context.CancelFunc
	tmr *helper.GeneralTaskTimer
}

var (
	demoRadarHeartBroker gbroker.Broker
	snGenerator          int

	demoRadarPostureBroker gbroker.Broker
)

func createRadarheartBroker() {
	demoRadarHeartBroker = memory.NewBroker()
}

func NewRadarDataSrcGenerator() *RadarDataSrcGenerator {
	c, cf := context.WithCancel(context.Background())
	r := &RadarDataSrcGenerator{
		ctx: c,
		cf:  cf,
	}
	r.tmr = helper.NewGeneralTaskTimer("1s", helper.RegisterTaskProcess(r))
	return r
}
func (r *RadarDataSrcGenerator) Process() error {
	data := &common.RadarStatusEntity{
		Electricity: int32(snGenerator),
		Status:      1,                                     //系统状态0：正常工作	1：待机
		IsOnline:    1,                                     // `json:"is_online"`
		Ip:          "127.0.0.1",                           //   `json:"ip"`         //ip地址
		SerialNum:   "serial_" + strconv.Itoa(snGenerator), // `json:"serial_num"` //序列号
		Faults:      []string{"11", "22"},                  // `json:"faults"`     //故障信息
	}

	sn := "test_radar_" + strconv.Itoa(snGenerator)
	snGenerator = snGenerator + 1

	entity := &common.EquipmentMessageBoxEntity{
		Name:      sn,
		Sn:        sn,
		MsgType:   mavlink.RadarIdHeartbeat,
		EquipType: int(common.DEV_RADAR),
		Info:      data,
	}
	demoRadarHeartBroker.Publish(mq.EquipmentStatusTopic, broker.NewMessage(entity))
	return nil
}

func (r *RadarDataSrcGenerator) CancelHeartGen() {
	r.cf()
}
func (r *RadarDataSrcGenerator) consumerHeartOnRadar(ctx context.Context) {
	heartEntities := make([]bean.RadarReplayHeart, 0, batchSize)
	mu := sync.Mutex{}
	_, _ = demoRadarHeartBroker.Subscribe(mq.EquipmentStatusTopic, func(event gbroker.Event) error {

		select {
		case <-ctx.Done():
			logger.Infof("receive stop..")
			return nil
		default:
			//
		}
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("consumeRadarTcpHeartInfo Unmarshal error: %v", err)
		}
		if entity.MsgType == 0 {
			return nil
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		heart := bean.RadarTcpHeart{}
		err = jsoniter.Unmarshal(infoJson, &heart)
		if err != nil {
			return fmt.Errorf("consumeRadarTcpHeartInfo Unmarshal info error: %v", err)
		}
		heart.Sn = entity.Sn
		mu.Lock()
		defer mu.Unlock()

		heartEntities = append(heartEntities, bean.RadarReplayHeart{
			Sn:          heart.Sn,
			IsOnline:    1, //1在线、2离线
			Electricity: int(heart.Electricity),
			CreateTime:  time.Now().UnixMilli(),
		})

		createRadarHeartTable(entity.Sn)
		if err = db.GetDB().Table(bean.RadarReplayHeart{}.GetTableName(entity.Sn)).Create(&heartEntities).Error; err != nil {
			logger.Errorf("consumeRadarTcpHeartInfo create error: %v", err)
		}
		heartEntities = heartEntities[0:0]

		return nil
	})
}

func TestRadarHeartSrcGenerator(t *testing.T) {
	heartG := NewRadarDataSrcGenerator()

	go func() {
		heartG.consumerHeartOnRadar(heartG.ctx)
	}()

	heartG.tmr.DoTask(heartG.ctx)
	time.Sleep(10 * time.Second)

	heartG.CancelHeartGen()
}

func createRadarPostureBroker() {
	demoRadarPostureBroker = memory.NewBroker()
}

type DemoCheckColumnExist struct {
	A int32   `json:"a_col"`
	B float32 `json:"b_col" gorm:"index"` //
	C string  `jons:"c_col"`
}

func (d *DemoCheckColumnExist) TableName() string {
	return "tab_test_check_col"
}

func removeDemoCheckTab() {
	utils.CheckAndDeleteTab[DemoCheckColumnExist](db.GetDB(), new(DemoCheckColumnExist).TableName(), new(DemoCheckColumnExist))
}
func TestCheckTabColumnExistAndProc(t *testing.T) {
	utils.CheckTabCondCreateTab[DemoCheckColumnExist](db.GetDB(), new(DemoCheckColumnExist).TableName(), new(DemoCheckColumnExist),
		utils.WithTableCond[DemoCheckColumnExist](nil, new(DemoCheckColumnExist).TableName()),
		utils.WithIndexCond[DemoCheckColumnExist](new(DemoCheckColumnExist), "b"),
		utils.WithColFieldCond2[DemoCheckColumnExist](new(DemoCheckColumnExist).TableName(), "c"))
}
