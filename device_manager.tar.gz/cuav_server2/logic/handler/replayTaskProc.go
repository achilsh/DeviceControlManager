package handler

import (
	"context"
	"errors"
	"fmt"
	"strconv"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

const (
	ReplayTaskSuccess = 1
	ReplayTaskFail    = 2
)
const (
	QueryItemMaxLen int32 = 4096
)

const (
	ReplayTypeMsg         int32 = iota
	ReplayTypeHEART       int32 = 1 //
	ReplayTypeDetect      int32 = 2
	ReplayTypePosture     int32 = 3
	ReplayTypeHit         int32 = 4
	ReplayTypeSpectrum    int32 = 5
	ReplayTypeC2SysConfig int32 = 6
)

// ReplayDataTypes 把所有的replay 数据汇总到一个列表中，每次开启 回放时，遍历所有的回放数据类型，过滤 DevTaskTableConfigured
// 未被注册的回放数据类型
var ReplayDataTypes map[int32]string = map[int32]string{
	ReplayTypeHEART:       "ReplayHEART",
	ReplayTypeDetect:      "ReplayDetect",
	ReplayTypePosture:     "ReplayPosture",
	ReplayTypeHit:         "ReplayHit",
	ReplayTypeSpectrum:    "ReplaySpectrum",
	ReplayTypeC2SysConfig: "C2SysConfig",
	//if add new device, and need to replay this device message except above， add and write new definition below.
}

func GetReplayDataTypeDesc(dataType int32) string {
	v, ok := ReplayDataTypes[dataType]
	if !ok {
		return ""
	}
	return v
}

// DevTaskTableConfigured 定义replay 设备对应的数据能力，
var DevTaskTableConfigured = map[int32]map[int32]bool{
	int32(client.EnumDevTypeList_RadarDevTypeEnum): { //radar 雷达，
		ReplayTypeHEART:   true,
		ReplayTypeDetect:  true,
		ReplayTypePosture: true,
	},

	int32(client.EnumDevTypeList_TracerPDevTypeEnum): { //tracerP
		ReplayTypeDetect: true,
	},
	int32(client.EnumDevTypeList_TracerSDevTypeEnum): { //tracerS
		ReplayTypeHEART:       true,
		ReplayTypeDetect:      true,
		ReplayTypeC2SysConfig: true,
	},
	int32(client.EnumDevTypeList_FpvDevTypeEnum): { //FPV
		ReplayTypeHEART:       true,
		ReplayTypeDetect:      true,
		ReplayTypeC2SysConfig: true,
	},
	int32(client.EnumDevTypeList_GunDevTypeEnum): { //反置枪
		ReplayTypeHEART: true,
	},
	int32(client.EnumDevTypeList_SFLDevTypeEnum): { //sfl 哨兵塔
		ReplayTypeHEART:  true,
		ReplayTypeDetect: true,
		ReplayTypeHit:    true,
	},
	int32(client.EnumDevTypeList_SpooferDevTypeEnum): { // dev_nsf4000  导航诱导
		ReplayTypeHEART: true,
	},
	int32(client.EnumDevTypeList_UrdDevTypeEnum): { //dev_urd360 坤雷RF
		ReplayTypeHEART:    true,
		ReplayTypeDetect:   true,
		ReplayTypeSpectrum: true,
	},
}

var (
	TasksMng = NewReplayTaskMng()

	HandlerReplayStartLogic         = new(ReplayStartLogic)
	HandlerReplayStopLogic          = new(ReplayStopLogic)
	HandlerReplayRateChangeLogic    = new(ReplayRateChangeLogic)
	HandlerReplayDevListChangeLogic = new(ReplayDevListChangeLogic)

	HandlerReplayPause    = new(ReplayPauseLogic)
	HandlerReplayContinue = new(ReplayContinueLogic)
)

type FilterType = bool

var (
	IsFiltered FilterType = true
	NoFiltered FilterType = false
)

// FilterTask 如果不存在关系或关系值为false，则返回true; 映射关系需要手动维护。
func FilterTask(devType, taskType int32) FilterType {
	tasksSet, ok := DevTaskTableConfigured[devType]
	if !ok {
		return IsFiltered
	}
	if len(tasksSet) <= 0 {
		return IsFiltered
	}

	task, ok := tasksSet[taskType]
	if !ok {
		return IsFiltered
	}
	if !task {
		return IsFiltered
	}
	return NoFiltered
}

type OptionTaskBase func(*ReplayTaskBase)

func WithQueryStartTime(s int64) OptionTaskBase {
	if s <= 0 {
		logger.Infof("input start time is nil")
		return nil
	}
	return func(opt *ReplayTaskBase) {
		opt.QueryStartTime = s
	}
}
func WithQueryLen(nums int32) OptionTaskBase {
	if nums <= 0 {
		nums = QueryItemMaxLen
	}
	return func(opt *ReplayTaskBase) {
		opt.DefaultQueueSize = nums
	}
}
func WithQueryEndTime(e int64) OptionTaskBase {
	if e <= 0 {
		logger.Infof("input end time is nil")
		return nil
	}
	return func(opt *ReplayTaskBase) {
		opt.QueryDbEndTime = e
	}
}
func WithConsumerQueueBoundTime(b int64) OptionTaskBase {
	if b <= 0 {
		logger.Infof("consumer queue bound time is nil")
		return nil
	}
	return func(opt *ReplayTaskBase) {
		opt.BoundUnixTimeMs = b
	}
}

// NewReplayTask q *helper.SkyFendPQWrap[ValueType], m *LocalMem, sn string, devType, replayType int32, rtm *DataReplayer
func NewReplayTask(q *helper.SkyFendPQWrap[ValueType], m *LocalMem, sn string, devType, replayType int32, rtm *DataReplayer, opts ...OptionTaskBase) IReplayTaskAbstract {
	baseTask := ReplayTaskBase{
		QueueRef:               q,
		SingleMemRef:           m,
		ReplayType:             replayType,
		Sn:                     sn,
		DevType:                devType,
		TaskMngRef:             rtm,
		TriggerLoadDbQueueSize: 100,
	}
	for _, opt := range opts {
		opt(&baseTask)
	}

	var ret IReplayTaskAbstract
	switch replayType {
	case ReplayTypeC2SysConfig:
		ret = &ReplayC2SysConfigTask{
			ReplayTaskBase: baseTask,
		}

	case ReplayTypeHEART:
		ret = &ReplayHeartTask{
			ReplayTaskBase: baseTask,
		}

	case ReplayTypeDetect:
		ret = &ReplayDetectTask{
			ReplayTaskBase: baseTask,
		}

	case ReplayTypePosture:
		ret = &ReplayPostureTask{
			ReplayTaskBase: baseTask,
		}

	case ReplayTypeHit:
		ret = &ReplayHitTask{
			ReplayTaskBase: baseTask,
		}

	case ReplayTypeSpectrum:
		ret = &ReplayInduceTask{
			ReplayTaskBase: baseTask,
		}

	default:
		logger.Errorf("not support replay type: %v", replayType)
		return nil

	}
	logger.Infof("create new task, %+v", ret.BasicInfo())
	return ret
}

func DoGeneralTask(task *ReplayTaskBase) [][]byte {
	toReplayData := make([][]byte, 0)

	busiData := task.FetchData()
	if busiData == nil || len(busiData) <= 0 {
		logger.Infof("has not data from queue, task info: %v", task.GetDevSnTaskType())
		return nil
	}
	logger.Infof("replay data item nums: %v, task info: %v", len(busiData), task.GetDevSnTaskType())

	memHandler := task.TaskMngRef.GetLocalMemHandler(task.Sn, task.ReplayType)
	if memHandler == nil {
		logger.Infof("not exist local mem handle, maybe not register in init, task info: %v", task.GetDevSnTaskType())
		return nil
	}

	toDelCacheKey := make([]string, 0)
	for _, keyItem := range busiData {
		if keyItem == nil || len(keyItem.Value) <= 0 {
			continue
		}

		buisDataUnmarshal, e := memHandler.GetCache().Get(keyItem.Value)
		if e != nil {
			logger.Errorf("get data from big cache fail, task info: %v", task.GetDevSnTaskType())
			continue
		}
		if len(buisDataUnmarshal) <= 0 {
			logger.Infof("busi data in local cache is empty, task info: %v", task.GetDevSnTaskType())
			continue
		}
		toDelCacheKey = append(toDelCacheKey, keyItem.Value)

		toReplayData = append(toReplayData, buisDataUnmarshal)
	}
	logger.Infof("data form big cache nums: %v,  task info: %v", len(toReplayData), task.GetDevSnTaskType())

	for _, key := range toDelCacheKey {
		_ = memHandler.GetCache().Delete(key)
	}
	return toReplayData
}

type ReplayC2SysConfigTask struct {
	ReplayTaskBase
	SysConfigDataReplay [][]byte
}

func (r *ReplayC2SysConfigTask) GetData() [][]byte {
	return r.SysConfigDataReplay
}
func (r *ReplayC2SysConfigTask) DoTask() {
	r.SysConfigDataReplay = DoGeneralTask(&(r.ReplayTaskBase))
}

// ReplayHeartTask 每一种 replay 数据的replay 任务。
type ReplayHeartTask struct {
	ReplayTaskBase
	HeartDataReplay [][]byte //一次会获取设备的多个心跳。
}

func (r *ReplayHeartTask) GetData() [][]byte {
	return r.HeartDataReplay
}

// DoTask 从 queue中读取心跳数据
func (r *ReplayHeartTask) DoTask() {
	r.HeartDataReplay = DoGeneralTask(&(r.ReplayTaskBase))
}

type ReplayDetectTask struct {
	ReplayTaskBase
	DetectDataReplay [][]byte
}

// DoTask 从 queue中读取 监测 数据
func (r *ReplayDetectTask) DoTask() {
	r.DetectDataReplay = DoGeneralTask(&(r.ReplayTaskBase))
}
func (r *ReplayDetectTask) GetData() [][]byte {
	return r.DetectDataReplay
}

type ReplayPostureTask struct {
	ReplayTaskBase
	PostureReplayData [][]byte
}

// DoTask  从 queue中读取 姿态 数据
func (r *ReplayPostureTask) DoTask() {
	r.PostureReplayData = DoGeneralTask(&(r.ReplayTaskBase))
}
func (r *ReplayPostureTask) GetData() [][]byte {
	return r.PostureReplayData
}

// ReplayHitTask 从 queue中读取 hit 数据
type ReplayHitTask struct {
	ReplayTaskBase
	HitReplayData [][]byte
}

func (r *ReplayHitTask) GetData() [][]byte {
	return r.HitReplayData
}

func (r *ReplayHitTask) DoTask() {
	r.HitReplayData = DoGeneralTask(&(r.ReplayTaskBase))
}

// ReplayInduceTask 从 queue中读取 induce 数据
type ReplayInduceTask struct {
	ReplayTaskBase
	InduceReplayData [][]byte
}

func (r *ReplayInduceTask) DoTask() {
	r.InduceReplayData = DoGeneralTask(&(r.ReplayTaskBase))
}
func (r *ReplayInduceTask) GetData() [][]byte {
	return r.InduceReplayData
}

// GetBusinessTaskProc 根据请求的参数获取处理对象
func GetBusinessTaskProc(opType int32) BusinessTaskAbstract {
	var ret BusinessTaskAbstract = nil
	switch opType {
	case int32(client.EnumReplayOpSwitch_Start):
		ret = HandlerReplayStartLogic

	case int32(client.EnumReplayOpSwitch_Stop):
		ret = HandlerReplayStopLogic

	case int32(client.EnumReplayOpSwitch_RateChange):
		ret = HandlerReplayRateChangeLogic

	case int32(client.EnumReplayOpSwitch_DevListChange):
		ret = HandlerReplayDevListChangeLogic
	default:
		ret = nil
	}
	return ret
}

type BusinessTaskAbstract interface {
	Call(req *client.ReplayDeviceStartStopRequest, res *client.ReplayDeviceOpResponse) error
}

// ReplayStartLogic 处理api 请求逻辑: start replay
type ReplayStartLogic struct {
}

func ParseTimeFromStringToInt64(startStr, endStr *string) (startI64, endI64 int64, err error) {
	if startStr == nil || endStr == nil || len(*startStr) <= 0 || len(*endStr) <= 0 {
		logger.Infof("input time string is not ok")
		return 0, 0, errors.New("time param is no ok")
	}

	startI64, err = strconv.ParseInt(*startStr, 10, 64)
	if err != nil {
		logger.Errorf("parse start time from: %v to int64 fail,e: %v", err)
		return 0, 0, errors.New("parse start time fail")
	}

	endI64, err = strconv.ParseInt(*endStr, 10, 64)
	if err != nil {
		logger.Errorf("parse end time from: %v to int64 fail, e: %v", err)
		return 0, 0, errors.New("parse end time fail")
	}

	if startI64 < 0 || endI64 <= 0 || startI64 >= endI64 {
		logger.Errorf("begin time and end time is invalid")
		return 0, 0, errors.New("begin time and end time is invalid")
	}
	return
}

// Call 启动任务
func (r *ReplayStartLogic) Call(req *client.ReplayDeviceStartStopRequest,
	res *client.ReplayDeviceOpResponse) error {
	res.Status = ReplayTaskSuccess

	var restartOp bool = false
	logger.Infof("start replay req, req msg: %v", req.String())

	if TasksMng.IsRunning() {
		logger.Infof("start replay is doing, req start need to restart it.")
		restartOp = true
	}

	if restartOp {
		stopReq := &client.ReplayDeviceStartStopRequest{
			Ops: int32(client.EnumReplayOpSwitch_Stop),
		}
		stopResp := &client.ReplayDeviceOpResponse{}
		err := HandlerReplayStopLogic.Call(stopReq, stopResp)
		if err != nil || stopResp.Status == ReplayTaskFail {
			logger.Errorf("stop fail for restart req: %v", req.String())
			res.Status = ReplayTaskFail
			return nil
		}
		logger.Infof("stop succ for restart req: %v", req.String())
	}

	//参数校验
	bi64, ei64, e := ParseTimeFromStringToInt64(&req.BeginTime, &req.EndTime)
	if e != nil {
		res.Status = ReplayTaskFail
		return nil
	}
	if req.Rate <= 0 {
		logger.Errorf("start replay rate is 0")
		res.Status = ReplayTaskFail
		return nil
	}

	if len(req.GetDevTypeList()) <= 0 {
		logger.Infof("start replay, dev list is empty")
		res.Status = ReplayTaskFail
		return nil
	}

	//设置上下文参数：
	TasksMng.SetReplayRate(req.GetRate())
	TasksMng.SetReplayStartTime(bi64)
	TasksMng.SetReplayEndTime(ei64)

	mpSns := make(map[string]int32) //key is sn, value is dev_type
	for i := 0; i < len(req.GetDevTypeList()); i++ {
		if _, ok := mpSns[req.GetDevTypeList()[i].GetSn()]; ok {
			logger.Infof("start req param has repeated sn: %v", req.GetDevTypeList()[i].GetSn())
			continue
		}
		mpSns[req.GetDevTypeList()[i].GetSn()] = req.GetDevTypeList()[i].GetDeviceType()
	}

	snList := make([]string, 0, len(mpSns))
	devTypeList := make([]int32, 0, len(mpSns))

	for sn, snType := range mpSns {
		snList = append(snList, sn)
		devTypeList = append(devTypeList, snType)
	}

	TasksMng.SetReplayDevList(snList, devTypeList)
	TasksMng.InitQueueTaskMem()
	TasksMng.InitChan()

	//创建依赖资源和任务，包括所有的场景, 场景列表见: ReplayDataTypes
	for _, snItem := range snList { //遍历每个sn
		TasksMng.SetSnType(snItem, mpSns[snItem])

		for taskType := range ReplayDataTypes { //遍历每种replay数据类型。比如：心跳，姿态，检测，打击等。
			//检查并过滤设备类型下的业务任务，去除设备类型不需要执行该任务。
			devType, ok := mpSns[snItem]
			var notExistBusiness = false
			if ok {
				notExistBusiness = FilterTask(devType, taskType)
			}
			if notExistBusiness {
				logger.Infof("sn: %v, devType: %v, business type: %v need not run task", snItem,
					helper.DevTypeFromIntToStr(devType), GetReplayDataTypeDesc(taskType))
				continue
			}

			q := TasksMng.CreateReplayQueue(snItem, taskType)
			m := TasksMng.CreateReplayMem(context.Background(), snItem, taskType)
			TasksMng.CreateReplayTask(snItem, taskType,
				NewReplayTask(q, m, snItem, devType, taskType, TasksMng,
					WithConsumerQueueBoundTime(TasksMng.ReplayCtx.BeginTime),
					WithQueryEndTime(TasksMng.ReplayCtx.EndTime),
					WithQueryStartTime(TasksMng.ReplayCtx.BeginTime),
					WithQueryLen(QueryItemMaxLen)))
		}
	}

	//启动任务：
	strBaseRate := TasksMng.TransformRate(req.GetRate())
	TasksMng.StartWorkTimer(strBaseRate)

	TasksMng.SetRunning()
	logger.Infof("start replay is called.")
	return nil
}

// ReplayStopLogic 处理api 请求逻辑： stop replay
type ReplayStopLogic struct {
}

func (r *ReplayStopLogic) Call(req *client.ReplayDeviceStartStopRequest,
	res *client.ReplayDeviceOpResponse) error {

	res.Status = ReplayTaskSuccess

	logger.Infof("stop replay req, req msg: %v", req.String())

	if TasksMng.IsSameStatus(ReplayRunStatusStop) {
		logger.Errorf("stop replay is doing, not repeated request")
		res.Status = ReplayTaskFail
		return nil
	}
	TasksMng.StopAllReplayTasks()

	TasksMng.SetStop()
	TasksMng.StopWorkTimer()
	TasksMng.CloseNotifyReqChan()
	TasksMng.CloseNotifyAckChan()

	logger.Infof("stop replay call return")
	return nil
}

// ReplayRateChangeLogic 处理api 请求逻辑： change replay rate
type ReplayRateChangeLogic struct {
}

func (r *ReplayRateChangeLogic) Call(req *client.ReplayDeviceStartStopRequest,
	res *client.ReplayDeviceOpResponse) error {

	res.Status = ReplayTaskSuccess

	logger.Infof("change replay rate req, req msg: %v", req.String())

	if TasksMng.IsSameStatus(ReplayRunStatusStop) {
		logger.Errorf("now replay status is stop or pause, not been change rate.")
		res.Status = ReplayTaskFail
		return nil
	}

	if req.GetRate() <= 0 {
		logger.Errorf("change rate is invalid, it is: %v", req.GetRate())
		return nil
	}

	if TasksMng.ReplayCtx.GetRate() == req.GetRate() {
		logger.Infof("req change rate is same current rate, not need process.")
		return nil
	}

	strBaseRate := TasksMng.TransformRate(req.GetRate())
	TasksMng.SetReplayRate(req.GetRate())
	TasksMng.ModifyWorkTimer(strBaseRate)

	logger.Infof("change replay rate is called.")
	return nil
}

func getDelAndAddSn(reqSn []string, localSn []string) (toDelSn []string, toAddSn []string) {
	if len(localSn) <= 0 && len(reqSn) <= 0 {
		logger.Infof("not need to filter any sn")
		return
	}

	if len(localSn) <= 0 {
		logger.Infof("need to add new replay sn: %v", reqSn)
		toAddSn = reqSn
		return
	}

	if len(reqSn) <= 0 {
		logger.Infof("need to filter sn, req sn list is empty, need to del local sn: %v", localSn)
		toDelSn = localSn
		return
	}

	mpReqSn := make(map[string]bool)
	for _, rsn := range reqSn {
		mpReqSn[rsn] = true
	}

	mpLocalSn := make(map[string]bool)
	for _, lsn := range localSn {
		mpLocalSn[lsn] = true
	}

	//get to del sn: 查找本地不在请求的sn.
	for lsn := range mpLocalSn {
		if _, ok := mpReqSn[lsn]; !ok {
			toDelSn = append(toDelSn, lsn)
		}
	}

	//get to add sn: 查找请求中不在本地的sn.
	for rsn := range mpReqSn {
		if _, ok := mpLocalSn[rsn]; !ok {
			toAddSn = append(toAddSn, rsn)
		}
	}

	logger.Infof("need to add replay sn list: %v, to del replay sn list: %v", toAddSn, toDelSn)
	return
}

// ReplayDevListChangeLogic 处理api 请求逻辑： change  replay device list
type ReplayDevListChangeLogic struct {
}

type AddedNewReplaySnItem struct {
	Sn        string
	StartTime int64
	EndTime   int64
	DevType   int32
}

func (a *AddedNewReplaySnItem) String() string {
	if a == nil {
		return ""
	}
	s := fmt.Sprintf("sn: %v, startTime: %v, endTime: %v, devType: %v", a.Sn, a.StartTime, a.EndTime, a.DevType)
	return s
}

func CheckStartEndTime(begin, end string) (int64, int64, error) {
	startTime, endTime, e := ParseTimeFromStringToInt64(&begin, &end)
	if e != nil {
		//res.Status = ReplayTaskFail
		logger.Errorf("has new sn to add replay, but start/end time in invalid.")
		return 0, 0, e
	}

	if startTime < 0 || endTime <= 0 || startTime >= endTime {
		logger.Infof("add new replay sn start time and end time is invalid, s: %v, e: %v", startTime, endTime)
		//res.Status = ReplayTaskFail

		return 0, 0, errors.New("invalid time for start and end time")
	}
	return startTime, endTime, nil
}
func (r *ReplayDevListChangeLogic) Call(req *client.ReplayDeviceStartStopRequest,
	res *client.ReplayDeviceOpResponse) error {

	res.Status = ReplayTaskSuccess

	logger.Infof("change replay dev list req, req msg: %v", req.String())

	if TasksMng.IsSameStatus(ReplayRunStatusStop) {
		logger.Errorf("current status is stop, can not been change replay dev list")
		res.Status = ReplayTaskFail
		return nil
	}

	var toReqSnList []string
	for _, item := range req.GetDevTypeList() {
		if item == nil {
			continue
		}
		toReqSnList = append(toReqSnList, item.GetSn())
	}

	var toLocalSnList []string
	if TasksMng.ReplayCtx != nil {
		for _, item := range TasksMng.ReplayCtx.ReplayDeviceList {
			if item == nil {
				continue
			}
			toLocalSnList = append(toLocalSnList, item.sn)
		}
	}

	toDel, toAdd := getDelAndAddSn(toReqSnList, toLocalSnList)

	startTime, endTime := int64(0), int64(0)
	if len(toAdd) > 0 {
		var e error
		startTime, endTime, e = CheckStartEndTime(req.BeginTime, req.EndTime)
		if e != nil {
			res.Status = ReplayTaskFail
			return nil
		}
	}

	if len(toDel) > 0 {
		if TasksMng.IsPause() { //因为暂停，删除sn将不会在定时器里做，所以需要手动删除
			for _, sn := range toDel {
				TasksMng.DeleteReplayTaskBySn(sn)
			}
		} else {

			toDelSnCh := DelSnChData{
				SnLists: toDel,
			}

			logger.Infof("begin send del sn list to timer processor")
			TasksMng.StopFlag.Store(true)
			TasksMng.DelSnNotifyReqCh <- toDelSnCh

			logger.Infof("begin receive del sn list ack")
			<-TasksMng.DelSnNotifyAckCh
			TasksMng.StopFlag.Store(false)

			logger.Infof("receive del sn ack done.")
		}
		logger.Infof("del replay task for sn: %v", toDel)
	}

	var notifyAddItem []*AddedNewReplaySnItem
	for _, sn := range toAdd {
		for _, reqSnInfo := range req.GetDevTypeList() {
			if reqSnInfo == nil {
				continue
			}
			if reqSnInfo.Sn == sn {
				notifyAddItem = append(notifyAddItem, &AddedNewReplaySnItem{
					Sn:        sn,
					DevType:   reqSnInfo.GetDeviceType(),
					StartTime: startTime,
					EndTime:   endTime,
				})
			}
		}
		logger.Infof("new replay sn notify: %+v", notifyAddItem)
	}

	if len(toAdd) > 0 {
		//新增 sn 复用原来的倍数；重新配置 start / end time ; 创建新任务，新loader.
		if TasksMng.IsPause() {
			for _, item := range notifyAddItem {
				if item == nil {
					continue
				}
				TasksMng.AddReplayTaskBySn(item)
			}

		} else {
			TasksMng.AddSnNotifyReqCh <- notifyAddItem
			<-TasksMng.AddSnNotifyAckCh
		}
		logger.Infof("add task for sn: %v", toAdd)
	}

	logger.Info("replay dev list change is done")
	return nil
}

///////////////////////////////////////////////////////////////////////////////////////////

type IReplayControlOp interface {
	Control(res *client.ReplayDevicePauseOpResponse)
}

func GetReplayControlHandler(op int32) IReplayControlOp {
	var ret IReplayControlOp = nil

	switch op {
	case int32(client.EnumReplayPauseOp_PauseOP):
		ret = HandlerReplayPause

	case int32(client.EnumReplayPauseOp_ResetPause):
		ret = HandlerReplayContinue

	default:
		logger.Infof("not support control cmd: %v", op)
	}
	return ret
}

type ReplayPauseLogic struct{}

func (r *ReplayPauseLogic) Control(res *client.ReplayDevicePauseOpResponse) {
	logger.Infof("request pause replay process begin")
	res.Status = ReplayTaskSuccess

	if TasksMng.IsPause() || TasksMng.IsStop() {
		logger.Infof("is paused, now repeated do pause.")
		return
	}

	setWaitTm := fmt.Sprintf("%vh", TasksMng.PauseTimerHour)
	logger.Infof("task wait time: %v to continue, now is paused", setWaitTm)

	//暂停时不修改上下文中的rate 值。
	TasksMng.ModifyWorkTimer(setWaitTm)

	TasksMng.SetPause()
	logger.Infof("request pause replay process ok")
}

type ReplayContinueLogic struct{}

func (r *ReplayContinueLogic) Control(res *client.ReplayDevicePauseOpResponse) {
	logger.Infof("request continue replay process begin")
	res.Status = ReplayTaskSuccess

	if !TasksMng.IsPause() {
		logger.Infof("current is not pause, now continue op omit")
		res.Status = ReplayTaskFail
		return
	}

	rate := TasksMng.ReplayCtx.GetRate() //在控制速率时需要更新。
	strBaseRate := TasksMng.TransformRate(rate)
	logger.Infof("continue work, task work period: %v", strBaseRate)
	TasksMng.ModifyWorkTimer(strBaseRate)

	TasksMng.SetRunning()
	logger.Infof("request continue replay process ok")
}
