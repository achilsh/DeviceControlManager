package handler

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"
	"sync"
	"time"
)

// consumeReplayRFHeartInfo 通过屏幕来和c2连接。
func consumeReplayRFHeartInfo() {
	heartEntities := make([]bean.GunReplayHeartData, 0, batchSize)
	mu := sync.Mutex{}

	_, _ = mq.GunDroneIdBroker.Subscribe(mq.GunDroneIdTopic, func(event broker.Event) error {
		entity := client.ClientReport{}
		if err := proto.Unmarshal(event.Message().Body, &entity); err != nil {
			logger.Errorf("consume gun Unmarshal error: %v", err)
			return err
		}

		if entity.MsgType != common.ClientMsgIDAEAGHeartBeat {
			//TODO: 我看下线也会发，所以是佛记录下线数据。
			return nil
		}

		dataInfo := client.ScreenHeartBeatInfo{}
		if err := proto.Unmarshal(entity.Data, &dataInfo); err != nil {
			logger.Errorf("parse gun heart info fail, e: %v", err)
			return err
		}
		if dataInfo.GetData() == nil || dataInfo.GetHeader() == nil {
			logger.Infof("parse data info is nil for gun heart")
			return nil
		}
		//TODO: to need check dataInfo.GetData().GetIsOnLine() == common.DevOffline
		sn := dataInfo.GetHeader().GetSn()

		mu.Lock()
		defer mu.Unlock()

		heartEntities = append(heartEntities, bean.GunReplayHeartData{
			Sn:             sn,
			ScreenStatus:   dataInfo.GetData().GetScreenStatus(),
			Electricity:    dataInfo.GetData().GetElectricity(),
			SignalStrength: dataInfo.GetData().GetSignalStrength(),
			WorkStatus:     dataInfo.GetData().GetWorkStatus(),
			AlarmLevel:     dataInfo.GetData().GetAlarmLevel(),
			HitFreq:        dataInfo.GetData().GetHitFreq(),
			DetectFreq:     dataInfo.GetData().GetDetectFreq(),
			X:              dataInfo.GetData().GetX(),
			Y:              dataInfo.GetData().GetY(),
			Z:              dataInfo.GetData().GetZ(),
			GunLongitude:   dataInfo.GetData().GetGunLongitude(),
			GunLatitude:    dataInfo.GetData().GetGunLatitude(),
			GunAltitude:    dataInfo.GetData().GetGunAltitude(),
			SatellitesNum:  dataInfo.GetData().GetSatellitesNum(),
			GunDirection:   dataInfo.GetData().GetGunDirection(),
			ReHitTime:      dataInfo.GetData().GetReHitTime(),
			HitTime:        dataInfo.GetData().GetHitTime(),
			UDroneNum:      dataInfo.GetData().GetUDroneNum(),
			Elevation:      dataInfo.GetData().GetElevation(),
			IsOnline:       dataInfo.GetData().GetIsOnline(),
			CreateTime:     time.Now().UnixMilli(),
		})
		createBusiHeartTable[bean.GunReplayHeartData](db.GetDB(), sn, int32(common.DEV_SCREEN))
		if err := db.GetDB().Table(bean.GunReplayHeartData{}.GetTableName(sn)).Create(&heartEntities).Error; err != nil {
			logger.Errorf("consume gun heart data, write to db fail, e: %v", err)
		}

		heartEntities = helper.ClearSlice[bean.GunReplayHeartData](heartEntities)
		return nil
	})

}
