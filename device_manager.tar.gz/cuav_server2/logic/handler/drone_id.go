package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
	"google.golang.org/protobuf/proto"

	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"math/big"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
)

const (
	DroneIDTcpPort        = 12000
	DroneIDServerMaxCount = 500

	DroneHeightPrecision        = 10
	DroneYawAnglePrecision      = 100
	DroneSpeedPrecision         = 100
	DroneVerticalSpeedPrecision = 100
	DroneHorizonPrecision       = 100
	DronePitchPrecision         = 100
	DroneDirection              = 100
	FreqPrecision               = 1000
)

var (
	DroneIDTcpServerLock sync.Mutex
	DroneIDTcpServerMap  sync.Map //= make(map[string]*server.TcpServer, 0)
)
var (
	droneIDTypeMap  sync.Map
	droneIDTypeLock sync.Mutex
)

type DroneID struct {
	*Device
	dt common.DeviceType
}

func NewDroneID(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager) DeviceInterface {
	return &DroneID{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
		},
	}
}

func (d *DroneID) Deal() {
	if d.MsgLen <= 0 {
		logger.Errorf("message len: 0 remoteIP: %v", d.Device.RemoteIp)
		return
	}

	d.MsgId = int(d.Msg[mavlink.MsgIdLoc])
	switch d.MsgId {
	case mavlink.DroneIDGetVersionInfo:
		d.ReceiveGetVersionInfo()
	case mavlink.TracerGetDevTypeInfo:
		d.ReceiveGetDevTypeInfo()
	case mavlink.DRONEIDMsgGetChannel:
		d.ReceiveGetChannelReq()
	case mavlink.DRONEIDMsgHeartbeat:
		d.Heart()
	case mavlink.TracerIdGetVersionInfo:
		d.ReceiveTracerGetVersionInfo()
	case mavlink.TracerIdRequestUpgrade:
		d.ReceiveTracerRequestUpgrade()
	case mavlink.TracerIdSendUpdatePkg:
		d.ReceiveTracerSendUpdatePkg()
	case mavlink.TracerIdVerifyImage:
		d.ReceiveTracerVerifyImage()
	case mavlink.TracerIdGetTimeoutRetryTime:
		// 获取运行超时重试时间
		d.ReceiveTracerGetUpdateTimeoutRetryTime()
	case mavlink.TracerIdWriteUpdateData:
		d.ReceiveTracerWriteUpdateData()
	case mavlink.TracerIdGetUpdateWriteStatus:
		d.ReceiveTracerGetUpdateWriteStatus()
	case mavlink.TracerIdRunApp:
		d.ReceiveTracerRunApp()
	case mavlink.TracerIdGetLogList:
		d.ReceiveGetLogList()
	case mavlink.TracerIdGetLog:
		d.ReceiveGetLog()
	case mavlink.TracerIdDeleteLog:
		d.ReceiveDelLog()
	case mavlink.TracerIdGetTime:
		d.ReceiveGetTime()
	case mavlink.TracerGetWorkMode:
		d.ReceiveSendGetWorkMode()
	case mavlink.TracerSetOrientationMode:
		d.ReceiveSendSetOrientationMode()
		// detect logic
	case mavlink.TracerIdGetDetectRes:
		d.ReceiveDetectRes()
	case mavlink.TracerIdGetRemoteIdDetectRes:
		d.ReceiveRemoteIdDetectRes()
	case mavlink.TracerIdGetFreqDetectRes:
		d.ReceiveFreqDetectRes()
	case mavlink.TracerIdGetNewFreqDetectRes:
		d.ReceiveNewFreqDetectRes()
	case mavlink.TracerIdGetFreqDataRes:
		d.ReceiveFreqDataRes()
	case mavlink.TracerIdGetFreqDetectResExp:
		d.ReceiveFreqDetectExp()
	case mavlink.TracerCliSend:
		d.ReceiveTracerCli()
	case mavlink.TracerSetWhiteList:
		d.ReceiveTracerSetWhite()
	case mavlink.TracerSetAlarmLevel:
		d.ReceiveTracerSetAlarm()
	case mavlink.TracerSetHideMode:
		d.ReceiveTracerSetHideMode()
	case mavlink.TracerIdUpgradeF1:
		d.ReceiveTracerUpdateF1()
	case mavlink.TracerIdUpgradeF2:
		d.ReceiveTracerUpdateF2()
	case mavlink.TracerIdUpgradeF3:
		d.ReceiveTracerUpdateF3()
	case mavlink.FpvPushVideoStreams:
		d.TransferVideoStream()
	case mavlink.TracerControlVideo:
		d.ProcVideoCmdResponse()

	default:
		logger.Error("unknown message id:", d.MsgId)
	}
}

func (d *DroneID) updateStatusOnLine(sn string, heartInfo *mavlink.DroneIDHeartbeat) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		return
	}

	dev := &Device{
		Sn:                sn,
		Status:            common.DevOnline,
		RemoteIp:          d.RemoteIp,
		RemotePort:        d.RemotePort,
		LocalIp:           d.LocalIp,
		ServerPort:        d.ServerPort,
		DevType:           common.DEV_V2DRONEID,
		FirstHeartTime:    time.Now(),
		LastHeartTime:     time.Now(),
		SourceId:          d.SourceId,
		IsEnable:          d.GetStatus(sn), //Notice...
		GetStatusInterval: time.Now(),
		SessionId:         GetGlobalSessionId(),
		WorkMode:          d.WorkMode,
	}
	DevStatusMapOnEvent.Store(cacheKey, dev)

	go func() {
		dataInfo := &client.DroneStatusInfo{
			Header: &client.EquipmentMessageBoxEntity{
				Name:      sn,
				Sn:        sn,
				EquipType: int32(common.DEV_V2DRONEID),
				MsgType:   mavlink.TracerEventOnLine,
			},
			Data: &client.DroneIDReport{
				Sn:       sn,
				IsOnline: common.DevOnline,
				EventId:  utils.GetEventId(dev.SessionId),
				//需要查询下表：因为tracer不携带经纬度信息。由c2获取
				//GunLatitude:  float64(heartInfo.Info.GunLatitude) / GunLatitudeTion,
				//GunLongitude: float64(heartInfo.Info.GunLongitude) / GunLongitudeTion,
			},
		}
		msg, err := proto.Marshal(dataInfo)
		if err != nil {
			logger.Error("marshal dataInfo err:", err)
			return
		}

		report := &client.ClientReport{
			MsgType: common.ClientMsgTracerStatusEventData,
			Data:    msg,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal report err:", err)
			return
		}

		_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
		logger.Infof("tracer heartbeat event has reported, devSn: %v,report:%v", sn, dataInfo.Data)
	}()
	return
}
func (d *DroneID) updateStatus(sn string) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		if dev.IsEnable == common.DeviceDisenable {
			return common.DeviceDisenable
		}
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WorkMode = d.WorkMode
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		if dev.IsEnable != common.DeviceDisenable && dev.IsEnable != common.DeviceEnable {
			dev.IsEnable = d.GetStatus(sn)
		}
		return dev.IsEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_V2DRONEID,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          d.GetStatus(sn), //Notice...
			GetStatusInterval: time.Now(),
			WorkMode:          d.WorkMode,
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		go func() {
			time.Sleep(time.Second * 2)
			//发送白名单给tracer设备
			go SendDevWhiteList()
			if d.Conn == nil {
				return
			}
			runVer, appVer, bootVer, HwVer, protoVer, err := d.TracerGetVersionInfo()
			logger.Infof("Tracer get  Ver: %v, %v, %v, %v, %v \n",
				runVer, appVer, bootVer, HwVer, protoVer)
			if err != nil {
				logger.Infof("Tracer get  Ver runVer: %v err: %v \n", runVer, err)
			}
			if appVer != "" {
				err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         sn,
					DevVersion: appVer,
				}, &client.EquipCrudRes{})
				if err != nil {
					logger.Error("Update EquipList err: ", err)
				}
			}
		}()
		return dev.IsEnable
	}
}

func (d *DroneID) Heart() {
	heart := &mavlink.DroneIDHeartbeat{}
	if err := d.UnmarshalPayload(heart); err != nil {
		//使用旧协议
		d.WorkMode = int32(heart.Info.WorkMode)

		heartOld := &mavlink.DroneIDHeartbeatOld{}
		if err := d.UnmarshalPayloadOld(heartOld); err != nil {
			logger.Errorf(err.Error())
			return
		}
		devSn := ByteToString(heartOld.Info.SN[:])
		if devSn != "" {
			// update device status
			if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
				logger.Infof("device %v disable", devSn)
				return
			}
			// report heartbeat
			d.HeartReportOld(devSn, heartOld)
		}
		return
	}
	d.WorkMode = int32(heart.Info.WorkMode)

	devSn := ByteToString(heart.Info.SN[:])
	if devSn != "" {
		d.updateStatusOnLine(devSn, heart)
		// update device status
		if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
			logger.Infof("device %v disable", devSn)
			return
		}
		// report heartbeat
		d.HeartReport(devSn, heart)
	}
}

func (d *DroneID) HeartReport(devSn string, heartInfo *mavlink.DroneIDHeartbeat) {
	var report mavlink.DroneIDReport
	report.IsOnline = common.DevOnline
	report.Electricity = heartInfo.Info.Electricity
	report.TimeStamp = heartInfo.Info.TimeStamp
	report.Sn = devSn
	report.BatteryStatus = heartInfo.Info.BatteryStatus
	report.WorkMode = heartInfo.Info.WorkMode
	report.WorkStatus = heartInfo.Info.WorkStatus
	report.Fault = heartInfo.Info.Fault
	report.AlarmLevel = heartInfo.Info.AlarmLevel
	report.BuzzerOn = heartInfo.Info.Buzzer
	report.VibrationOn = heartInfo.Info.Vibration
	report.StealthModeOn = heartInfo.Info.StealthMode

	msg := common.EquipmentMessageBoxEntity{
		Name:      devSn,
		Sn:        devSn,
		MsgType:   mavlink.DRONEIDMsgHeartbeat,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	_ = mq.V2DroneIdBroker.Publish(mq.V2DroneIdTopic, broker.NewMessage(msg))
	logger.Infof("heartbeat has reported:", report)
}
func (d *DroneID) HeartReportOld(devSn string, heartInfo *mavlink.DroneIDHeartbeatOld) {
	var report mavlink.DroneIDReport
	report.IsOnline = common.DevOnline
	report.Electricity = heartInfo.Info.Electricity
	report.TimeStamp = heartInfo.Info.TimeStamp
	report.Sn = devSn
	report.BatteryStatus = heartInfo.Info.BatteryStatus
	report.WorkMode = heartInfo.Info.WorkMode
	report.WorkStatus = heartInfo.Info.WorkStatus
	report.AlarmLevel = heartInfo.Info.AlarmLevel

	msg := common.EquipmentMessageBoxEntity{
		Name:      devSn,
		Sn:        devSn,
		MsgType:   mavlink.DRONEIDMsgHeartbeat,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	_ = mq.V2DroneIdBroker.Publish(mq.V2DroneIdTopic, broker.NewMessage(msg))
	logger.Infof("heartbeat has reported, devSn: %v, Drone size: %v", devSn)
}

func (d *DroneID) UnmarshalPayload(data *mavlink.DroneIDHeartbeat) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	return nil
}
func (d *DroneID) UnmarshalPayloadOld(data *mavlink.DroneIDHeartbeatOld) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)

	}

	return nil
}

func V2DroneIDOfflineReport(sn string, port int) {
	var tcpServer *server.TcpServer
	if s, ok := DroneIDTcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)

		if tcpServer != nil {
			tcpServer.Stop()
		}
		deviceUsedPorts.Delete(tcpServer.Port)
		DroneIDTcpServerMap.Delete(sn)
		DevSnMap.Delete(tcpServer.Port)
		cachekeyDroneid := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
		DevStatusMap.Delete(cachekeyDroneid)
		tcpServer = nil
	}
	msg := common.EquipmentMessageBoxEntity{
		Name: sn,
		Sn:   sn,
		Info: &mavlink.DroneIDReport{
			TimeStamp:     uint32(time.Now().Unix()),
			Electricity:   0,
			Sn:            sn,
			IsOnline:      common.DevOffline,
			BatteryStatus: 0,
			WorkMode:      0,
			WorkStatus:    0,
			AlarmLevel:    0,
		},
		MsgType:   mavlink.DRONEIDMsgHeartbeat,
		EquipType: int(common.DEV_V2DRONEID),
	}
	IsSerialMap = false
	_ = mq.V2DroneIdBroker.Publish(mq.V2DroneIdTopic, broker.NewMessage(msg))
	logger.Info("send tracer offline:", msg)
}

func (d *DroneID) GetStatus(sn string) int32 {
	statusRes := &client.GetStatusRes{}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: "DroneID"}, statusRes)

	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}

	return statusRes.IsEnable
}

func (d *DroneID) UnMarshalGetChannelReq() string {
	devSn := ""
	switch d.MsgId {
	case mavlink.DRONEIDMsgGetChannel:
		req := &mavlink.DroneIDGetChannelRequest{}
		d.GetPacket(req)
		devSn = ByteToString(req.Sn[:])
		break
	case mavlink.RadarUdpBroadcastResponse:
		req := &mavlink.UdpBroadcastConfirmRequest{}
		d.GetPacket(req)
		devSn = strings.TrimRight(string(req.Sn[:]), string(rune(0)))
		break
	default:
		break
	}
	return devSn
}

func (d *DroneID) TcpServerCheck(devSn string, localIP []string) *server.TcpServer {
	var tcpServer *server.TcpServer
	if s, ok := DroneIDTcpServerMap.Load(devSn); ok {
		tcpServer = s.(*server.TcpServer)
		isAlike := false
		for _, ip := range localIP {
			if ip == tcpServer.Ip {
				isAlike = true
			}
		}
		if isAlike == false { //查找的本地IP没有与之前相同的
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			DroneIDTcpServerMap.Delete(devSn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}
	}

	//注册tcp服务
	if tcpServer == nil {
		port, err := ip.GetFreeTcpPort()
		if err != nil {
			logger.Error("droneid tcp 获取可用端口失败：", err)
			port = d.getRandPort(DroneIDTcpPort, DroneIDTcpPort+DroneIDServerMaxCount)
		}
		tcpServer = server.NewTcpServer(port, Handle)
		DroneIDTcpServerMap.Store(devSn, tcpServer)
		tcpServer.ServerType = uint8(common.DEV_V2DRONEID)
		tcpServer.ServerName = devSn
		localAddr, _ := ip.GetLocalIp(d.UdpIp)
		tcpServer.Ip = localAddr
		go tcpServer.Start()
	}
	return tcpServer
}

func (d *DroneID) ReceiveGetChannelReq() {
	DroneIDTcpServerLock.Lock()
	defer DroneIDTcpServerLock.Unlock()

	devSn := d.UnMarshalGetChannelReq()
	if devSn == "" {
		logger.Info("device sn empty")
		return
	}

	if isContinue := d.deviceDiscover(devSn); !isContinue {
		logger.Error("droneID等待设备确认：", devSn)
		return
	}

	if status := d.GetStatus(devSn); status == common.DeviceDisenable {
		logger.Infof("device %v disable", devSn)
		return
	}

	localIP := make([]string, 0)

	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[tracer] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(devSn, localIP)
	DevSnMap.Store(tcpServer.Port, devSn)
	d.ServerPort = tcpServer.Port
	//DroneIDSnMaps.Store(tcpServer.Port, devSn)

	//响应
	switch d.MsgId {
	case mavlink.DRONEIDMsgGetChannel:
		addr := d.LocalIp
		tcpServer.Ip = addr
		tcpServer.LastHeartTime = time.Now()
		res := &mavlink.DroneIDGetChannelResponse{}
		resBuff := res.CreateGetChannelResponse(addr, uint16(tcpServer.Port))
		n, err := d.Conn.Write(resBuff)
		logger.Info("droneID响应获取信道：", addr, n, err)
		break
	case mavlink.RadarUdpBroadcastResponse:
		logger.Info("[DroneID] receive Broadcast BB Msg")
		UdpBroadcastSendChannel(devSn, d.UdpIp, d.SourceId, tcpServer)
		break
	default:
		break
	}

	return
}

func (d *DroneID) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	logger.Infof("GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		logger.Error("GetPacket write buff err:", err)
		return nil

	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("GetPacket read header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Error("GetPacket read msg err:", err)
		return nil
	}
	return req
}

func (d *DroneID) getPort() int {
	screenPortMutex.Lock()
	defer screenPortMutex.Unlock()
	startPort := int(ScreenTcpPort)
	usedPort, ok := deviceUsedPorts.Load(startPort)
	for ok && usedPort.(int) > 0 {
		startPort++
		usedPort, ok = deviceUsedPorts.Load(startPort)
	}
	deviceUsedPorts.Store(startPort, startPort)
	return startPort
}

func (d *DroneID) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok && (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}

func (d *DroneID) deviceDiscover(sn string) bool {
	return true
}

func (d *DroneID) SendGetVersionInfo() (*client.DroneIDGetVersionInfoResponse, error) {
	req := &mavlink.DroneIDGetVersionInfoRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request droneID version info err: %v", err)
		return nil, fmt.Errorf("request droneID version info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.DroneIDGetVersionInfo]
	if !ok {
		manager = NewWaitTaskManager(mavlink.DroneIDGetVersionInfo, true, 0)
		d.WaitTaskMap[mavlink.DroneIDGetVersionInfo] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request droneID version info err: %v", checkNetConnErr)
			return nil, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.DroneIDGetVersionInfoResponse)
	if !ok {
		return nil, errors.New("response err type")
	}

	r := &client.DroneIDGetVersionInfoResponse{}
	r.Company = ByteToString(res.CompanyName[:])
	r.Sn = ByteToString(res.DeviceSn[:])
	r.PsVersion = ByteToString(res.PsVersion[:])
	r.PlVersion = ByteToString(res.PlVersion[:])
	r.Ip = ByteToString(res.DeviceIP[:])
	logger.Debug("response droneID version result:%+v", *r)
	return r, nil
}

func (d *DroneID) ReceiveGetVersionInfo() {
	res := &mavlink.DroneIDGetVersionInfoResponse{}
	d.GetPacket(res)
	logger.Debug("receive droneID version info:%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.DroneIDGetVersionInfo]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *DroneID) SendGetDevTypeInfo() (int32, error) {
	req := &mavlink.TracerGetDevTypeInfoRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request droneID version info err: %v", err)
		return 0, fmt.Errorf("request droneID version info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.TracerGetDevTypeInfo]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerGetDevTypeInfo, true, time.Second*3)
		d.WaitTaskMap[mavlink.TracerGetDevTypeInfo] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request droneID version info err: %v", checkNetConnErr)
			return 0, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.TracerGetDevTypeInfoResponse)
	if !ok {
		return 0, errors.New("response err type")
	}

	logger.Debug("response droneID version result:%+v", *res)
	return int32(res.DevType), nil
}

func (d *DroneID) ReceiveGetDevTypeInfo() {
	res := &mavlink.TracerGetDevTypeInfoResponse{}
	d.GetPacket(res)
	logger.Debug("receive droneID DevType info:%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.TracerGetDevTypeInfo]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func SendDroneIDHeart() {
	ticker := time.NewTicker(time.Second * 1)
	defer ticker.Stop()
	for range ticker.C {
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if dev.DevType == common.DEV_V2DRONEID && dev.Status == common.DevOnline {
				reqMode := &DroneID{
					Device: dev,
					dt:     common.DEV_V2DRONEID,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}

func (d *DroneID) SendExtHeartbeat() error {
	GunHeartSum++
	if GunHeartSum > 255 {
		GunHeartSum = 0
	}
	req := &mavlink.DroneIDHeartbeatExtRequest{
		GunHeartSum,
	}
	reqBuff := req.CreateScreenHeartbeatExt()
	if d != nil && d.Conn != nil {
		n, err := d.Conn.Write(reqBuff)
		logger.Info("c2发送droneID心跳结果：", GunHeartSum, n, err, reqBuff)
		if err != nil {
			msg := common.EquipmentMessageBoxEntity{
				Name: d.Sn,
				Sn:   d.Sn,
				Info: &mavlink.DroneIDReport{
					TimeStamp: uint32(time.Now().Unix()),
					Sn:        d.Sn,
					IsOnline:  common.DevOffline,
				},
				MsgType:   mavlink.DRONEIDMsgHeartbeat,
				EquipType: int(common.DEV_V2DRONEID),
			}
			IsSerialMap = false
			_ = mq.V2DroneIdBroker.Publish(mq.V2DroneIdTopic, broker.NewMessage(msg))
			logger.Info("send tracer offline:", msg)
		}
		return err
	}
	return nil
}

func ByteToString(data []byte) string {
	nullIndex := bytes.IndexByte(data, 0)
	if nullIndex >= 0 {
		data = data[:nullIndex]
	}
	return string(data)
}

func (d *DroneID) TracerGetVersionInfo() (uint32, string, string, string, string, error) {
	logger.Info("TracerGetVersionInfo Start")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Tracer Get Version Info occurred:", r)
			return
		}
	}()
	req := &mavlink.TracerGetVersionRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetVersionInfo]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdGetVersionInfo, true, time.Second*3)
		d.WaitTaskMap[mavlink.TracerIdGetVersionInfo] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("TracerGetVersionInfo buff: %02X \n", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerGetVersionInfo 发送获取Tracer版本信息失败: ", err)
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 0, "", "", "", "", checkNetConnErr
		}
		return 0, "", "", "", "", err
	}
	res := result.(*mavlink.TracerGetVersionResponse)
	logger.Debugf("TracerGetVersionInfo 获取Tracer版本信息结果：%#v", res)
	logger.Info("TracerGetVersionInfo End")
	return res.RunVersion,
		d.TrimStringSpace(res.AppVersion[:]),
		d.TrimStringSpace(res.BootVersion[:]),
		d.TrimStringSpace(res.HwVersion[:]),
		d.TrimStringSpace(res.ProtocolVersion[:]),
		nil
}

func (d *DroneID) TrimStringSpace(strArr []byte) string {
	tmp := make([]byte, 0)
	for _, v := range strArr {
		if v == 0x00 {
			break
		}
		tmp = append(tmp, v)
	}
	return string(tmp)
}

func (d *DroneID) ReceiveTracerGetVersionInfo() {
	res := &mavlink.TracerGetVersionResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerGetVersionInfo 接收到Tracer版本信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetVersionInfo]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerResetSystem 系统复位
func (d *DroneID) TracerResetSystem(rq *client.ResetSystemRequest) (int32, error) {
	logger.Info("TracerResetSystem Start")
	req := &mavlink.TracerResetSystemRequest{
		ResetCode: mavlink.TracerOtaReSetCode,
		Type:      uint16(4),
	}
	buff := req.Create()

	logger.Debugf("TracerResetSystem buff: %02X \n", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerResetSystem 发送反制抢系统复位信息失败: ", err)
		return 1, err
	}
	logger.Infof("TracerResetSystem End")
	return 0, nil
}

// TracerRequestUpgrade 请求固件升级
func (d *DroneID) TracerRequestUpgrade(data [256]byte, tryCount int) (int32, error) {
	logger.Info("TracerRequestUpgrade Start")
	var req = &mavlink.TracerRequestUpgradeRequest{
		Data: data,
	}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdRequestUpgrade]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdRequestUpgrade, true, 0)
		d.WaitTaskMap[mavlink.TracerIdRequestUpgrade] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("TracerRequestUpgrade buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerRequestUpgrade 请求固件升级: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerRequestUpgrade WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.TracerRequestUpgradeResponse)
	logger.Debugf("TracerRequestUpgrade 请求固件升级：%#v", res)
	logger.Info("TracerRequestUpgrade End")
	// 嵌入是boot有个bug第一次请求A7会返回1;睡眠2两秒再重试
	if res.Status != 0 {
		if tryCount > 0 {
			tryCount--
			time.Sleep(2 * time.Second)
			return d.TracerRequestUpgrade(data, tryCount)
		}
	}
	return int32(res.Status), nil
}

// ReceiveTracerRequestUpgrade 获取请求固件升级响应
func (d *DroneID) ReceiveTracerRequestUpgrade() {
	res := &mavlink.TracerRequestUpgradeResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerRequestUpgrade 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdRequestUpgrade]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerSendUpdatePkg 发送升级固件数据
func (d *DroneID) TracerSendUpdatePkg(offset uint32, imageData []uint8) (*mavlink.TracerSendUpdatePkgResponse, error) {
	logger.Info("TracerSendUpdatePkg Start offset:", offset)
	req := &mavlink.TracerSendUpdatePkgRequest{
		ImageOffset: offset,
		ImageLength: uint32(len(imageData)),
		ImageData:   imageData,
	}
	buff, err := req.Create()
	if err != nil {
		return nil, err
	}

	// 超时重发
	result, err := d.TimeOutRepeatSendBuff(buff, 3, 5*time.Second, mavlink.TracerIdSendUpdatePkg)
	if err != nil {
		logger.Errorf("TracerSendUpdatePkg 获取发送升级固件数据信息结果报错：%#v", err)
		logger.Errorf("TracerSendUpdatePkg Err buff: %v", buff)
		logger.Errorf("TracerSendUpdatePkg WaitTask Err %s", err.Error())
		return nil, err
	}
	res := result.(*mavlink.TracerSendUpdatePkgResponse)
	logger.Debugf("TracerSendUpdatePkg 获取发送升级固件数据信息结果：%#v", result)
	return res, nil
}

// ReceiveTracerSendUpdatePkg 获取发送升级固件数据响应
func (d *DroneID) ReceiveTracerSendUpdatePkg() {
	res := &mavlink.TracerSendUpdatePkgResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerSendUpdatePkg 获取发送升级固件数据响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdSendUpdatePkg]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TimeOutRepeatSendBuff 超时重发字节数据
func (d *DroneID) TimeOutRepeatSendBuff(buff []byte, tryCount int, timeOut time.Duration, messageId int) (interface{}, error) {
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[messageId]
	if !ok {
		manager = NewWaitTaskManager(messageId, true, timeOut)
		d.WaitTaskMap[messageId] = manager
	}
	task := manager.AddTask(nil, nil)
	if d.Conn == nil {
		manager.DeleteTask(task.TaskId)
		fmt.Println("TimeOutRepeatSendBuff device conn is nil")
		return nil, errors.New("device conn is nil")
	}
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TimeOutRepeatSendBuff 发送信息失败: ", err)
		fmt.Printf("TimeOutRepeatSendBuff 发送信息失败:  %v \n", err)
		manager.DeleteTask(task.TaskId)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		// 超时重试
		if tryCount > 0 {
			tryCount--
			fmt.Println("TimeOutRepeatSendBuff tryCount: ", tryCount)
			return d.TimeOutRepeatSendBuff(buff, tryCount, timeOut, messageId)
		}
	}
	return result, err
}

// TracerVerifyImage 校验固件镜像
func (d *DroneID) TracerVerifyImage() (int32, error) {
	logger.Info("TracerVerifyImage Start")
	req := &mavlink.TracerVerifyImageRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdVerifyImage]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdVerifyImage, true, 0)
		d.WaitTaskMap[mavlink.TracerIdVerifyImage] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("TracerVerifyImage buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerVerifyImage 发送校验固件镜像信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerVerifyImage WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.TracerVerifyImageResponse)
	logger.Debugf("TracerVerifyImage 获取校验固件镜像信息结果：%#v", res)
	logger.Info("TracerVerifyImage End")
	return int32(res.Status), nil
}

// ReceiveTracerVerifyImage 获取校验固件镜像响应
func (d *DroneID) ReceiveTracerVerifyImage() {
	res := &mavlink.TracerVerifyImageResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerVerifyImage 获取校验固件镜像响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdVerifyImage]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerGetUpdateTimeoutRetryTime 获取固件升级超时重试时间
func (d *DroneID) TracerGetUpdateTimeoutRetryTime() (*mavlink.TracerGetUpdateTimeoutRetryTimeResponse, error) {
	req := &mavlink.TracerGetUpdateTimeoutRetryTimeRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetTimeoutRetryTime]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdGetTimeoutRetryTime, true, 20*time.Second)
		d.WaitTaskMap[mavlink.TracerIdGetTimeoutRetryTime] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("发送获取固件升级超时重试时间信息失败: ", err)
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	res := result.(*mavlink.TracerGetUpdateTimeoutRetryTimeResponse)
	logger.Debugf("获取固件升级超时重试时间信息结果：%#v", res)

	return res, nil
}

// ReceiveTracerGetUpdateTimeoutRetryTime 获取固件升级超时重试时间响应
func (d *DroneID) ReceiveTracerGetUpdateTimeoutRetryTime() {
	res := &mavlink.TracerGetUpdateTimeoutRetryTimeResponse{}
	d.GetPacket(res)
	logger.Debugf("获取固件升级超时重试时间回复信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetTimeoutRetryTime]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerSendUpgradeF1
func (d *DroneID) TracerSendUpgradeF1(fileName string, c2Ip string) (int32, error) {
	logger.Info("TracerSendUpgradeF1 Start")

	req := &mavlink.TracerUpdateF1Request{}
	buff := req.Create(fileName, c2Ip)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdUpgradeF1]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdUpgradeF1, true, 0)
		d.WaitTaskMap[mavlink.TracerIdUpgradeF1] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("TracerSendUpgradeF1 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerSendUpgradeF1 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerSendUpgradeF1 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.TracerUpdateF1Response)
	logger.Debugf("TracerUpdateF1Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("TracerUpdateF1Response End")
	return int32(res.Status), nil
}

// ReceiveTracerUpdateF1 获取请求固件升级响应
func (d *DroneID) ReceiveTracerUpdateF1() {
	res := &mavlink.TracerUpdateF1Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerUpdateF1 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdUpgradeF1]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerSendUpgradeF2
func (d *DroneID) TracerSendUpgradeF2() (int32, error) {
	logger.Info("TracerSendUpgradeF2 Start")
	req := &mavlink.TracerUpdateF2Request{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdUpgradeF2]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdUpgradeF2, true, time.Second*30)
		d.WaitTaskMap[mavlink.TracerIdUpgradeF2] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("TracerSendUpgradeF2 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerSendUpgradeF2 发送写入固件数据信息失败: ", err)
		return -1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerSendUpgradeF2 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return -1, checkNetConnErr
		}
		return -1, err
	}
	res := result.(*mavlink.TracerUpdateF2Response)
	logger.Debugf("TracerUpdateF2Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("TracerUpdateF2Response End")
	return int32(res.Progress), nil
}

// ReceiveTracerUpdateF2 获取请求固件升级响应
func (d *DroneID) ReceiveTracerUpdateF2() {
	res := &mavlink.TracerUpdateF2Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerUpdateF2 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdUpgradeF2]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerSendUpgradeF3
func (d *DroneID) TracerSendUpgradeF3() (int32, error) {
	logger.Info("TracerSendUpgradeF3 Start")

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdUpgradeF3]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdUpgradeF3, true, time.Second*30)
		d.WaitTaskMap[mavlink.TracerIdUpgradeF3] = manager
	}
	task := manager.AddTask(nil, nil)

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerSendUpgradeF3 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.TracerUpdateF3Response)
	logger.Debugf("TracerUpdateF3Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("TracerUpdateF3Response End")
	return int32(res.UpgradeResult), nil
}

// ReceiveTracerUpdateF3 获取请求固件升级响应
func (d *DroneID) ReceiveTracerUpdateF3() {
	res := &mavlink.TracerUpdateF3Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerUpdateF3 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdUpgradeF3]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerWriteUpdateData 写入固件数据
func (d *DroneID) TracerWriteUpdateData() (int32, error) {
	logger.Info("TracerWriteUpdateData Start")
	req := &mavlink.TracerWriteUpdateDataRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdWriteUpdateData]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdWriteUpdateData, true, 0)
		d.WaitTaskMap[mavlink.TracerIdWriteUpdateData] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("TracerWriteUpdateData buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerWriteUpdateData 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerWriteUpdateData WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.TracerWriteUpdateDataResponse)
	logger.Debugf("TracerWriteUpdateData 获取写入固件数据信息结果：%#v", res)
	logger.Info("TracerWriteUpdateData End")
	return int32(res.Status), nil
}

// ReceiveTracerWriteUpdateData 获取写入固件数据响应
func (d *DroneID) ReceiveTracerWriteUpdateData() {
	res := &mavlink.TracerWriteUpdateDataResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerWriteUpdateData 获取写入固件数据响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdWriteUpdateData]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerGetUpdateWriteStatus 获取固件写入状态
func (d *DroneID) TracerGetUpdateWriteStatus() (*mavlink.TracerGetUpdateWriteStatusResponse, error) {
	logger.Info("TracerGetUpdateWriteStatus Start")
	req := &mavlink.TracerGetUpdateWriteStatusRequest{}
	buff := req.Create()
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetUpdateWriteStatus]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdGetUpdateWriteStatus, true, 0)
		d.WaitTaskMap[mavlink.TracerIdGetUpdateWriteStatus] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerGetUpdateWriteStatus 发送获取固件写入状态信息失败: ", err)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerGetUpdateWriteStatus WaitTask Err: %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	res := result.(*mavlink.TracerGetUpdateWriteStatusResponse)
	logger.Debugf("TracerGetUpdateWriteStatus 获取固件写入状态信息结果：%#v", res)
	logger.Info("TracerGetUpdateWriteStatus End")
	return res, nil
}

// ReceiveTracerGetUpdateWriteStatus 获取固件写入状态回复结果
func (d *DroneID) ReceiveTracerGetUpdateWriteStatus() {
	res := &mavlink.TracerGetUpdateWriteStatusResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerGetUpdateWriteStatus 获取固件写入状态回复信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetUpdateWriteStatus]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerRunApp 运行固件App
func (d *DroneID) TracerRunApp() (int32, error) {
	logger.Info("TracerRunApp Start")
	req := &mavlink.TracerRunAppRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdRunApp]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdRunApp, true, 0)
		d.WaitTaskMap[mavlink.TracerIdRunApp] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("TracerRunApp buff: %02X \n", buff)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerRunApp 发送运行固件App信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerRunApp WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.TracerRunAppResponse)
	logger.Debugf("TracerRunApp 获取运行固件App信息结果：%#v", res)
	logger.Info("TracerRunApp End")
	return int32(res.Status), nil
}

// ReceiveTracerRunApp 获取运行固件App响应
func (d *DroneID) ReceiveTracerRunApp() {
	res := &mavlink.TracerRunAppResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerRunApp 获取运行固件App响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdRunApp]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *DroneID) Send(sn string, reqBuff []byte) error {
	radarSendLock.Lock()
	defer radarSendLock.Unlock()
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	cache, ok := DevStatusMap.Load(cacheKey)
	if !ok {
		return errors.New("设备未连接")
	}
	dev := cache.(*Device)
	//检查状态
	if dev.Status != common.DevOnline {
		errors.New("设备离线")
	}
	if _, err := dev.Conn.Write(reqBuff); err != nil {
		return err
	}
	return nil
}

// SendGetWorkMode 发送请求DroneId工作模式
func (d *DroneID) SendGetWorkMode() (int32, error) {
	logger.Info("---> Send Get Work Mode")
	req := &mavlink.TracerGetWorkModeRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerGetWorkMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerGetWorkMode, true, 0)
		d.WaitTaskMap[mavlink.TracerGetWorkMode] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Send Get Work Mode err: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Get Work Mode err %s", err.Error())
		return 1, err
	}
	res := result.(*mavlink.TracerGetWorkModeResponse)

	logger.Info("-->End Send Get Work Mode")
	return int32(res.Status), nil
}

func (d *DroneID) ReceiveSendGetWorkMode() {
	res := &mavlink.TracerGetWorkModeResponse{}
	d.GetPacket(res)
	logger.Debugf("receive Send Get Work Mode：%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.TracerGetWorkMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SendSetOrientationMode 发送请求DroneId工作模式
func (d *DroneID) SendSetOrientationMode(status uint8, uavNumber uint8, uamName string, uFreq uint32) (int32, error) {
	logger.Info("---> Send Set Orientation Mode")
	req := &mavlink.TracerSetOrientationModeRequest{}
	buff := req.Create(status, uavNumber, uamName, uFreq)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerSetOrientationMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerSetOrientationMode, true, 0)
		d.WaitTaskMap[mavlink.TracerSetOrientationMode] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer info is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Set Orientation Mode err:[%v].Buff is [%v]", err, buff)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Set Orientation Mode err %s", err.Error())
		return 1, err
	}
	res := result.(*mavlink.TracerSetOrientationModeResponse) // res.Status : 0 fail, 1: successful

	//如果是第一次记录，不会有记录项: Azimuth; 该值在定向过程中返回时被填充。
	TracerSOrientInstance().DoTracerSOrientLog(int32(res.Status), status,
		&TracerSOrientationSession{
			Sn:          d.Sn,
			DroneNumber: uint32(uavNumber),
			DroneName:   uamName,
			Freq:        uFreq,
			Status:      TracerSBeginOrienting,
		}, WriteDBForOrient)

	logger.Info("-->End Set Orientation Mode")
	return int32(res.Status), nil
}

func (d *DroneID) ReceiveSendSetOrientationMode() {
	res := &mavlink.TracerSetOrientationModeResponse{}
	d.GetPacket(res)
	logger.Debugf("receive Send Set Orientation Mode：%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.TracerSetOrientationMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SendTracerCli 发送请求DroneId  Cmd
func (d *DroneID) SendTracerCli(cmd string) ([]byte, error) {
	logger.Info("---> Send Tracer Cli")
	req := &mavlink.TracerCliRequest{
		Handle: 1,
		Cmd:    append([]byte(cmd), 0),
	}

	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerCliSend]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerCliSend, true, 0)
		d.WaitTaskMap[mavlink.TracerCliSend] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer Cli is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer Cli err:[%v].Buff is [%v]", err, buff)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer Cli err %s", err.Error())
		return nil, err
	}
	res := result.(*mavlink.TracerCliResponse)

	logger.Info("-->End Set Tracer Cli")
	return res.CmdResult, nil
}

func (d *DroneID) ReceiveTracerCli() {
	res := &mavlink.TracerCliResponse{}
	var cmdRes []byte
	var status uint32
	var result uint32
	cmdRes = make([]byte, len(d.Msg)-14-mavlink.HeaderLen)
	err := mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+4:]), binary.LittleEndian, &status, 4)
	if err != nil {
		logger.Error("msg Decode Tracer Cli status err:%v", err)
		return
	}
	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+8:]), binary.LittleEndian, &result, 4)
	if err != nil {
		logger.Error("msg Decode Tracer Cli result err:%v", err)
		return
	}

	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+12:]), binary.LittleEndian, &cmdRes, len(d.Msg)-14-mavlink.HeaderLen)
	if err != nil {
		logger.Error("msg Decode Tracer Cli  cmdRes err:%v", err)
		return
	}
	logger.Info("cmdRes is :", cmdRes)

	resultCode := strconv.Itoa(int(result))
	resCmd := string(cmdRes)
	str := ""
	if status == 0 {
		str = "ok"
		resCmd = str + " " + resultCode + " " + resCmd
	} else {
		str = "fail"
		resCmd = str + " " + resultCode + " " + resCmd
	}
	logger.Info("resCmd is :", resCmd)

	res.CmdResult = []byte(resCmd)
	manager, ok := d.WaitTaskMap[mavlink.TracerCliSend]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Debugf("Receive Tracer Cli res.CmdResult is ", res.CmdResult)
	return
}

// SendGetLogList -----------------------------日志列表-----------------------------------------------
// 发送请求DroneId日志列表指令
func (d *DroneID) SendGetLogList(sn string) (*mavlink.DroneIdGetLogListResponseAll, error) {
	logger.Info("-->Into Send Get LogList To DroneId")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("DroneID Get LogList occurred:", r)
			return
		}
	}()
	req := mavlink.DroneIdGetLogListRequest{}
	reqBuff := req.CreateDroneIdGetLogList()
	logger.Info("Send GetLogList Tracer msg is:", reqBuff)
	if err := d.Send(sn, reqBuff); err != nil {
		logger.Error("-->Send Get LogList To DroneId fail !,err is : ", err)
		return nil, err
	}
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetLogList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdGetLogList, true, time.Second*10)
		d.WaitTaskMap[mavlink.TracerIdGetLogList] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		logger.Error("-->Wait err:", err)
		return nil, err
	}
	logger.Info("-->Send Get LogList To DroneId End")
	return result.(*mavlink.DroneIdGetLogListResponseAll), nil
}

// ReceiveGetLogList 接收DroneId日志列表返回，组包
func (d *DroneID) ReceiveGetLogList() {
	logger.Info("-->into Revceive Get LogList DroneId")

	var PkgTotalNum uint32
	var PkgCurNum uint32
	var LogNameLen uint32
	var LogDataLen uint32
	var LogName []byte

	err := mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen:]), binary.LittleEndian, &PkgTotalNum, 4)
	logger.Debug("PkgTotalNum : ", PkgTotalNum)

	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+4:]), binary.LittleEndian, &PkgCurNum, 4)
	logger.Debug("PkgCurNum : ", PkgCurNum)

	if err != nil {
		logger.Error("msg Decode err:%v", err)
		return
	}
	msg := &mavlink.DroneIdGetLogListResponse{}
	index := mavlink.HeaderLen + 8

	for {
		//退出条件
		if len(d.Msg)-index < mavlink.CrcLen+1 {
			break
		}
		//解析LogNameLen
		err = mavlink.Read(bytes.NewReader(d.Msg[index:]), binary.LittleEndian, &LogNameLen, 4)
		if err != nil {
			logger.Error("msg Decode LogNameLen err:%v", err)
			return
		}
		//解析LogDataLen
		index = index + 4
		err = mavlink.Read(bytes.NewReader(d.Msg[index:]), binary.LittleEndian, &LogDataLen, 4)
		if err != nil {
			logger.Error("msg Decode LogDataLen err:%v", err)
			return
		}
		//解析LogName
		index = index + 4
		LogName = make([]byte, LogNameLen)
		err = mavlink.Read(bytes.NewReader(d.Msg[index:]), binary.LittleEndian, &LogName, int(LogNameLen))
		if err != nil {
			logger.Error("msg Decode LogName err:%v", err)
			return
		}

		logger.Debug("LogName : ", string(LogName))
		index = index + int(LogNameLen)

		if strings.Contains(string(LogName), ".txt") || strings.Contains(string(LogName), ".log") {
			msg.DroneIdLogInfo = append(msg.DroneIdLogInfo, mavlink.DroneIdLogInfo{
				LogNameLen: LogNameLen,
				LogDataLen: LogDataLen,
				LogName:    LogName,
			})
		}
	}

	var i interface{} = msg
	if PkgTotalNum != PkgTotalNum {
		logger.Info("-->Revceive ing DroneId")
		mavlink.DroneIdResAll.SetData(i.(*mavlink.DroneIdGetLogListResponse))
	} else {
		mavlink.DroneIdResAll.SetData(i.(*mavlink.DroneIdGetLogListResponse))
		logger.Info("DroneId Loglist res is %v", msg)
		manager, ok := d.WaitTaskMap[mavlink.TracerIdGetLogList]
		if ok {
			manager.CompletedTask(&mavlink.DroneIdResAll, nil)
		}
		logger.Info("-->Revceive Get LogList end DroneId")
	}
}

// SendGetLog -----------------------------请求日志-----------------------------------------------
// 发送请求DroneId日志指令
func (d *DroneID) SendGetLog(sn, filePath string, logInfo DeviceLogList) (*mavlink.DroneIdGetLogMsgResponse, error) {
	logger.Info("-->Into Send Get Log To DroneID")
	logger.Info("DroneID LogName : ", logInfo.LogName)
	defer func() {
		if r := recover(); r != nil {
			logger.Error("DroneId Get Log occurred:", r)
			return
		}
	}()
	var num uint32
	binary.Read(rand.Reader, binary.LittleEndian, &num)

	req := mavlink.DroneIdGetLogRequestAll{}
	logreq := make([]*mavlink.DroneIdGetLogRequest, 0)

	logfile := &mavlink.DroneIdLogFileInfo{
		LogId:      num,
		LogNameLen: uint32(len(logInfo.LogName)),
		LogName:    []byte(logInfo.LogName),
	}
	logreq = append(logreq, &mavlink.DroneIdGetLogRequest{
		LogNum:      1,
		LogFileInfo: [1]mavlink.DroneIdLogFileInfo{*logfile},
	})

	FileNameMap.Set(num, logInfo.LogName, filePath+"/droneID/"+sn+"/"+logInfo.LogName)

	reqBuff := req.CreateDroneIdGetLog(logreq)

	//创建文件夹
	dirpath := ""
	if strings.Contains(logInfo.LogName, "/") {
		index := strings.LastIndex(logInfo.LogName, "/")
		dirpath = filePath + "/droneID/" + sn + "/" + logInfo.LogName[:index]
	} else {
		dirpath = filePath + "/droneID/" + sn
	}
	err := helper.CreateDirIfNotExist(dirpath)
	if err != nil {
		logger.Error("Create directory error : ", err)
	} else {
		logger.Info("Directory created successfully.")
	}

	logger.Info("-->File Path is :", filePath+"/droneID/"+sn+"/"+logInfo.LogName)
	logger.Info("Send GetLog Tracer msg is:", reqBuff)
	if err = d.Send(sn, reqBuff); err != nil {
		logger.Error("-->Send Get Log To DroneID Fail,err : ", err)
		return nil, err
	}
	logger.Info("Send Get File To DroneID")

	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetLog]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdGetLog, true, time.Second*600)
		d.WaitTaskMap[mavlink.TracerIdGetLog] = manager
	}
	// TODO 处理包序
	result, err := manager.Wait()
	if err != nil {
		logger.Error("-->Wait Fail,err : ", err)
		return nil, err
	}
	logger.Info("-->Send Get DroneID Log End")
	return result.(*mavlink.DroneIdGetLogMsgResponse), nil
}

// ReceiveGetLog 接收DroneId日志文件返回
func (d *DroneID) ReceiveGetLog() {
	logger.Info("-->into Receive Get Log")

	var PkgTotalNum uint32
	var PkgCurNum uint32
	var LogId uint32

	err := mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen:mavlink.HeaderLen+4]), binary.LittleEndian, &LogId, 4)
	logger.Debug("LogId : ", LogId)

	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+4:mavlink.HeaderLen+8]), binary.LittleEndian, &PkgTotalNum, 4)
	logger.Debug("PkgTotalNum : ", PkgTotalNum)

	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+8:mavlink.HeaderLen+12]), binary.LittleEndian, &PkgCurNum, 4)
	logger.Debug("PkgCurNum : ", PkgCurNum)

	if err != nil {
		logger.Error("msg Decode err:%v", err)
		return
	}
	if PkgCurNum == 0 && PkgTotalNum == 0 { //空包不进行处理
		return
	}
	var msg string

	msg = string(d.Msg[mavlink.HeaderLen+16 : len(d.Msg)-mavlink.CrcLen])

	fileInfo, isExit := FileNameMap.Get(LogId)
	if isExit != true {
		logger.Error("File Name Map Get err")
	}

	if PkgCurNum == 0 {
		file, err := os.Create(fileInfo.FilePath)
		if err != nil {
			logger.Error(err)
		}
		defer file.Close()
		logger.Debug("文件已创建")
	}

	mavlink.DroneIdLogMsgAll.SetData(msg)
	if PkgCurNum+1 != PkgTotalNum {
		logger.Debug("-->Revceive log ing")
		if PkgCurNum%PackNum == 0 { //200个包写入一次  一个包16k  //测试  90s 传280M日志文件
			if PkgCurNum == PackNum {
				//新建文件写入
				err = os.WriteFile(fileInfo.FilePath, []byte(strings.Join(mavlink.DroneIdLogMsgAll.GetData(), "")), 0644)
				if err != nil {
					logger.Error("Log Store Fail,err:", err)
				}
			} else {
				//追加写入
				file, err := os.OpenFile(fileInfo.FilePath, os.O_APPEND|os.O_WRONLY, 0644)
				if err != nil {
					logger.Error(err)
				}
				file.WriteString(strings.Join(mavlink.DroneIdLogMsgAll.GetData(), ""))
				defer file.Close()
			}
			mavlink.DroneIdLogMsgAll.DeleteData()
		}
	} else {
		if PkgTotalNum == 1 {
			//新建文件写入
			err = os.WriteFile(fileInfo.FilePath, []byte(strings.Join(mavlink.DroneIdLogMsgAll.GetData(), "")), 0644)
			if err != nil {
				logger.Error("Log Store Fail,err:", err)
			}
			manager, ok := d.WaitTaskMap[mavlink.TracerIdGetLog]
			if ok {
				manager.CompletedTask(&mavlink.DroneIdLogMsgAll, nil)
			}
		} else {
			//追加写入
			file, err := os.OpenFile(fileInfo.FilePath, os.O_APPEND|os.O_WRONLY, 0644)
			if err != nil {
				logger.Error(err)
			}
			file.WriteString(strings.Join(mavlink.DroneIdLogMsgAll.GetData(), ""))
			defer file.Close()
			manager, ok := d.WaitTaskMap[mavlink.TracerIdGetLog]
			if ok {
				manager.CompletedTask(&mavlink.DroneIdLogMsgAll, nil)
			}
		}

		mavlink.DroneIdLogMsgAll.DeleteData()
		FileNameMap.Del(LogId)
	}
	logger.Info("-->Receive Get Log  end")
}

// SendDelLog -----------------------------删除日志-----------------------------------------------
// 发送删除DroneId日志指令
func (d *DroneID) SendDelLog(sn string, logDir string) (*mavlink.DroneIdDelLogResponse, error) {
	logger.Info("-->Into Send Del Log")
	req := mavlink.DroneIdDelLogRequestAll{}
	reqBuff := req.CreateDroneIdDelLog(logDir)
	if err := d.Send(sn, reqBuff); err != nil {
		logger.Error("-->Send Del Log To DroneId Fail,err : ", err)
		return nil, err
	}
	manager, ok := d.WaitTaskMap[mavlink.TracerIdDeleteLog]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdDeleteLog, true, 0)
		d.WaitTaskMap[mavlink.TracerIdDeleteLog] = manager
	}
	// TODO 处理包序
	result, err := manager.Wait()
	if err != nil {
		logger.Error("-->Send Del Log Wait err : ", err)
		return nil, err
	}
	logger.Info("-->Send Del Log End")
	return result.(*mavlink.DroneIdDelLogResponse), nil
}

// ReceiveDelLog 接收DroneId日志文件返回
func (d *DroneID) ReceiveDelLog() {
	logger.Info("-->into Receive Del Log")
	res := &mavlink.DroneIdDelLogResponse{}
	d.GetPacket(res)
	logger.Info("Del Log response : ", res.Status)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdDeleteLog]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->Receive Del Log end")
}

// ReceiveGetTime 接收DroneId获取时间消息
func (d *DroneID) ReceiveGetTime() {
	logger.Info("-->into Send Time To DroneID")
	res := &mavlink.DroneIdGetTimeResponse{}
	time1 := time.Now()
	resTime := time1.Format("20060102150405")

	var byteArr [20]byte

	for k := range resTime {
		byteArr[k] = resTime[k]
	}

	rspBuf := res.CreateGetTimeMessage(byteArr)
	logger.Debugf("Send Time To DroneID Data:%v", rspBuf)

	n, err := d.Conn.Write(rspBuf)
	logger.Debugf("Send Time To DroneID：%v,%#v", n, res)
	if err != nil {
		logger.Error("Send Time To DroneID err:", err)
		return
	}
	logger.Info("--->End Send Time To DroneID")
	return
}

func (d *DroneID) UpdateTracerTypeByDetect(detectType int32, devSn string) {
	tracerName := ""
	if detectType == mavlink.TracerIdGetDetectRes {
		tracerName = helper.DevTypeFromIntToStr(int32(client.EnumDevTypeList_TracerPDevTypeEnum))

	} else if detectType == mavlink.TracerIdGetRemoteIdDetectRes {
		tracerName = helper.DevTypeFromIntToStr(int32(client.EnumDevTypeList_TracerPDevTypeEnum))

	} else if detectType == mavlink.TracerIdGetFreqDetectRes {
		tracerName = helper.DevTypeFromIntToStr(int32(client.EnumDevTypeList_TracerSDevTypeEnum))

	} else {
	}
	if len(tracerName) <= 0 {
		return
	}

	{
		key := devSn + ":" + "tracer_type_check"

		droneIDTypeLock.Lock()
		defer droneIDTypeLock.Unlock()

		_, ok := droneIDTypeMap.Load(key)
		if ok {
			return
		}
		droneIDTypeMap.Store(key, 1)
	}

	err := NewEquipList().UpdateSomeFields(context.Background(), &client.UpdateCondReq{Sn: devSn, Etype: tracerName}, nil)
	if err != nil {
		logger.Errorf("update tracer etype fail, e: %v", err)
		return
	}
	logger.Info("update tracer etype succ, sn: %v, etype: %v", devSn, tracerName)
}

// ReceiveDetectRes 收到Tracer侦测结果
func (d *DroneID) ReceiveDetectRes() {
	logger.Info("--->Into Receive Detect Res")
	result := &mavlink.TracerDetectResult{}
	if err := d.UnmarshalPayloadDetectRes(result); err != nil {
		logger.Errorf(err.Error())
		return
	}
	devSn := ByteToString(result.Info.SN[:])
	if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		logger.Infof("device %v disable", devSn)
		return
	}
	if len(result.Description) == 0 {
		return
	}
	if devSn != "" {
		d.detectReport(devSn, result)
	}
	//收到Tracer侦测到无人机数据，向数据库记录当天有记录
	if _, exist := RadarReplayMap.Get(devSn); exist {
		return
	}
	RadarReplayMap.Set(devSn, devSn, true)
	time1 := time.Now()
	resTime := time1.Format("20060102")
	NewDevSchedule().Insert(context.Background(), &client.DevScheduleInsertReq{Sn: devSn, Date: resTime, Information: 1}, &client.DevScheduleInsertRsp{})
	logger.Info("--->End Receive Detect Res")
}

func (d *DroneID) updateDetectEventOne(sn string, detectInfo []*mavlink.TracerDetectDescriptionReport) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}
	if len(detectInfo) <= 0 {
		logger.Infof("detect uav info is empty")
		return
	}

	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_V2DRONEID,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)

	var info []*client.TracerDetectDescription
	for _, desc := range detectInfo {
		if desc == nil {
			continue
		}
		info = append(info, &client.TracerDetectDescription{
			ProductType:    int32(desc.ProductType),
			DroneName:      desc.DroneName,
			SerialNum:      desc.SerialNum,
			DroneLongitude: desc.DroneLongitude,
			DroneLatitude:  desc.DroneLatitude,
		})
	}

	eventDetectInfo := &client.TracerDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventDetectAppear,
		},
		Data: &client.TracerDetectReport{
			EventId: utils.GetEventId(detect.SessionId),
			Sn:      sn,
			Info:    info,
		},
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer detect uav event has reported, devSn: %v,report:%v", sn, detectInfo)
}
func (d *DroneID) detectReport(devSn string, detectInfo *mavlink.TracerDetectResult) {
	logger.Info("--->Into Report Detect Res")
	var report mavlink.TracerDetectReport
	report.Description = make([]*mavlink.TracerDetectDescriptionReport, 0, len(detectInfo.Description))
	report.Sn = devSn

	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}

	for _, drone := range detectInfo.Description {
		//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
		var role int32
		for _, info := range whiteList.WhiteList {
			if info.Sn == ByteToString(drone.SerialNum[:]) {
				role = info.Role
			}
		}
		if role == ERRTYPE {
			role = ENEMY
		}

		r := &mavlink.TracerDetectDescriptionReport{
			ProductType:        drone.ProductType,
			DroneName:          ByteToString(drone.DroneName[:]),
			SerialNum:          ByteToString(drone.SerialNum[:]),
			DroneLongitude:     detectInfo.DroneCoordinateConvert(float64(drone.DroneLongitude)),
			DroneLatitude:      detectInfo.DroneCoordinateConvert(float64(drone.DroneLatitude)),
			DroneHeight:        float64(drone.DroneHeight) / DroneHeightPrecision,
			DroneYawAngle:      float64(drone.DroneYawAngle) / DroneYawAnglePrecision,
			DroneSpeed:         float64(drone.DroneSpeed) / DroneSpeedPrecision,
			DroneVerticalSpeed: float64(drone.DroneVerticalSpeed) / DroneVerticalSpeedPrecision,
			OperatorLongitude:  detectInfo.DroneCoordinateConvert(float64(drone.OperatorLongitude)),
			OperatorLatitude:   detectInfo.DroneCoordinateConvert(float64(drone.OperatorLatitude)),
			Freq:               float64(drone.Freq) / FreqPrecision,
			Distance:           drone.Distance,
			DangerLevels:       drone.DangerLevels,
			Role:               role,
		}
		report.Description = append(report.Description, r)
	}
	d.updateDetectEventOne(devSn, report.Description)

	msg := common.EquipmentMessageBoxEntity{
		Name:      devSn,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetDetectRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))
	logger.Infof("Tracer Detect has reported, devSn: %v, Drone size: %v", devSn, len(report.Description))
	logger.Info("--->End Report Detect Res")
}

func (d *DroneID) UnmarshalPayloadDetectRes(data *mavlink.TracerDetectResult) error {
	deviceInfoLen := binary.Size(mavlink.TracerDetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

// ReceiveRemoteIdDetectRes 收到Tracer Remote侦测结果
func (d *DroneID) ReceiveRemoteIdDetectRes() {
	logger.Info("--->Into Receive Remote Detect Res")
	result := &mavlink.TracerRemoteDetectResult{}
	if err := d.UnmarshalPayloadRemoteDetectRes(result); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if devSn != "" {
		if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
			logger.Infof("device %v disable", devSn)
			return
		}
		d.remoteIdDetectReport(devSn, result)
	}
	logger.Info("--->End Receive Remote Detect Res")
}

func (d *DroneID) updateRemoteDetectEvent(sn string, detectInfo []*mavlink.TracerRemoteDetectDescriptionReport) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}
	if len(detectInfo) <= 0 {
		logger.Infof("detect uav info is empty")
		return
	}

	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_V2DRONEID,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)

	var info []*client.TracerDetectDescription
	for _, desc := range detectInfo {
		if desc == nil {
			continue
		}
		info = append(info, &client.TracerDetectDescription{
			ProductType:    int32(desc.ProductType),
			DroneName:      desc.DroneName,
			SerialNum:      desc.SerialNum,
			DroneLongitude: desc.DroneLongitude,
			DroneLatitude:  desc.DroneLatitude,
		})
	}

	eventDetectInfo := &client.TracerDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventDetectAppear,
		},
		Data: &client.TracerDetectReport{
			EventId: utils.GetEventId(detect.SessionId),
			Sn:      sn,
			Info:    info,
		},
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer detect uav event has reported, devSn: %v,report:%v", sn, detectInfo)
}
func (d *DroneID) remoteIdDetectReport(devSn string, detectInfo *mavlink.TracerRemoteDetectResult) {
	logger.Info("--->Into Receive Remote Report Res")
	var report mavlink.TracerRemoteDetectReport
	report.Description = make([]*mavlink.TracerRemoteDetectDescriptionReport, 0, len(detectInfo.Description))
	report.Sn = devSn

	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	for _, drone := range detectInfo.Description {
		//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
		var role int32
		for _, info := range whiteList.WhiteList {
			if info.Sn == ByteToString(drone.SerialNum[:]) {
				role = info.Role
			}
		}
		if role == ERRTYPE {
			role = ENEMY
		}
		r := &mavlink.TracerRemoteDetectDescriptionReport{
			ProductType:         drone.ProductType,
			DroneName:           ByteToString(drone.DroneName[:]),
			SerialNum:           ByteToString(drone.SerialNum[:]),
			DroneLongitude:      detectInfo.DroneCoordinateConvert(float64(drone.DroneLongitude)),
			DroneLatitude:       detectInfo.DroneCoordinateConvert(float64(drone.DroneLatitude)),
			DroneHeight:         float64(drone.DroneHeight) / DroneHeightPrecision,
			DroneDirection:      float64(drone.DroneDirection) / DroneDirection,
			DroneSpeedderection: drone.DroneSpeedderection,
			DroneSpeed:          float64(drone.DroneSpeed) / DroneSpeedPrecision,
			DroneVerticalSpeed:  float64(drone.DroneVerticalSpeed) / DroneSpeedPrecision,
			OperatorLongitude:   detectInfo.DroneCoordinateConvert(float64(drone.OperatorLongitude)),
			OperatorLatitude:    detectInfo.DroneCoordinateConvert(float64(drone.OperatorLatitude)),
			Freq:                float64(drone.Freq) / FreqPrecision,
			Distance:            drone.Distance,
			DangerLevels:        drone.DangerLevels,
			Role:                role,
		}
		report.Description = append(report.Description, r)
	}
	d.updateRemoteDetectEvent(devSn, report.Description)

	msg := common.EquipmentMessageBoxEntity{
		Name:      devSn,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetRemoteIdDetectRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))
	logger.Info("--->End Receive Remote Report Res")
	logger.Infof("Tracer Detect Remote has reported, devSn: %v, Drone size: %v", devSn, len(report.Description))
}

func (d *DroneID) UnmarshalPayloadRemoteDetectRes(data *mavlink.TracerRemoteDetectResult) error {
	deviceInfoLen := binary.Size(mavlink.TracerRemoteDetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

// ReceiveFreqDetectRes 收到Tracer 频谱侦测结果
func (d *DroneID) ReceiveFreqDetectRes() {
	logger.Info("--->Into Receive Freq Detect Res")
	result := &mavlink.TracerFreqDetectResult{}
	if err := d.UnmarshalPayloadFreqDetectRes(result); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if devSn != "" {
		if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
			logger.Infof("device %v disable", devSn)
			return
		}
		d.freqDetectReport(devSn, result)
	}
	logger.Info("--->End Receive Freq Detect Res")
}
func (d *DroneID) updateFreqDetectEvent(sn string, detectInfo []*mavlink.TracerFreqDetectDescription) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}
	if len(detectInfo) <= 0 {
		logger.Infof("detect uav info is empty")
		return
	}

	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_V2DRONEID,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)

	var info []*client.TracerDetectDescription
	for _, desc := range detectInfo {
		if desc == nil {
			continue
		}
		info = append(info, &client.TracerDetectDescription{
			ProductType: int32(desc.UavNumber),
			DroneName:   string(desc.DroneName[:]),
			//SerialNum:      int32(desc.UavNumber),
			//DroneLongitude: desc.DroneLongitude,
			//DroneLatitude:  desc.DroneLatitude,
		})
	}

	eventDetectInfo := &client.TracerDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventDetectAppear,
		},
		Data: &client.TracerDetectReport{
			EventId: utils.GetEventId(detect.SessionId),
			Sn:      sn,
			Info:    info,
		},
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer detect uav event has reported, devSn: %v,report:%v", sn, detectInfo)
}
func (d *DroneID) freqDetectReport(devSn string, detectInfo *mavlink.TracerFreqDetectResult) {
	logger.Info("--->Into Receive Freq Report Res")

	var report mavlink.TracerFreqDetectReport
	report.Description = make([]*mavlink.TracerFreqDetectDescriptionReport, 0, len(detectInfo.Description))
	report.Sn = devSn
	report.DxPower = float64(detectInfo.Info.DxPower)
	report.QxPower = float64(detectInfo.Info.QxPower)
	report.DxHorizon = float64(detectInfo.Info.DxHorizon) / DroneHorizonPrecision

	for _, drone := range detectInfo.Description {
		tempDroneHorizon := drone.DroneHorizon

		if tempDroneHorizon > MAXDroneHorizon {
			tempDroneHorizon = Invalid
		}
		r := &mavlink.TracerFreqDetectDescriptionReport{
			UavNumber:     uint32(drone.UavNumber),
			DroneName:     ByteToString(drone.DroneName[:]),
			DroneHorizon:  float64(tempDroneHorizon) / DroneHorizonPrecision,
			UFreq:         float64(drone.UFreq) / FreqPrecision,
			UDangerLevels: drone.UDangerLevels,
			Recerve:       drone.Recerve,
		}
		logger.Infof("droneID Detect Freq data: %+v", *r)
		report.Description = append(report.Description, r)
	}

	d.updateFreqDetectEvent(devSn, detectInfo.Description)

	msg := common.EquipmentMessageBoxEntity{
		Name:      devSn,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetFreqDetectRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))
	logger.Info("--->End Receive Freq Report Res")
	logger.Infof("Tracer Detect Freq has reported, devSn: %v, Drone size: %v", devSn, len(report.Description))
}

func (d *DroneID) UnmarshalPayloadFreqDetectRes(data *mavlink.TracerFreqDetectResult) error {
	deviceInfoLen := binary.Size(mavlink.TracerFreqDetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

// ReceiveNewFreqDetectRes 收到Tracer 频谱侦测结果
func (d *DroneID) ReceiveNewFreqDetectRes() {
	logger.Info("--->Into Receive New Freq Detect Res")
	result := &mavlink.TracerNewFreqDetectResult{}
	if err := d.UnmarshalPayloadNewFreqDetectRes(result); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if devSn != "" {
		if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
			logger.Infof("device %v disable", devSn)
			return
		}
		d.newfreqDetectReport(devSn, result)
	}
	logger.Info("--->End Receive New Freq Detect Res")
}

func (d *DroneID) updateDetectEventNew(sn string, detectInfo []*mavlink.TracerNewFreqDetectDescription) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}
	if len(detectInfo) <= 0 {
		logger.Infof("detect uav info is empty")
		return
	}

	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_V2DRONEID,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)

	var info []*client.TracerDetectDescription
	for _, desc := range detectInfo {
		if desc == nil {
			continue
		}
		info = append(info, &client.TracerDetectDescription{
			ProductType: int32(desc.UavNumber),
			DroneName:   string(desc.DroneName[:]),
			SerialNum:   strconv.FormatInt(int64(desc.UavNumber), 10),
			//DroneLongitude: desc.DroneLongitude,
			//DroneLatitude:  desc.DroneLatitude,
		})
	}

	eventDetectInfo := &client.TracerDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventDetectAppear,
		},
		Data: &client.TracerDetectReport{
			EventId: utils.GetEventId(detect.SessionId),
			Sn:      sn,
			Info:    info,
		},
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer detect uav event has reported, devSn: %v,report:%v", sn, detectInfo)

}
func (d *DroneID) newfreqDetectReport(devSn string, detectInfo *mavlink.TracerNewFreqDetectResult) {
	logger.Info("--->Into Receive New Freq Report Res")
	var report mavlink.TracerFreqDetectReport
	report.Description = make([]*mavlink.TracerFreqDetectDescriptionReport, 0, len(detectInfo.Description))
	report.Sn = devSn
	report.DxPower = float64(detectInfo.Info.DxPower)
	report.QxPower = float64(detectInfo.Info.QxPower)
	report.DxHorizon = float64(detectInfo.Info.DxHorizon) / DroneHorizonPrecision

	for _, drone := range detectInfo.Description {
		tempDroneHorizon := drone.DroneHorizon

		if tempDroneHorizon > MAXDroneHorizon {
			tempDroneHorizon = Invalid
		}
		dist := fmt.Sprintf("%.1f", drone.Dist)
		distResult, _ := strconv.ParseFloat(dist, 64)
		r := &mavlink.TracerFreqDetectDescriptionReport{
			UavNumber:     uint32(drone.UavNumber),
			DroneName:     ByteToString(drone.DroneName[:]),
			DroneHorizon:  float64(tempDroneHorizon) / DroneHorizonPrecision,
			UFreq:         float64(drone.UFreq) / FreqPrecision,
			UDangerLevels: drone.UDangerLevels,
			UMoving:       int32(drone.UMoving),
			Dist:          distResult,
			Recerve:       drone.Recerve,
		}
		logger.Infof("droneID Detect Freq data: %+v", *r)
		report.Description = append(report.Description, r)
	}

	d.updateDetectEventNew(devSn, detectInfo.Description)

	msg := common.EquipmentMessageBoxEntity{
		Name:      devSn,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetFreqDetectRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))
	logger.Info("--->End Receive New Freq Report Res")
	logger.Infof("Tracer Detect New Freq has reported, devSn: %v, Drone size: %v", devSn, len(report.Description))
}

func (d *DroneID) UnmarshalPayloadNewFreqDetectRes(data *mavlink.TracerNewFreqDetectResult) error {
	deviceInfoLen := binary.Size(mavlink.TracerNewFreqDetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

// ReceiveFreqDataRes 收到Tracer 频谱仪数据 E4
func (d *DroneID) ReceiveFreqDataRes() {
	logger.Info("--->Into Receive Freq Data Res")
	result := &mavlink.TracerSFreqDataResult{}
	if err := d.UnmarshalPayloadFreqDataRes(result); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if devSn != "" {
		if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
			logger.Infof("device %v disable", devSn)
			return
		}
		d.freqDataReport(devSn, result)
	}
	logger.Info("--->End Receive Freq Detect Res")
}

func (d *DroneID) ReceiveFreqDetectExp() {
	logger.Infof("call ReceiveFreqDetectExp")
	result := new(mavlink.TracerSFreqDetectExp)
	if e := d.UnmarshalPayLoadFreqDetectExp(result); e != nil {
		logger.Errorf("parse TracerSFreqDetectExp from bin fail, e: %v", e)
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if len(devSn) <= 0 {
		return
	}
	if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		logger.Infof("dev is offline, sn: %v", devSn)
		return
	}
	d.freqDetectExpReport(devSn, result)

	for _, detectInfo := range result.Desc {
		if detectInfo == nil {
			continue
		}
		TracerSOrientInstance().DoOrientLogicOnDetect(devSn, detectInfo)
	}
}

func (d *DroneID) updateDetectEventExp(sn string, detectInfo []*mavlink.TracerSFreqDetectExpDesc) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}
	if len(detectInfo) <= 0 {
		logger.Infof("detect uav info is empty")
		return
	}

	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_V2DRONEID,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)

	var info []*client.TracerDetectDescription
	for _, desc := range detectInfo {
		if desc == nil {
			continue
		}
		info = append(info, &client.TracerDetectDescription{
			ProductType: int32(desc.UavNumber),
			DroneName:   string(desc.DroneName[:]),
			SerialNum:   strconv.FormatInt(int64(desc.UavNumber), 10),
			//DroneLongitude: desc.DroneLongitude,
			//DroneLatitude:  desc.DroneLatitude,
		})
	}

	eventDetectInfo := &client.TracerDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventDetectAppear,
		},
		Data: &client.TracerDetectReport{
			EventId: utils.GetEventId(detect.SessionId),
			Sn:      sn,
			Info:    info,
		},
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer detect uav event has reported, devSn: %v,report:%v", sn, detectInfo)
}

func (d *DroneID) freqDetectExpReport(devSn string, detectInfo *mavlink.TracerSFreqDetectExp) {
	logger.Info("--->Into Receive Freq Report expand")
	var report mavlink.TracerFreqDetectReport
	report.Description = make([]*mavlink.TracerFreqDetectDescriptionReport, 0, len(detectInfo.Desc))
	report.Sn = devSn
	report.DxPower = float64(detectInfo.Info.DxPower)
	report.QxPower = float64(detectInfo.Info.QxPower)
	report.DxHorizon = float64(detectInfo.Info.DxHorizon) / DroneHorizonPrecision
	report.StartAngle = float64(detectInfo.Info.StartAngle) / DroneHorizonPrecision
	report.EndAngle = float64(detectInfo.Info.EndAngle) / DroneHorizonPrecision

	for _, drone := range detectInfo.Desc {
		tempDroneHorizon := drone.DroneHorizon

		if tempDroneHorizon > MAXDroneHorizon {
			tempDroneHorizon = Invalid
		}
		dist := fmt.Sprintf("%.1f", drone.Reserve4)
		distResult, _ := strconv.ParseFloat(dist, 64)
		r := &mavlink.TracerFreqDetectDescriptionReport{
			UavNumber:     drone.UavNumber,
			DroneName:     ByteToString(drone.DroneName[:]),
			DroneHorizon:  float64(tempDroneHorizon) / DroneHorizonPrecision,
			UFreq:         float64(drone.UFreq) / FreqPrecision,
			UDangerLevels: drone.UDangerLevels,
			UMoving:       int32(drone.Reserve1),
			Dist:          distResult,
			Recerve:       drone.Reserve42,
			IsSptOrient:   drone.IsSptOrient,
			OrientState:   drone.OrientState,
			ReserveOther:  drone.Reserve41,
		}
		logger.Infof("droneID Detect Freq data: %+v", *r)
		report.Description = append(report.Description, r)
	}

	d.updateDetectEventExp(devSn, detectInfo.Desc)

	msg := common.EquipmentMessageBoxEntity{
		Name:      devSn,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetFreqDetectRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))
	logger.Infof("Tracer Detect Freq expand has reported, devSn: %v, Drone size: %v", devSn, len(report.Description))
}
func (d *DroneID) UnmarshalPayLoadFreqDetectExp(data *mavlink.TracerSFreqDetectExp) error {
	deviceInfoLen := binary.Size(mavlink.TracerFreqDetectInfoExp{})
	buff := new(bytes.Buffer)

	if e := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); e != nil {
		return fmt.Errorf("parse TracerFreqDetectInfo from bin fail, e: %v", e)
	}
	if e := binary.Read(buff, binary.LittleEndian, &data.Info); e != nil {
		return fmt.Errorf("parse TracerSFreqDetectExp.Info fail, e: %v", e)
	}
	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen

	if e := data.DeserializeFreqData(d.Msg[start:end]); e != nil {
		return e
	}
	return nil
}
func (d *DroneID) UnmarshalPayloadFreqDataRes(data *mavlink.TracerSFreqDataResult) error {
	deviceInfoLen := binary.Size(mavlink.TracerSFreqDataInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeFreqData(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}
func (d *DroneID) updateDetectEvent(sn string, detectInfo []*mavlink.TracerSFreqDataDescription) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}
	if len(detectInfo) <= 0 {
		logger.Infof("detect uav info is empty")
		return
	}

	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_V2DRONEID,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)

	var info []*client.TracerDetectDescription
	for _, desc := range detectInfo {
		if desc == nil {
			continue
		}
		info = append(info, &client.TracerDetectDescription{
			Freq: float64(desc.AmpValue),
		})
	}

	eventDetectInfo := &client.TracerDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventDetectAppear,
		},
		Data: &client.TracerDetectReport{
			EventId: utils.GetEventId(detect.SessionId),
			Sn:      sn,
			Info:    info,
		},
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer detect uav event has reported, devSn: %v,report:%v", sn, detectInfo)
}
func (d *DroneID) freqDataReport(devSn string, freqData *mavlink.TracerSFreqDataResult) {
	logger.Info("--->Into Receive Freq Data Res")
	report := client.TracerSFreqDataReport{}
	report.Info = make([]*client.TracerSFreqDataDescription, 0, len(freqData.Description))
	report.Sn = devSn
	report.FreqNum = int32(freqData.Info.FreqNum)
	for _, description := range freqData.Description {
		report.Info = append(report.Info, &client.TracerSFreqDataDescription{
			AmpValue: description.AmpValue,
		})

	}
	msg := common.EquipmentMessageBoxEntity{
		Name:      devSn,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetFreqDataRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	d.updateDetectEvent(devSn, freqData.Description)

	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))
	logger.Info("--->End Receive Freq Data Report Res len:", len(report.Info))
	logger.Infof("Tracers  Freq data, devSn: %v", devSn)
}

// HandleBroadCast 处理广播消息
func (d *DroneID) HandleBroadCast(ctx context.Context, req *slinkv1.UdpBroadcastConfirmRequest) (*slinkv1.UdpBroadcastConfirmResponse, error) {
	if req.GetSn() == "" {
		logger.Info("device sn empty")
		return nil, nil
	}

	if status := d.GetStatus(req.GetSn()); status == common.DeviceDisenable {
		logger.Infof("device %v disable", req.GetSn())
		return nil, nil
	}

	localIP := make([]string, 0)
	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[tracer] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(req.GetSn(), localIP)
	DevSnMap.Store(tcpServer.Port, req.GetSn())
	d.ServerPort = tcpServer.Port

	//响应
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       req.Sn,
		Addr:     ip.IPV4(tcpServer.Ip),
		Port:     uint16(tcpServer.Port),
		ConnType: 1,
	}
	return rsp, nil
}

// SendTracerSetWhite 发送设置tracer白名单
func (d *DroneID) SendTracerSetWhite(snList []mavlink.TracerWhiteInfo) (int, error) {
	logger.Info("---> Send Tracer Set White")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Tracer Set White occurred:", r)
			return
		}
	}()
	req := mavlink.TracerSetWhiteRequestAll{}
	whitelist := make([]mavlink.TracerWhiteInfo, 0)
	for _, s := range snList {
		whitelist = append(whitelist, mavlink.TracerWhiteInfo{Serial: s.Serial})
	}
	reqInfo := &mavlink.TracerSetWhiteRequest{
		WhiteNum:  uint16(len(whitelist)),
		WhiteList: whitelist,
	}

	buff := req.Create(reqInfo)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerSetWhiteList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerSetWhiteList, true, time.Millisecond*300)
		d.WaitTaskMap[mavlink.TracerSetWhiteList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer Set White is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer Set White  err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer Set White  err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.TracerSetWhiteResponse)

	logger.Info("-->End Set Tracer Set Alarm")
	return int(res.Status), nil
}

func (d *DroneID) ReceiveTracerSetWhite() {
	logger.Info("-->into Receive Tracer Set White")
	res := &mavlink.TracerSetWhiteResponse{}
	d.GetPacket(res)
	logger.Debugf("Set White 接收到tracer 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerSetWhiteList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SendTracerSetAlarm 发送设置tracer告警
func (d *DroneID) SendTracerSetAlarm(level int) (int, error) {
	logger.Info("---> Send Tracer Set Alarm")
	req := &mavlink.TracerSetAlarmRequest{}
	buff := req.Create(level)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerSetAlarmLevel]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerSetAlarmLevel, true, 0)
		d.WaitTaskMap[mavlink.TracerSetAlarmLevel] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer Set Alarm is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer Set Alarm  err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer Set Alarm  err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.TracerSetAlarmResponse)

	logger.Info("-->End Set Tracer Set Alarm")
	return int(res.Status), nil
}

func (d *DroneID) ReceiveTracerSetAlarm() {
	logger.Info("-->into Receive Set Alarm")
	res := &mavlink.TracerSetAlarmResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Alarm 接收到tracer 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerSetAlarmLevel]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SendTracerSetHideMode 发送设置tracer隐蔽模式
func (d *DroneID) SendTracerSetHideMode(level int) (int, error) {
	logger.Info("---> Send Tracer Set HideMode")
	req := &mavlink.TracerSetHideModeRequest{}

	buff := req.Create(level)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerSetHideMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerSetHideMode, true, 0)
		d.WaitTaskMap[mavlink.TracerSetHideMode] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer Set HideMode is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer Set HideMode  err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer Set HideMode  err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.TracerSetHideModeResponse)

	logger.Info("-->End Set Tracer Set HideMode")
	return int(res.Status), nil
}

func (d *DroneID) ReceiveTracerSetHideMode() {
	logger.Info("-->into Receive Set Hide Mode")
	res := &mavlink.TracerSetHideModeResponse{}
	d.GetPacket(res)
	logger.Debugf("Set HideMode 接收到tracer 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerSetHideMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func SendDevWhiteList() {
	deviceInfo := &client.EquipListRes{}
	err := NewEquipList().List(context.Background(), &client.EquipListReq{}, deviceInfo)
	if err != nil {
		logger.Info("Get EquipList err: ", err)
	}
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err = NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	logger.Info("Get EquipList is : ", whiteList.WhiteList)
	snList := make([]mavlink.TracerWhiteInfo, 0)

	for _, all := range whiteList.WhiteList {
		if all.Role == FRIEND {
			var tempSn [32]byte
			copy(tempSn[:], all.Sn)
			snList = append(snList, mavlink.TracerWhiteInfo{Serial: tempSn})
		}
	}
	for _, equip := range deviceInfo.Equips {
		if equip.Etype == "DroneID" {
			tracerInfo := FindCacheDevice(equip.Sn, common.DEV_V2DRONEID)
			if tracerInfo == nil {
				continue
			} else {
				dev := &DroneID{Device: tracerInfo}
				dev.SendTracerSetWhite(snList)
			}

		}
	}
}

const (
	VideoFail = 0
)

// ControlVideoCmd send Tracer Video control
func (d *DroneID) ControlVideoCmd(op uint8, uavName uint8, droneName []uint8, freq uint32) (int32, error) {
	tmpArray := [mavlink.DevSNLen]uint8{}
	copy(tmpArray[:], droneName)

	req := &mavlink.TracerVideoControlRequest{
		Status:    op,
		UavName:   uavName,
		DroneName: tmpArray,
		Freq:      freq,
	}

	buf := req.Build(uint8(common.DEV_V2DRONEID))
	if buf == nil {
		return VideoFail, errors.New("build send to tracer pkg fail")
	}

	mng, ok := d.WaitTaskMap[mavlink.TracerControlVideo]
	if !ok {
		mng = NewWaitTaskManager(mavlink.TracerControlVideo, true, 5*time.Second)
		d.WaitTaskMap[mavlink.TracerControlVideo] = mng
	}

	task := mng.AddTask(nil, nil)

	logger.Debugf("send tracer video msg: [% x]", buf)

	if _, e := d.Conn.Write(buf); e != nil {
		logger.Errorf("send tracer video control fail, e: %v, value: %v", e, buf)
		return VideoFail, e
	}

	ret, e := mng.WaitTask(task)
	if e != nil {
		logger.Errorf("set tracer video control response, fail,e: %v", e)
		return VideoFail, e
	}

	res := ret.(*mavlink.TracerVideoControlResponse)
	if res.Status == 0 {
		return VideoFail, nil
	}
	return int32(res.Status), nil
}
func (d *DroneID) ProcVideoCmdResponse() {
	logger.Info("--->Into Receive video cmd star/stop response from device")
	result := &mavlink.TracerVideoControlResponse{}

	d.GetPacket(result)
	logger.Debugf("ProcVideoCmdResponse 获取信息：%#v", result)
	manager, ok := d.WaitTaskMap[mavlink.TracerControlVideo]
	if ok {
		manager.CompletedTask(result, nil)
	}
	logger.Infof("process video cmd star/stop response from device.")
	return
}

func (d *DroneID) TransferVideoStream() {
	FpvVideoInstance().UpdateStatusOnPushingVideo()

	logger.Info("receive fpv transfer video stream.")
	videoStreamPkg := &mavlink.FpvTransferVideoStreamPkg{}

	readBegin := mavlink.HeaderLen
	offSet := mavlink.DevSNLen
	readEnd := readBegin + offSet
	err := mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &videoStreamPkg.SN, offSet)
	logger.Debug("SN : ", string(videoStreamPkg.SN[:]))

	if isEnable := d.updateStatus(string(videoStreamPkg.SN[:])); isEnable == common.DeviceDisenable {
		logger.Infof("device %v disable", string(videoStreamPkg.SN[:]))
		return
	}

	// struct 转 pb协议
	devSn := ByteToString(videoStreamPkg.SN[:])
	if devSn == "" {
		return
	}
	if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		logger.Infof("Fpv device %v disable", devSn)
		return
	}

	readBegin = readEnd
	offSet = 4
	readEnd = readBegin + offSet
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &videoStreamPkg.FrameIndex, offSet)
	logger.Debug("FrameIndex : ", videoStreamPkg.FrameIndex)

	readBegin = readEnd
	offSet = 4
	readEnd = readBegin + offSet
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &videoStreamPkg.PkgMax, offSet)
	logger.Debug("PkgMax : ", videoStreamPkg.PkgMax)

	readBegin = readEnd
	offSet = 4
	readEnd = readBegin + offSet
	_ = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &videoStreamPkg.PkgIndex, offSet)
	logger.Debug("PkgIndex : ", videoStreamPkg.PkgIndex)

	readBegin = readEnd
	offSet = 4
	readEnd = readBegin + offSet
	_ = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &videoStreamPkg.DataLen, offSet)
	logger.Debug("DataLen : ", videoStreamPkg.DataLen)

	if videoStreamPkg.PkgMax == 0 && videoStreamPkg.PkgIndex == 0 {
		return
	}
	if videoStreamPkg.DataLen <= 0 {
		logger.Errorf("has no msg data")
		return
	}
	logger.Infof("sub pkg data len: %v, this pkg total pkg len: %v", videoStreamPkg.DataLen, d.MsgLen)

	readBegin = readEnd
	offSet = int(videoStreamPkg.DataLen)
	readEnd = readBegin + offSet
	videoStreamPkg.Data = make([]byte, offSet)
	//  是否需要循环等待去读。应该不需要，框架根据头部长度已经把数据读完整了。
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, videoStreamPkg.Data, offSet)
	if err != nil {
		logger.Errorf("msg decode fail, e: %v", err)
		return
	}
	// 必须先更新值内容，然后在更新索引，因为更新值比更新索引更耗时，如果顺序互换，由于并发性，有可能索引建立，但是值未就绪，倒置取完整数据时异常。
	FpvVideoFrameIndexMng.SetData(int32(videoStreamPkg.FrameIndex),
		int32(videoStreamPkg.PkgIndex), videoStreamPkg.Data)

	FpvVideoFrameIndexMng.SetFramePkgIndex(int32(videoStreamPkg.FrameIndex),
		int32(videoStreamPkg.PkgIndex), int32(videoStreamPkg.PkgMax))

	if !FpvVideoFrameIndexMng.IsFullPkg(int32(videoStreamPkg.FrameIndex)) {
		logger.Infof("continue to receive pkg, frameIndex: %v", videoStreamPkg.FrameIndex)
		return
	}

	responseBuf := []byte{}
	for i := 0; i < int(videoStreamPkg.PkgMax); i++ {
		bufData := FpvVideoFrameIndexMng.GetData(int32(videoStreamPkg.FrameIndex), int32(i))
		if bufData == nil {
			logger.Infof("get incompletely frame index, omit this get, frame index: %v, pkgIndex: %v",
				videoStreamPkg.FrameIndex, i)
			return
		}
		responseBuf = append(responseBuf, bufData...)
	}
	// delete after receive all packages .
	for i := 0; i < int(videoStreamPkg.PkgMax); i++ {
		ii := int32(i)
		fIndex := int32(videoStreamPkg.FrameIndex)

		go func() {
			FpvVideoFrameIndexMng.DelData(fIndex, ii)
			FpvVideoFrameIndexMng.DelFrameIndex(fIndex)
		}()
	}

	logger.Infof("whole pkg len: %v, frameIndex: %v", len(responseBuf), videoStreamPkg.FrameIndex)

	msgProto := &client.FpvVideoStreams{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			MsgType:   mavlink.FpvVideoStreamMsg,
			EquipType: int32(common.DEV_FPV),
		},
		//
		Data: &client.FpvVideoStreamItem{
			FrameIndex: videoStreamPkg.FrameIndex,
			PackIndex:  videoStreamPkg.PkgIndex,
			PackMax:    videoStreamPkg.PkgMax,
			DataLen:    uint32(len(responseBuf)),
			Data:       responseBuf,
		},
		EndVideoCond: &client.VideoMsgForEnd{
			UavSeqNo:  FpvVideoInstance().UavSeqNo,
			DroneName: FpvVideoInstance().DroneName,
			UFreq:     FpvVideoInstance().UFreq,
			Sn:        devSn,
			DevType:   3,
		},
	}
	msgProtoBin, e := proto.Marshal(msgProto)
	if e != nil {
		logger.Errorf("marshal FpvVideoStreams fail, e: %v", e)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIdTransferFpvVideoStream,
		Data:    msgProtoBin,
	}
	out, e := proto.Marshal(report)
	if e != nil {
		logger.Errorf("marshal report data fail, e: %v", e)
		return
	}
	e = mq.FpvMsgBroker.Publish(mq.FpvTopic, broker.NewMessage(out))
	if e != nil {
		logger.Errorf("push msg on topic: %v fail", mq.FpvTopic)
		return
	}
	logger.Info("--->End Receive fpv video stream")
}
func TracerDetectDisappearEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	eventId := ""

	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*DetectEvent)
		eventId = utils.GetEventId(dev.SessionId)

	} else {
		logger.Infof("not exist on event status context, sn: %v", sn)
		return
	}
	DevDetectMapOnEvent.Delete(cacheKey)

	eventDetectInfo := &client.TracerDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventDetectDisappear,
		},
		Data: &client.TracerDetectReport{
			EventId: eventId,
			Sn:      sn,
		},
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer detect disappear uav event has reported, devSn: %v", sn)
}

func TracerOffLineEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	eventId := ""

	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		eventId = utils.GetEventId(dev.SessionId)

	} else {
		logger.Infof("not exist on event status context, sn: %v", sn)
		return
	}

	DevStatusMapOnEvent.Delete(cacheKey)

	dataInfo := &client.DroneStatusInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventOffLine,
		},
		Data: &client.DroneIDReport{
			Sn:       sn,
			IsOnline: common.DevOffline,
			EventId:  eventId,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerStatusEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer Offline event report: %v", report)
}
