package handler

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
	"fmt"
	"gorm.io/gorm"
	"math/rand"
	"sync"
	"testing"
	"time"
)

func GetIntervalTime(g *genReplayTypeCond) int64 {
	if g == nil {
		return 90
	}
	rand.Seed(time.Now().UnixNano())
	return rand.Int63n(g.timeIntervalEnd-g.timeIntervalBegin+1) + g.timeIntervalBegin
}

func StringRadarHeart(r *bean.RadarReplayHeart) string {
	s := fmt.Sprintf("sn: %v, create_time: %v", r.Sn, r.CreateTime)
	return s
}

// //写数据操作: radar
func WriteDbHeartOnRadar(bms, ems int64, g *genReplayTypeCond) {
	if g == nil {
		return
	}

	for b := bms; b < ems; b = b + GetIntervalTime(g) {
		tabName := common.BuildHeartTableName(g.sn, time.UnixMilli(b))
		utils.CheckAndCreateTab[bean.RadarReplayHeart](db.GetDB(), tabName, &bean.RadarReplayHeart{}, 0)

		data := bean.RadarReplayHeart{
			Sn:          g.sn,
			IsOnline:    1,
			Electricity: 30,
			CreateTime:  b,
		}
		arrData := []bean.RadarReplayHeart{
			data,
		}
		if err := g.dbHandle.Table(tabName).Create(&arrData).Error; err != nil {
			logger.Errorf("write radar heart fail, e: %v, data: %v", err, StringRadarHeart(&data))
		}
	}
}
func WriteDbDetectOnRadar(bms, ems int64, g *genReplayTypeCond) {
	if g == nil {
		return
	}

	for b := bms; b < ems; b = b + GetIntervalTime(g) {
		tabName := common.BuildDetectTableName(g.sn, time.UnixMilli(b))
		utils.CheckAndCreateTab[bean.RadarReplayDetect](db.GetDB(), tabName, &bean.RadarReplayDetect{}, 0)

		data := make([]bean.RadarReplayDetect, 0, g.DetectNum)
		for i := 0; i < int(g.DetectNum); i++ {
			data = append(data, bean.RadarReplayDetect{
				Sn:           g.sn,
				ObjId:        int(time.Now().Unix()),
				X:            11.11,
				Y:            22.22,
				Z:            33.33,
				Velocity:     44.44,
				Azimuth:      55.55,
				Alive:        100,
				ExistingProb: 90.0,
				StateType:    1,
				CreateTime:   b + int64(i),
			})
		}
		//time.Sleep(1 * time.Microsecond)

		if err := g.dbHandle.Table(tabName).Create(&data).Error; err != nil {
			logger.Errorf("write radar detect fail, e: %v", err)
		}
	}
}
func WriteDbPostureOnRadar(bms, ems int64, g *genReplayTypeCond) {
	if g == nil {
		return
	}

	for b := bms; b < ems; b = b + GetIntervalTime(g) {
		tabName := common.BuildPostureTableName(g.sn, time.UnixMilli(b))
		utils.CheckAndCreateTab[bean.RadarReplayPosture](db.GetDB(), tabName, &bean.RadarReplayPosture{}, 0)

		var data []bean.RadarReplayPosture
		data = append(data, bean.RadarReplayPosture{
			Sn:         g.sn,
			Heading:    12.11,
			Pitching:   12.12,
			Rolling:    12.13,
			Longitude:  12.14,
			Latitude:   12.15,
			CreateTime: b,
		})

		if err := g.dbHandle.Table(tabName).Create(&data).Error; err != nil {
			logger.Errorf("write radar posture fail, e: %v", err)
		}
	}
}

// / 写数据库： tracerP
func WriteDbDetectOnTracerP(bms, ems int64, g *genReplayTypeCond) {
	if g == nil {
		return
	}

	for b := bms; b < ems; b = b + GetIntervalTime(g) {
		tabName := common.BuildDetectTableName(g.sn, time.UnixMilli(b))
		utils.CheckAndCreateTab[bean.TracerReplayDetect](db.GetDB(), tabName, &bean.TracerReplayDetect{}, 0)

		data := make([]bean.TracerReplayDetect, 0, g.DetectNum)
		for i := 0; i < int(g.DetectNum); i++ {
			data = append(data, bean.TracerReplayDetect{
				Sn:                g.sn,
				OperatorLongitude: 11.11,
				OperatorLatitude:  11.12,
				Freq:              11.13,
				Distance:          11.14,
				DangerLevels:      1,
				Role:              1,
				DroneName:         "autel_drone",
				SerialNum:         fmt.Sprintf("droneId_%v_%v", i, b),
				DroneLongitude:    200,
				DroneLatitude:     300,
				DroneHeight:       400,
				DroneSpeed:        12.12,
				DroneYawAngle:     123.123,
				DetectSrcType:     12,

				QxPower:      123.123,
				DxPower:      123.123,
				DxHorizon:    123.123,
				DroneHorizon: 123.123,

				OnceSeq:    b,
				HasUav:     1,
				CreateTime: b + int64(i),
			})
		}
		//time.Sleep(1 * time.Microsecond)

		if err := g.dbHandle.Table(tabName).Create(&data).Error; err != nil {
			logger.Errorf("write tracerP detect fail, e: %v", err)
		}
	}
}

// 写数据库： tracerS
func WriteDbHeartOnTracerS(bms, ems int64, g *genReplayTypeCond) {
	if g == nil {
		return
	}

	for b := bms; b < ems; b = b + GetIntervalTime(g) {
		tabName := common.BuildHeartTableName(g.sn, time.UnixMilli(b))
		utils.CheckAndCreateTab[bean.TracerReplayHeart](db.GetDB(), tabName, &bean.TracerReplayHeart{}, 0)

		data := bean.TracerReplayHeart{
			Sn:          g.sn,
			IsOnline:    1,
			WorkMode:    3,
			WorkStatus:  1,
			AlarmLevel:  1,
			Electricity: 30,
			CreateTime:  b,
		}
		arrData := []bean.TracerReplayHeart{
			data,
		}
		if err := g.dbHandle.Table(tabName).Create(&arrData).Error; err != nil {
			logger.Errorf("write tracerS heart fail, e: %v", err)
		}
	}
}
func WriteDbDetectOnTracerS(bms, ems int64, g *genReplayTypeCond) {
	if g == nil {
		return
	}

	for b := bms; b < ems; b = b + GetIntervalTime(g) {
		tabName := common.BuildDetectTableName(g.sn, time.UnixMilli(b))
		utils.CheckAndCreateTab[bean.TracerReplayDetect](db.GetDB(), tabName, &bean.TracerReplayDetect{}, 0)

		data := make([]bean.TracerReplayDetect, 0, g.DetectNum)
		for i := 0; i < int(g.DetectNum); i++ {
			data = append(data, bean.TracerReplayDetect{
				Sn:           g.sn,
				Freq:         11,
				DangerLevels: 12,
				DroneName:    fmt.Sprintf("tracers_%v_%v", i, b),
				DroneHorizon: 1,

				QxPower:   11.123,
				DxPower:   11.234,
				DxHorizon: 11.456,

				HasUav:     bean.FreqDetectUavHas,
				OnceSeq:    b,
				CreateTime: b + int64(i),
			})
		}
		//time.Sleep(1 * time.Microsecond)

		if err := g.dbHandle.Table(tabName).Create(&data).Error; err != nil {
			logger.Errorf("write tracerS detect fail, e: %v", err)
		}
	}
}
func WriteDbSysConfigOnTracerS(bms, ems int64, g *genReplayTypeCond) {
	if g == nil {
		return
	}
	//
	for b := bms; b < ems; b = b + GetIntervalTime(g) {
		tabName := common.BuildSysCfgTabName(g.sn, time.UnixMilli(b))
		utils.CheckAndCreateTab[bean.TracerSReplaySysConfigData](db.GetDB(), tabName, &bean.TracerSReplaySysConfigData{}, 0)

		sysCfgEntities := make([]bean.TracerSReplaySysConfigData, 0, batchSize)
		sysCfgEntities = append(sysCfgEntities, bean.TracerSReplaySysConfigData{
			Sn:          g.sn,
			C2Longitude: 1.123,
			C2Latitude:  2.123,
			CreateTime:  b,
		})
		if err := g.dbHandle.Table(tabName).Create(&sysCfgEntities).Error; err != nil {
			logger.Errorf("write tracerS config fail, e: %v, data: %v", err)
		}
	}
}

// write 数据库， fpv
func WriteDbHeartOnFpv(bms, ems int64, g *genReplayTypeCond) {
	if g == nil {
		return
	}

	for b := bms; b < ems; b = b + GetIntervalTime(g) {
		tabName := common.BuildHeartTableName(g.sn, time.UnixMilli(b))
		utils.CheckAndCreateTab[bean.FpvReplayHeartData](db.GetDB(), tabName, &bean.FpvReplayHeartData{}, 0)

		data := bean.FpvReplayHeartData{
			Sn:            g.sn,
			IsOnline:      1,
			BatteryStatus: 10,
			Electricity:   10,
			WorkMode:      1,
			WorkStatus:    1,
			AlarmLevel:    1,
			CreateTime:    b,
		}
		arrData := []bean.FpvReplayHeartData{
			data,
		}
		if err := g.dbHandle.Table(tabName).Create(&arrData).Error; err != nil {
			logger.Errorf("write fpv heart fail, e: %v", err)
		}
	}
}
func WriteDbDetectOnFpv(bms, ems int64, g *genReplayTypeCond) {
	if g == nil {
		return
	}

	for b := bms; b < ems; b = b + GetIntervalTime(g) {
		tabName := common.BuildDetectTableName(g.sn, time.UnixMilli(b))
		utils.CheckAndCreateTab[bean.FpvReplayDetectData](db.GetDB(), tabName, &bean.FpvReplayDetectData{}, 0)

		data := make([]bean.FpvReplayDetectData, 0, g.DetectNum)
		for i := 0; i < int(g.DetectNum); i++ {
			data = append(data, bean.FpvReplayDetectData{
				Sn:            g.sn,
				UavNumber:     int32(i),
				DroneName:     fmt.Sprintf("autel_drone_%v_%v", i, b),
				UFreq:         123.123,
				UDangerLevels: 1,

				QxPower:      123.123,
				DxPower:      123.123,
				DxHorizon:    123.123,
				DroneHorizon: 123.123,

				CreateTime: b + int64(i),
			})
		}
		//time.Sleep(1 * time.Microsecond)

		if err := g.dbHandle.Table(tabName).Create(&data).Error; err != nil {
			logger.Errorf("write fpv detect fail, e: %v", err)
		}
	}
}
func WriteDbSysCfgOnFpv(bms, ems int64, g *genReplayTypeCond) {
	for b := bms; b < ems; b = b + GetIntervalTime(g) {
		tabName := common.BuildSysCfgTabName(g.sn, time.UnixMilli(b))
		utils.CheckAndCreateTab[bean.FpvReplaySysConfigData](db.GetDB(), tabName, &bean.FpvReplaySysConfigData{}, 0)

		sysCfgEntities := make([]bean.FpvReplaySysConfigData, 0, batchSize)
		sysCfgEntities = append(sysCfgEntities, bean.FpvReplaySysConfigData{
			Sn:            g.sn,
			Longitude:     1.1,
			Latitude:      1.1,
			Heading:       1,
			Arch:          1,
			TerminalId:    "terminal_1",
			EType:         "fpv",
			WarningRadius: 1,
			CounterRadius: 1,
			FenceRadius:   1,
			ScannerRadius: 1,
			Height:        1,
			C2Longitude:   1,
			C2Latitude:    1,
			CreateTime:    b,
		})
		if err := g.dbHandle.Table(tabName).Create(&sysCfgEntities).Error; err != nil {
			logger.Errorf("write fpv config fail, e: %v, data: %v", err)
		}
	}

}

// write 数据库， sfl
func WriteDbHeartOnSfl(bms, ems int64, g *genReplayTypeCond) {
	if g == nil {
		return
	}
	for b := bms; b < ems; b = b + GetIntervalTime(g) {
		tabName := common.BuildHeartTableName(g.sn, time.UnixMilli(b))
		utils.CheckAndCreateTab[bean.SFLReplayHeartData](db.GetDB(), tabName, &bean.SFLReplayHeartData{}, 0)

		data := bean.SFLReplayHeartData{
			Sn:            g.sn,
			WorkStatus:    1,
			IsOnline:      1,
			HitFreq:       1,
			DetectFreq:    1,
			Elevation:     12.12,
			GunDirection:  1.12,
			GunLongitude:  1.12,
			GunLatitude:   1.21,
			GunAltitude:   1.21,
			SatellitesNum: 1,
			FaultLevel:    1,
			CtrlFault:     1,
			AeagFault:     1,
			TracerFault:   1,
			CreateTime:    b,
		}
		arrData := []bean.SFLReplayHeartData{
			data,
		}
		if err := g.dbHandle.Table(tabName).Create(&arrData).Error; err != nil {
			logger.Errorf("write sfl heart fail, e: %v", err)
		}
	}
}
func WriteDbDetectOnSfl(bms, ems int64, g *genReplayTypeCond) {
	if g == nil {
		return
	}

	for b := bms; b < ems; b = b + GetIntervalTime(g) {
		tabName := common.BuildDetectTableName(g.sn, time.UnixMilli(b))
		utils.CheckAndCreateTab[bean.SFLReplayDetectData](db.GetDB(), tabName, &bean.SFLReplayDetectData{}, 0)

		data := make([]bean.SFLReplayDetectData, 0, g.DetectNum)
		for i := 0; i < int(g.DetectNum); i++ {
			data = append(data, bean.SFLReplayDetectData{
				Sn:                 g.sn,
				ProductType:        1,
				DroneName:          "autel_drone",
				SerialNum:          fmt.Sprintf("drone_%v_%v", i, b),
				DroneLongitude:     1,
				DroneLatitude:      1,
				DroneHeight:        1,
				DroneYawAngle:      1,
				DroneSpeed:         1,
				DroneVerticalSpeed: 1,
				SpeedDirection:     1,
				DroneSailLongitude: 1,
				DroneSailLatitude:  1,
				PilotLongitude:     1,
				PilotLatitude:      1,
				DroneHorizon:       1,
				DronePitch:         1,
				UFreq:              1,
				UDistance:          1,
				UDangerLevels:      1,
				Role:               1,
				OnceSeq:            b,

				CreateTime: b + int64(i),
			})
		}
		//time.Sleep(1 * time.Microsecond)

		if err := g.dbHandle.Table(tabName).Create(&data).Error; err != nil {
			logger.Errorf("write sfl detect fail, e: %v", err)
		}
	}
}
func WriteDbHitOnSfl(bms, ems int64, g *genReplayTypeCond) {
	if g == nil {
		return
	}
	for b := bms; b < ems; b = b + GetIntervalTime(g) {
		tabName := common.BuildHitStatusTableName(g.sn, time.UnixMilli(b))
		utils.CheckAndCreateTab[bean.SFLReplayHitStatusData](db.GetDB(), tabName, &bean.SFLReplayHitStatusData{}, 0)

		data := bean.SFLReplayHitStatusData{
			SN:                 g.sn,
			HitState:           1,
			ProductType:        1,
			DroneName:          "autel_drone",
			SerialNum:          fmt.Sprintf("drone_%v", b),
			DroneLongitude:     1,
			DroneLatitude:      1,
			DroneHeight:        1,
			DroneYawAngle:      1,
			DroneSpeed:         1,
			DroneVerticalSpeed: 1,
			SpeedDirection:     1,
			DroneSailLongitude: 1,
			DroneSailLatitude:  1,
			PilotLongitude:     1,
			PilotLatitude:      1,
			DroneHorizon:       1,
			DronePitch:         1,
			UFreq:              1,
			UDistance:          1,
			UDangerLevels:      1,
			Role:               1,
			CreateTime:         b,
		}
		arrData := []bean.SFLReplayHitStatusData{
			data,
		}
		if err := g.dbHandle.Table(tabName).Create(&arrData).Error; err != nil {
			logger.Errorf("write sfl hit status fail, e: %v", err)
		}
	}
}

// write 数据库， spoofer
func WriteDbHeartOnSpoofer(bms, ems int64, g *genReplayTypeCond) {
	if g == nil {
		return
	}
	for b := bms; b < ems; b = b + GetIntervalTime(g) {
		tabName := common.BuildHeartTableName(g.sn, time.UnixMilli(b))
		utils.CheckAndCreateTab[bean.SpooferReplayHeartData](db.GetDB(), tabName, &bean.SpooferReplayHeartData{}, 0)

		data := bean.SpooferReplayHeartData{
			Sn:          g.sn,
			IsOnline:    1,
			IsWorking:   1,
			GpsStatus:   1,
			Ephemeris:   1,
			TimeSync:    1,
			Longititude: 1,
			Latitude:    12.12,
			Height:      12.13,
			CreateTime:  b,
		}
		arrData := []bean.SpooferReplayHeartData{
			data,
		}
		if err := g.dbHandle.Table(tabName).Create(&arrData).Error; err != nil {
			logger.Errorf("write spoofer heart fail, e: %v", err)
		}
	}
}

// write 数据库， urd
func WriteDbHeartOnUrd(bms, ems int64, g *genReplayTypeCond) {
	if g == nil {
		return
	}
	for b := bms; b < ems; b = b + GetIntervalTime(g) {
		tabName := common.BuildHeartTableName(g.sn, time.UnixMilli(b))
		utils.CheckAndCreateTab[bean.SFLReplayHeartData](db.GetDB(), tabName, &bean.SFLReplayHeartData{}, 0)

		data := bean.SFLReplayHeartData{
			Sn:            g.sn,
			WorkStatus:    1,
			IsOnline:      1,
			HitFreq:       1,
			DetectFreq:    1,
			Elevation:     12.12,
			GunDirection:  1.12,
			GunLongitude:  1.12,
			GunLatitude:   1.21,
			GunAltitude:   1.21,
			SatellitesNum: 1,
			FaultLevel:    1,
			CtrlFault:     1,
			AeagFault:     1,
			TracerFault:   1,
			CreateTime:    b,
		}
		arrData := []bean.SFLReplayHeartData{
			data,
		}
		if err := g.dbHandle.Table(tabName).Create(&arrData).Error; err != nil {
			logger.Errorf("write sfl heart fail, e: %v", err)
		}
	}
}

type WriteItemToDbCB func(bMs, eMs int64, gen *genReplayTypeCond)
type genReplayTypeCond struct {
	devType           int32  // 雷达，tracerP/S
	replayData        string //心跳，监测，姿态 等。
	timeIntervalBegin int64  //ms
	timeIntervalEnd   int64
	factor            int32 //因子, 记录的时间分布
	sn                string
	writeDbItem       WriteItemToDbCB
	DetectNum         int32 //测试支持监测到无人机最大个数据，目前测试反馈在 ~30左右，可暂定在 35.
	dbHandle          *gorm.DB
}

type demoTimeScope struct {
	bTm int64 //ms
	eTm int64
}
type genReplayDataCond struct {
	demoTimeDays []demoTimeScope // 2023-12-12 格式;
	demoDataType []*genReplayTypeCond
}

func (g *genReplayDataCond) genData() {
	if g == nil {
		return
	}
	var wg sync.WaitGroup

	for i, _ := range g.demoTimeDays {
		demoDay := g.demoTimeDays[i]
		if demoDay.bTm <= 0 || demoDay.eTm <= 0 || demoDay.eTm < demoDay.bTm {
			logger.Errorf("day time is invalid")
			return
		}

		for ii, _ := range g.demoDataType {
			wg.Add(1)
			replayType := g.demoDataType[ii]
			if replayType == nil {
				wg.Done()
				continue
			}
			//
			if replayType.writeDbItem == nil {
				wg.Done()
				continue
			}
			go func() {
				defer wg.Done()
				replayType.writeDbItem(demoDay.bTm, demoDay.eTm, replayType)
			}()
		}
	}
	wg.Wait()
}

func NewGenReplayDataCond() *genReplayDataCond {
	r := &genReplayDataCond{}
	maxDetectNums := int32(35)
	_ = maxDetectNums

	//r.demoTimeDays = append(r.demoTimeDays, demoTimeScope{
	//	bTm: 1703779200000, //2023-12-29 00:00:00 可自定义
	//	eTm: 1703865599000, //1703865599000, //1703865599000, //1703779260000
	//})
	//
	//r.demoTimeDays = append(r.demoTimeDays, demoTimeScope{
	//	bTm: 1703865600000, //2023-12-30 00:00:00
	//	eTm: 1703951999000,
	//})

	//雷达数据
	testSn := "radar_09876"
	r.demoDataType = append(r.demoDataType, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_RadarDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeHEART],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		dbHandle:          db.GetDB(),
		writeDbItem:       WriteDbHeartOnRadar,
	}, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_RadarDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeDetect],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		DetectNum:         maxDetectNums,
		dbHandle:          db.GetDB(),
		writeDbItem:       WriteDbDetectOnRadar,
	}, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_RadarDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypePosture],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		dbHandle:          db.GetDB(),
		writeDbItem:       WriteDbPostureOnRadar,
	})
	//
	//tracerP
	testSn = "tracerP_09876"
	r.demoDataType = append(r.demoDataType, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_TracerPDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeDetect],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		DetectNum:         maxDetectNums,
		dbHandle:          db.GetDB(),
		writeDbItem:       WriteDbDetectOnTracerP,
	})

	//tracerS
	testSn = "tracerS_09876"
	r.demoDataType = append(r.demoDataType, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_TracerSDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeHEART],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		dbHandle:          db.GetDB(),
		writeDbItem:       WriteDbHeartOnTracerS,
	}, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_TracerSDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeDetect],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		DetectNum:         maxDetectNums,
		dbHandle:          db.GetDB(),
		writeDbItem:       WriteDbDetectOnTracerS,
	}, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_TracerSDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeC2SysConfig],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		dbHandle:          db.GetDB(),
		writeDbItem:       WriteDbSysConfigOnTracerS,
	})

	//
	testSn = "fpv_09876"
	r.demoDataType = append(r.demoDataType, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_FpvDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeHEART],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		dbHandle:          db.GetDB(),
		writeDbItem:       WriteDbHeartOnFpv,
	}, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_FpvDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeDetect],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		DetectNum:         maxDetectNums,
		dbHandle:          db.GetDB(),
		writeDbItem:       WriteDbDetectOnFpv,
	}, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_FpvDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeC2SysConfig],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		dbHandle:          db.GetDB(),
		writeDbItem:       WriteDbSysCfgOnFpv,
	})

	//
	testSn = "sfl_09876"
	r.demoDataType = append(r.demoDataType, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_SFLDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeHEART],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		dbHandle:          db.GetDB(),
		writeDbItem:       WriteDbHeartOnSfl,
	}, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_SFLDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeDetect],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		DetectNum:         maxDetectNums,
		dbHandle:          db.GetDB(),
		writeDbItem:       WriteDbDetectOnSfl,
	}, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_SFLDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeHit],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		dbHandle:          db.GetDB(),
		writeDbItem:       WriteDbHitOnSfl,
	})

	testSn = "spoofer_09876"
	r.demoDataType = append(r.demoDataType, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_SpooferDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeHEART],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		dbHandle:          db.GetDB(),
		writeDbItem:       WriteDbHeartOnSpoofer,
	})

	////
	testSn = "urd_09876"
	r.demoDataType = append(r.demoDataType, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_UrdDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeHEART],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		dbHandle:          db.GetDB(),
		writeDbItem:       nil, //TODO:
	}, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_UrdDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeDetect],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		DetectNum:         maxDetectNums,
		dbHandle:          db.GetDB(),
		writeDbItem:       nil, //TODO:
	}, &genReplayTypeCond{
		devType:           int32(client.EnumDevTypeList_UrdDevTypeEnum),
		replayData:        ReplayDataTypes[ReplayTypeSpectrum],
		timeIntervalBegin: 100,
		timeIntervalEnd:   110,
		factor:            90,
		sn:                testSn,
		dbHandle:          db.GetDB(),
		writeDbItem:       nil, //TODO:
	})

	return r
}
func TestGenReplayData(t *testing.T) {
	g := NewGenReplayDataCond()
	g.genData()
}

type ToTestDevList struct {
	sn        string
	devType   int32
	devTypStr string
}

func TestUpdateEquipList(t *testing.T) {
	//v := []ToTestDevList{
	//	{sn: "radar_09876", devType: int32(client.EnumDevTypeList_RadarDevTypeEnum), devTypStr: helper.DevTypeDescRadar},
	//	{sn: "tracerP_09876", devType: int32(client.EnumDevTypeList_TracerPDevTypeEnum), devTypStr: helper.DevTypeDescTraceP},
	//	{sn: "tracerS_09876", devType: int32(client.EnumDevTypeList_TracerSDevTypeEnum), devTypStr: helper.DevTypeDescTracerS},
	//	{sn: "fpv_09876", devType: int32(client.EnumDevTypeList_FpvDevTypeEnum), devTypStr: helper.DevTypeDescFpv},
	//	{sn: "sfl_09876", devType: int32(client.EnumDevTypeList_SFLDevTypeEnum), devTypStr: helper.DevTypeDescSfl},
	//	{sn: "spoofer_09876", devType: int32(client.EnumDevTypeList_SpooferDevTypeEnum), devTypStr: helper.DevTypeDescSpoofer},
	//	{sn: "urd_09876", devType: int32(client.EnumDevTypeList_UrdDevTypeEnum), devTypStr: helper.DevTypeDescTracerRF},
	//}

	//
	//for _, item := range v {
	//	dbItem := bean.EquipList{
	//		Sn:      item.sn,
	//		Etype:   item.devTypStr,
	//		CrtTime: utils.ParseTimeToString(time.Now()),
	//	}
	//	if err := db.GetDB().Create(&dbItem).Error; err != nil {
	//		logger.Errorf("create db fail, e: %v", err)
	//		continue
	//	}
	//}
}
