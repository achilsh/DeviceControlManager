package handler

import (
	"context"
	"errors"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
)

type RadarTcpDataCache struct{}

func NewRadarTcpDataCache() *RadarTcpDataCache {
	return &RadarTcpDataCache{}
}

func (p *RadarTcpDataCache) TrackTargetList(ctx context.Context, offset, limit int) ([]*bean.RadarTcpTrackTarget, []int, error) {
	var list []*bean.RadarTcpTrackTarget
	err := db.GetDB().Raw("select tt.* from radar_tcp_track_target tt join (select * from radar_tcp_track_info order by id limit ?, ?) ti "+
		"on tt.header_uid = ti.uid order by tt.id", offset, limit).Scan(&list).Error
	if err != nil {
		return nil, nil, errors.New("query TrackTargetList failed")
	}
	var counts []int
	err = db.GetDB().Raw("select count(*) as counts from radar_tcp_track_target tt join (select * from radar_tcp_track_info order by id limit ?, ?) ti "+
		"on tt.header_uid = ti.uid group by tt.header_uid order by tt.id", offset, limit).Scan(&counts).Error
	if err != nil {
		return nil, nil, errors.New("query TrackTargetList counts failed")
	}
	return list, counts, nil
}

func (p *RadarTcpDataCache) PostureList(ctx context.Context, offset, limit int) ([]*bean.RadarTcpPostureInfo, error) {
	var list []*bean.RadarTcpPostureInfo
	err := db.GetDB().Model(&bean.RadarTcpPostureInfo{}).Offset(offset).Limit(limit).Find(&list).Error
	if err != nil {
		return nil, errors.New("query PostureList failed")
	}
	return list, nil
}

func (p *RadarTcpDataCache) HeartList(ctx context.Context, offset, limit int) ([]*bean.RadarTcpHeart, error) {
	var list []*bean.RadarTcpHeart
	err := db.GetDB().Model(&bean.RadarTcpHeart{}).Offset(offset).Limit(limit).Find(&list).Error
	if err != nil {
		return nil, errors.New("query HeartList failed")
	}
	return list, nil
}
