// Package api 用户管理

package test

import (
	"fmt"
	"testing"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/stretchr/testify/assert"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

var mockErrorf = func(template string, args ...interface{}) {
	fmt.Printf(template, args...)
	return
}
var mockError = func(v ...interface{}) {
	fmt.Println(v)
	return
}
var mockErrorw = func(msg string, keysAndValues ...interface{}) {
	fmt.Print(msg)
	fmt.Println(keysAndValues...)
	return
}

func LoggerMock() {
	logger.Infof, logger.Debugf, logger.Errorf, logger.Warnf, logger.Panicf, logger.Fatalf = mockErrorf, mockErrorf, mockErrorf, mockErrorf, mockErrorf, mockErrorf
	logger.Info, logger.Debug, logger.Error, logger.Warn, logger.Panic, logger.Fatal = mockError, mockError, mockError, mockError, mockError, mockError
	logger.Infow, logger.Debugw = mockErrorw, mockErrorw
}

func GetMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	// Mock数据库
	db, mock, err := sqlmock.New()
	assert.NoError(t, err)

	// 使用模拟的SQL连接创建Gorm的DB对象
	DB, err := gorm.Open(mysql.New(mysql.Config{
		SkipInitializeWithVersion: true,
		Conn:                      db,
	}), &gorm.Config{})
	assert.NoError(t, err)
	assert.NotNil(t, DB)
	return DB, mock
}

func MockConfig() {
	//Mock配置
	config.Global = &config.GlobalConfig{
		Jwt: &config.Jwt{
			Ttl: 10,
		},
	}
}
