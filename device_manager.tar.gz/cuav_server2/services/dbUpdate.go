package services

import (
	"fmt"
	"os"
	"strings"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"gopkg.in/yaml.v3"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

type Config struct {
	DBVersion struct {
		Version string `yaml:"version"`
	} `yaml:"dbVersion"`
}

// 新增C2_ID表的 SQL 语句
const alterTableSQL_C2_ID = `
CREATE TABLE "c2_id"
(
    "id"     integer PRIMARY KEY NOT NULL,
    "c2_id" text                NOT NULL,
    CONSTRAINT "c2_id_unique" UNIQUE ("c2_id")
);
`

// 新增system_config表中C2经纬度 字段的sql语句
const alterColumnSQL_C2Long = `
ALTER TABLE system_config ADD COLUMN c2_longitude real DEFAULT 0.0;
ALTER TABLE system_config ADD COLUMN c2_latitude real DEFAULT 0.0;
`

// 新增equip_list表中radar_relevance 字段的sql语句
const alterColumnSQL_radar_relevance = `
ALTER TABLE equip_list ADD COLUMN radar_relevance int DEFAULT 0;
`
const InsertSql_Userbase = `
INSERT INTO "main"."user_base" ("role", "name", "nick_name", "gender", "mobile", "email", "crt_time", "push_token", "password", "update_time", "updater", "is_delete", "last_sms_time", "daily_send_times") 
VALUES ('1', 'admin', 'Administrator', 'f', '', '', '2022-10-19 20:39:33.1471407', 'fsdf8787dfs', '21232f297a57a5a743894a0e4a801fc3', '2022-11-18 15:56:29.6270324', NULL, 0, NULL, NULL);`

const Update_userBase = `
UPDATE "main"."user_base" SET  "role"='1', "nick_name"='xiaoming', "gender"='f', "mobile"='', "email"='995570953@qq.com', "crt_time"='2022-10-19 20:39:33.1471407', "push_token"='fsdf8787dfs', "password"='fae0b27c451c728867a567e8c1bb4e53', "update_time"='2022-11-18 15:56:29.6270324', "updater"=1, "is_delete"=0, "last_sms_time"=NULL, "daily_send_times"=NULL WHERE ("name"='demo');

UPDATE "main"."user_base" SET  "role"='1', "nick_name"='Administrator', "gender"='f', "mobile"='', "email"='', "crt_time"='2022-10-19 20:39:33.1471407', "push_token"='fsdf8787dfs', "password"='21232f297a57a5a743894a0e4a801fc3', "update_time"='2022-11-18 15:56:29.6270324', "updater"=0, "is_delete"=0, "last_sms_time"=NULL, "daily_send_times"=NULL WHERE ("name"='admin');
`
const SflDetectInfo_Insert = `
CREATE TABLE "sfl_detect_info"
(
    "id"             integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "sn"             text                              not null,
    "vendor"         text,
    "detect_time"    integer,
    "hit_time"       integer,
    "counter_time"   integer,
    "freq"           integer,
    "direction"      integer,
    "pilot_long_lat" text,
    CONSTRAINT "sfl_detect_info_unique" UNIQUE ("id")
);
`

// 新增导航诱导配置表
const CreateTableNsf4000_Config = `
CREATE TABLE "nsf4000_config"
(
    "id"                     integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "sn"                     text NOT NULL,
    "radius"                 integer,
    "power"                  integer,
    "defense_level_speed"    integer,
    "defense_vertical_speed" integer,
    "longitude"              real,
    "latitude"               real,
    "height"                 integer,
    "drive_level_speed"      integer,
    "drive_vertical_speed"   integer,
    CONSTRAINT "nsf4000_config_unique" UNIQUE ("sn")
);
`

// AlterColumnSQL_Nsf4000_Config 新增导航诱导配置表中主动防御和区域拒止 经纬度 字段的sql语句
const AlterColumnSQL_Nsf4000_Config = `
ALTER TABLE nsf4000_config ADD COLUMN defense_longitude real DEFAULT 0.0;
ALTER TABLE nsf4000_config ADD COLUMN defense_latitude real DEFAULT 0.0;
ALTER TABLE nsf4000_config ADD COLUMN area_stop_longitude real DEFAULT 0.0;
ALTER TABLE nsf4000_config ADD COLUMN area_stop_latitude real DEFAULT 0.0;
`

// CreateTableStatistic 新增数据分析表
const CreateTableStatistic = `
CREATE TABLE "flight_list"
(
    "id"            integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "drone_name"        text,
    "vendor"        text,
    "freq"          real,
    "dev_type"      integer,
    "serial_num"    text,
    "begin_time"    real,
    "end_time"      real,
    "duration_time" real,
    "height"        real,
    "protocol"      text,
    "drone_yaw_angle" real,
    CONSTRAINT "flight_list" UNIQUE ("id")
);
CREATE TABLE "record_list"
(
    "id"                integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "dev_type"          integer,
    "detect_table_name" text NOT NULL UNIQUE,
    CONSTRAINT "record_list" UNIQUE ("id")
);
CREATE TABLE "statistic_list"
(
    "id"             integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "fly_count"      integer,
    "last_time"      integer,

    CONSTRAINT "statistic_list" UNIQUE ("id")
);
INSERT INTO statistic_list (id, fly_count, last_time)
VALUES (1, 0, 0);
`

// 新增equip_list表中dev_version 字段的sql语句
const alterColumnSQL_dev_version = `
ALTER TABLE equip_list ADD COLUMN dev_version int DEFAULT "";
`

// CreateOrientDroneList 新增定向探测无人机列表
const CreateOrientDroneList = `
CREATE TABLE "tracers_orientation_detect_drone"
(
    "id"                integer NOT NULL,
    "sn"                text, -- 检测设备tracerS sn
    "drone_number"      integer, --  无人机编号
    "drone_name"        text,  -- 无人机名称
    "freq"              integer, -- mhz
    "azimuth"           integer, -- 方位角
    "create_time"       integer, -- 创建时间
    "update_time"       integer,
    "status"            integer, -- 1: 开始定向且未定向到无人机， 2: 已经定向无人机
    CONSTRAINT "radar_adc_pkey" PRIMARY KEY ("id")
);
CREATE INDEX orientation_detect_drone_index ON tracers_orientation_detect_drone(drone_number, drone_name, freq);
`

const alterColumnOnDroneWhiteListSQL = `
	ALTER TABLE drone_white_list  ADD COLUMN user_name text;
	ALTER TABLE drone_white_list  ADD COLUMN usage integer;
	ALTER TABLE drone_white_list  ADD COLUMN usage_desc text;
	ALTER TABLE drone_white_list  ADD COLUMN remarks text;
`

// 新增字段的sql语句
const alterColumnSQL = `
ALTER TABLE c2_id ADD COLUMN test TEXT;
`

// 新增sfl detect table 语句：
const alterSflDetectFieldSql = `
ALTER TABLE sfl_detect_info ADD COLUMN drone_height REAL;
`

func UpdateDb(currentVer, dbfile, cuavConfigFile string) {
	lastVer := "1.0.0.13"
	result := compareVersions(currentVer, lastVer) //当前版本低于1.0.0.10版本 需要更新数据库
	if result < 0 {
		logV := fmt.Sprintf("lastVer=%s is greater than  currentVer=%s\n", lastVer, currentVer)
		logger.Info(logV)
		//升级数据库
		startUpdate(dbfile, cuavConfigFile, lastVer)
	}
}

func startUpdate(dbfile, cuavConfigFile, lastVer string) {
	db, err := gorm.Open(sqlite.Open(dbfile), &gorm.Config{})
	if err != nil {
		logger.Errorf("Open sqlite error:%v", err)
		return
	}

	//1.0.0.2    新增表
	//新增c2_id表
	executeSQL(db, alterTableSQL_C2_ID)

	//1.0.0.3   新增C2经纬度字段
	executeSQL(db, alterColumnSQL_C2Long)

	//1.0.0.4  新增User表中admin用户
	executeSQL(db, InsertSql_Userbase)

	//1.0.0.5   新增SFL设备侦测表
	executeSQL(db, SflDetectInfo_Insert)

	//1.0.0.6  新增NSF4000_config表
	executeSQL(db, CreateTableNsf4000_Config)

	//1.0.0.7  新增equip_list表
	executeSQL(db, alterColumnSQL_radar_relevance)

	//1.0.0.8  新增数据分析表
	executeSQL(db, CreateTableStatistic)

	//1.0.0.9 新增导航诱导主动防御、区域拒止经纬度字段
	executeSQL(db, AlterColumnSQL_Nsf4000_Config)

	//1.0.0.10 新增equip_list表中版本号字段
	executeSQL(db, alterColumnSQL_dev_version)
	//1.0.0.11  定向历史表 修改sfldetect表结构
	executeSQL(db, CreateOrientDroneList)
	executeSQL(db, alterSflDetectFieldSql)

	//1.0.0.12
	executeSQL(db, Update_userBase)
	//1.0.0.13
	executeSQL(db, alterColumnOnDroneWhiteListSQL)
	//test
	//新增c2_id表中test字段
	//executeSQL(db, alterColumnSQL)

	//更新yaml文件
	UpdateConfigYaml(cuavConfigFile, lastVer)
}

func executeSQL(db *gorm.DB, sqlStatement string) {
	err := db.Exec(sqlStatement).Error
	if err != nil {
		logger.Errorf("op tab fail, e: %v, sql: [ %v ]", err, sqlStatement)
	}
	return
}

func UpdateConfigYaml(cuavConfigFile, lastVer string) {

	yamlFile, err := os.ReadFile(cuavConfigFile)
	if err != nil {
		logger.Error("Read File err:", err)
		return
	}
	// 将YAML内容解析到一个 map 中
	yamlMap := make(map[string]interface{})
	err = yaml.Unmarshal(yamlFile, &yamlMap)
	if err != nil {
		panic(err)
	}

	// 更新version字段
	yamlMap["dbVersion"].(map[string]interface{})["version"] = lastVer

	// 将更新后的 map 转换为 YAML 字符串
	updatedYamlBytes, err := yaml.Marshal(&yamlMap)
	if err != nil {
		panic(err)
	}
	updatedYamlStr := string(updatedYamlBytes)

	// 写入更新后的 YAML 字符串到文件
	err = os.WriteFile(cuavConfigFile, []byte(updatedYamlStr), 0644)
	if err != nil {
		panic(err)
	}

	logger.Info("Successfully updated yaml:", cuavConfigFile)
}

func compareVersions(v1, v2 string) int {
	ver1 := strings.Split(v1, ".")
	ver2 := strings.Split(v2, ".")

	for i := 0; i < len(ver1) && i < len(ver2); i++ {
		n1 := convertToInt(ver1[i])
		n2 := convertToInt(ver2[i])

		if n1 > n2 {
			return 1
		} else if n1 < n2 {
			return -1
		}
	}

	if len(ver1) > len(ver2) {
		return 1
	} else if len(ver1) < len(ver2) {
		return -1
	}

	return 0
}

func convertToInt(s string) int {
	var num int
	fmt.Sscanf(s, "%d", &num)
	return num
}
