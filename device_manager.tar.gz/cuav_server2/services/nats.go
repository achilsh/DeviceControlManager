package services

import (
	"context"
	"flag"
	"fmt"
	"net/http"
	"os"

	"github.com/nats-io/nats-server/v2/server"
	"go.uber.org/automaxprocs/maxprocs"
)

func StartNats(ctx context.Context, configFile string, dataDir string, stopChan chan int) {
	natsSever(ctx, []string{"-c", configFile, "-sd", dataDir})
	stopChan <- 1
}

func natsSever(ctx context.Context, args []string) {
	exe := "nats-server"

	// Create a FlagSet and sets the usage
	fs := flag.NewFlagSet(exe, flag.ExitOnError)
	fs.Usage = usage

	// Configure the options from the flags/config file
	opts, err := server.ConfigureOptions(fs, args,
		server.PrintServerAndExit,
		fs.Usage,
		server.PrintTLSHelpAndDie)
	if err != nil {
		server.PrintAndDie(fmt.Sprintf("%s: %s", exe, err))
	} else if opts.CheckConfig {
		fmt.Fprintf(os.Stderr, "%s: configuration file %s is valid\n", exe, opts.ConfigFile)
		os.Exit(0)
	}

	// Create the server with appropriate options.
	s, err := server.NewServer(opts)
	if err != nil {
		server.PrintAndDie(fmt.Sprintf("%s: %s", exe, err))
	}

	// Configure the logger based on the flags
	s.ConfigureLogger()

	// Start things up. Block here until done.
	if err := server.Run(s); err != nil {
		server.PrintAndDie(err.Error())
	}

	// Adjust MAXPROCS if running under linux/cgroups quotas.
	undo, err := maxprocs.Set(maxprocs.Logger(s.Debugf))
	if err != nil {
		s.Warnf("Failed to set GOMAXPROCS: %v", err)
	} else {
		defer undo()
	}

	go func() {
		select {
		case <-ctx.Done():
			s.Shutdown()
		}
	}()

	s.WaitForShutdown()
}

// usage will print out the flag options for the server.
func usage() {
	os.Exit(0)
}

func CheckNatsStatus() bool {
	req, _ := http.NewRequest("GET", "http://127.0.0.1:8222/healthz", nil)
	resp, err := http.DefaultClient.Do(req)
	if resp != nil {
		defer resp.Body.Close()
	}
	if err != nil {
		return false
	}
	if resp.StatusCode == 200 {
		fmt.Println("nats启动成功")
		return true
	}
	return false
}
