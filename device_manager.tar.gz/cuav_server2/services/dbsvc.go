package services

import (
	"context"
	"fmt"
	"os"
	"sync"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_plugin/registry/memory"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"github.com/go-micro/plugins/v4/server/grpc"
	"go-micro.dev/v4"
)

func StartDbSvc(ctx context.Context, wg *sync.WaitGroup, stopChan chan int, dbFile string) {
	dbSvcServer(ctx, wg, dbFile)
	stopChan <- 1
}

func dbSvcServer(ctx context.Context, wg *sync.WaitGroup, dbFile string) {
	// 初始化Broker
	mq.InitMemoryBroker()
	// 初始化数据库
	conn, err := db.InitSqlite(dbFile)
	if err != nil {
		logger.Fatalf("InitSqlite err %v", err)
		return
	}
	defer conn.Close()
	// 订阅消息
	handler.Consume()

	// 启动服务
	srv := micro.NewService(
		micro.Server(grpc.NewServer(WithId("1"))),
		micro.Name(config.GetGlobalConfig().MicroSvc.DbSvc),
		micro.Version(config.GetGlobalConfig().MicroSvc.Version),
		micro.Registry(memory.NewRegistry()),
		micro.Address("127.0.0.1:0"),
		micro.AfterStart(func() error {
			wg.Done()
			return nil
		}),
		micro.AfterStop(func() error {
			logger.Info("dbSvc退出")
			return nil
		}),
		micro.Context(ctx),
	)
	srv.Init()
	handler.InitHandler(srv)
	if err := srv.Run(); err != nil {
		fmt.Fprintf(os.Stderr, "Error run dbSvc: %v\n", err)
	}
}
