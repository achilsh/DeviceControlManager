package utils

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/bwmarrin/snowflake"
	"strconv"
)

var (
	SnowFlakeNode *snowflake.Node
)

// InitSnowFlakeNode 初始化雪花算法节点, NodeId范围: 0-1023
func InitSnowFlakeNode(NodeId int64) {
	var err error
	SnowFlakeNode, err = snowflake.NewNode(NodeId)
	if err != nil {
		logger.Fatal("初始化雪花算法节点失败：", err)
	}
}

func GetEventId(id int64) string {
	s := strconv.FormatInt(SnowFlakeNode.Generate().Int64(), 10) + "@" + strconv.FormatInt(int64(id), 10)
	return s
}
