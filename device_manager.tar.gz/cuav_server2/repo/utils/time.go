package utils

import (
	"time"
)

func ParseTimeToString(t time.Time) string {
	layout := "2006-01-02 15:04:05.0000000"
	return t.Format(layout)
}

func ParseTime(t time.Time, layout string) string {
	return t.Format(layout)
}

func StringToTime(str string) time.Time {
	strTime, _ := time.ParseInLocation("2006-01-02 15:04:05", str, time.Local)
	return strTime
}
