package mq

import (
	"adasgitlab.autel.com/tools/cuav_plugin/broker/memory"
	"go-micro.dev/v4/broker"
)

const (
	DeviceCommEventTopic   = "device_comm_event"
	EquipmentStatusTopic   = "equip_status"
	EquipMessageBoxTopic   = "equip_messagebox"
	RadarTrackTopic        = "radar_track"
	RadarPostureTopic      = "radar_posture"
	RadarBeamConfigTopic   = "radar_beam_config" //@fzw 没有用到的topic
	GunHeartTopic          = "gun_heart"
	GunDroneIdTopic        = "gun_drone_id"
	V2DroneIdTopic         = "v2_drone_id" //traceP,traceS @fzw 增加注释
	RFURD360Topic          = "rf_urd360"   //@fzw 没有用到的topic
	NSF4000Topic           = "NSF4000"
	NSF4000TopicLLH        = "NSF4000_LLH"
	TracerDetectTopic      = "tracer_detect"
	RFURD360StatusTopic    = "rf_urd360_status"
	RFURD360DroneInfoTopic = "rf_urd360_drone_info"
	RFURD360SpecturmTopic  = "rf_urd360_specturm"
	FpvTopic               = "fpv_msg"
	SflTopic               = "sfl_msg"
	AgxTopic               = "agx_msg"
	DataReplayMarkTopic    = "data_replay_mark"
	FpvSysConfig           = "fpv_sys_config"
	ReplayTransMsgTopic    = "replay_data_trans"
	SystemHeartTopic       = "system_heart"
	FpvStopCmdTopic        = "fpv_video_stop_cmd"
	EventReportTopic       = "event_report_cmd"
)

var (
	EquipmentStatusBroker broker.Broker
	EquipMessageBoxBroker broker.Broker
	DeviceCommEventBroker broker.Broker
	RadarTrackBroker      broker.Broker
	RadarPostureBroker    broker.Broker
	RadarBeamConfigBroker broker.Broker
	GunHeartBroker        broker.Broker
	GunDroneIdBroker      broker.Broker
	V2DroneIdBroker       broker.Broker
	RFURDBroker           broker.Broker
	NSF4000Broker         broker.Broker
	NSF4000BrokerLLH      broker.Broker
	TracerDetectBroker    broker.Broker
	FpvMsgBroker          broker.Broker
	SflMsgBroker          broker.Broker
	AgxMsgBroker          broker.Broker
	DataReplayMark        broker.Broker
	DataReplayMix         broker.Broker
	SystemHeartBroker     broker.Broker
	FpvVideoStopCmdBroker broker.Broker
	EventReportBroker     broker.Broker
)

func InitMemoryBroker() {
	EquipmentStatusBroker = memory.NewBroker()
	EquipMessageBoxBroker = memory.NewBroker()
	DeviceCommEventBroker = memory.NewBroker()
	RadarTrackBroker = memory.NewBroker()
	RadarPostureBroker = memory.NewBroker()
	RadarBeamConfigBroker = memory.NewBroker()
	GunHeartBroker = memory.NewBroker()
	GunDroneIdBroker = memory.NewBroker()
	V2DroneIdBroker = memory.NewBroker()
	RFURDBroker = memory.NewBroker()
	NSF4000Broker = memory.NewBroker()
	NSF4000BrokerLLH = memory.NewBroker()
	TracerDetectBroker = memory.NewBroker()
	FpvMsgBroker = memory.NewBroker()
	SflMsgBroker = memory.NewBroker()
	AgxMsgBroker = memory.NewBroker()
	DataReplayMark = memory.NewBroker()
	DataReplayMix = memory.NewBroker()
	SystemHeartBroker = memory.NewBroker()
	FpvVideoStopCmdBroker = memory.NewBroker()
	EventReportBroker = memory.NewBroker()
}
