package websocketsvr

import (
	"fmt"
	"net/http"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/gin-gonic/gin"
)

// WebSocketSvr ...
type WebSocketSvr struct {
	ip      string
	port    int
	handles map[string]gin.HandlerFunc
}

// Opt ...
type Opt func(w *WebSocketSvr)

// WithIP 设置IP
func WithIP(ip string) Opt {
	return func(w *WebSocketSvr) {
		w.ip = ip
	}
}

// WithPort 设置端口
func WithPort(port int) Opt {
	return func(w *WebSocketSvr) {
		w.port = port
	}
}

// WithWebHook 设置回调
func WithWebHook(hooks map[string]gin.HandlerFunc) Opt {
	return func(w *WebSocketSvr) {
		w.handles = hooks
	}
}

// New 构造websocket服务
func New(opts ...Opt) *WebSocketSvr {
	svr := &WebSocketSvr{}
	for _, opt := range opts {
		opt(svr)
	}
	return svr
}

// Start 启动webscoket
func (w *WebSocketSvr) Start() error {
	r := gin.Default()
	_ = r.SetTrustedProxies(nil)
	for k, v := range w.handles {
		r.GET(k, v)
	}
	server := &http.Server{
		Addr:    fmt.Sprintf("%s:%d", w.ip, w.port),
		Handler: r,
	}
	if err := server.ListenAndServe(); err != nil {
		logger.Errorf("http ListenAndServe err %v", err)
		return err
	}
	return nil
}
