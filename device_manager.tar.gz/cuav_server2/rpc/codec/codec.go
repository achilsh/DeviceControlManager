package codec

import (
	"errors"
	"reflect"
	"sync"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	entity "adasgitlab.autel.com/tools/cuav_server/entity/common"
)

// Codec 编解码器
type Codec struct {
	mu       sync.Mutex
	cmdCoder map[entity.DeviceType]map[uint16]interface{}
}

var (
	codecInstance *Codec
	codecOnce     sync.Once
)

// Instance 单例
func Instance() *Codec {
	codecOnce.Do(func() {
		codecInstance = &Codec{
			cmdCoder: make(map[entity.DeviceType]map[uint16]interface{}),
		}
	})
	return codecInstance
}

// Register 注册命令字请求响应编解码
func (c *Codec) Register(deviceType entity.DeviceType, cmd uint16, rsp interface{}) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.cmdCoder[deviceType] == nil {
		c.cmdCoder[deviceType] = make(map[uint16]interface{})
	}
	c.cmdCoder[deviceType][cmd] = rsp
}

// Get 获取设备下命令字请求响应编解码
func (c *Codec) Get(deviceType entity.DeviceType, cmd uint16) (interface{}, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if _, ok := c.cmdCoder[deviceType]; !ok {
		logger.Errorf("deviceType %d not register codec", deviceType)
		return nil, errors.New("deviceType not register codec")
	}
	v, ok := c.cmdCoder[deviceType][cmd]
	if !ok {
		logger.Errorf("deviceType %d cmd %d not register codec", deviceType, cmd)
		return nil, errors.New("cmd not register codec")
	}
	rspCoder := reflect.TypeOf(v).Elem()
	if rspCoder.Kind() != reflect.Struct {
		logger.Errorf("deviceType %d cmd %d reflect rspCoder TypeOf not struct", deviceType, cmd)
		rspCoder = nil
	}
	return reflect.New(rspCoder).Interface().(interface{}), nil
}
