package codec

import (
	"errors"

	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
)

func init() {
	RegisterSerializer(SerializationTypeSlink, &SlinkV1Serialization{})
}

// SlinkV1Serialization SlinkV1解析器
type SlinkV1Serialization struct{}

// Marshal 编码
func (s *SlinkV1Serialization) Marshal(body interface{}) ([]byte, error) {
	msg, ok := body.(slinkv1.Msg)
	if !ok {
		return nil, errors.New("marshal fail: body not  slinkv1  message")
	}
	return msg.Encode()
}

// Unmarshal 解码
func (s *SlinkV1Serialization) Unmarshal(data []byte, v interface{}) error {
	msg, ok := v.(slinkv1.Msg)
	if !ok {
		return errors.New("unmarshal fail: body not  slinkv1  message")
	}
	return msg.Decode(data)
}
