package task

import (
	"time"

	uuid "github.com/satori/go.uuid"
)

type Task struct {
	id      string        //任务ID
	timeout time.Duration //超时时间
	ch      chan int      //任务完成状态
	result  interface{}   //任务响应
	err     error         // 返回结果
}

type TaskOpt func(t *Task)

// WithID 设置taskID
func WithID(id string) TaskOpt {
	return func(t *Task) {
		t.id = id
	}
}

// WithTimeout 设置超时时间
func WithTimeout(timeout time.Duration) TaskOpt {
	return func(t *Task) {
		t.timeout = timeout
	}
}

// WithResult 设置结果
func WithResult(result interface{}) TaskOpt {
	return func(t *Task) {
		t.result = result
	}
}

// WithErr 设置错误信息
func WithErr(err error) TaskOpt {
	return func(t *Task) {
		t.err = err
	}
}

// NewTask 构造Task
func NewTask(opts ...TaskOpt) *Task {
	task := &Task{
		id:      uuid.NewV4().String(),
		timeout: time.Millisecond * 15000,
		ch:      make(chan int),
		err:     nil,
	}
	for _, o := range opts {
		o(task)
	}
	return task
}

// SetResult 设置任务结果
func (t *Task) SetResult(result interface{}, err error) {
	t.result = result
	t.err = err
}
