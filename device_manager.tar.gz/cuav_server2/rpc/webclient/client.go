package webclient

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/gorilla/websocket"
	uuid "github.com/satori/go.uuid"
	"go.uber.org/ratelimit"
)

var maxNumPerSecond = 1000 //每秒x次，限速
// Client websocket接入终端
type Client struct {
	id          string //连接唯一id
	data        chan []byte
	conn        *websocket.Conn
	ratelimiter ratelimit.Limiter //限速器
	msgType     int               //发送数据类型
}

// ClientOpt ...
type ClientOpt func(c *Client)

// WithConn 设置连接
func WithConn(conn *websocket.Conn) ClientOpt {
	return func(c *Client) {
		c.conn = conn
	}
}

// WithClientID 设置接入端唯一ID
func WithClientID(id string) ClientOpt {
	return func(c *Client) {
		c.id = id
	}
}

// WithMessageType 设置发送数据类型
func WithMessageType(msgType int) ClientOpt {
	return func(c *Client) {
		c.msgType = msgType
	}
}

// NewClient 创建新客户端
func NewClient(opts ...ClientOpt) *Client {
	client := &Client{
		data:        make(chan []byte),
		id:          uuid.NewV4().String(),
		ratelimiter: ratelimit.New(maxNumPerSecond),
		msgType:     websocket.BinaryMessage,
	}
	for _, opt := range opts {
		opt(client)
	}
	return client
}

// Read 读取websocket数据
func (c *Client) Read() {
	defer func() {
		ClientMgrInstance().UnRegister(c)
		_ = c.conn.Close()
	}()
	for {
		_, msg, err := c.conn.ReadMessage()
		if err != nil {
			logger.Errorf("Failed to read message from webSocket remoteip[%s] err %v", c.conn.RemoteAddr().String(), err)
			break
		}
		c.data <- msg
	}
}

// Send 发送数据
func (c *Client) Write() {
	defer func() {
		ClientMgrInstance().UnRegister(c)
		_ = c.conn.Close()
	}()
	// 发送管道数据
	for msg := range c.data {
		_ = c.ratelimiter.Take()
		if err := c.conn.WriteMessage(c.msgType, msg); err != nil {
			logger.Errorf("Failed to write message from websocket remoteip[%s] err %v", c.conn.RemoteAddr().String(), err)
		}
	}
}
