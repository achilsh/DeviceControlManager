package bean

type Sms struct {
	Id        int    `json:"id"`
	Phone     string `json:"phone"`
	RequestId string `json:"request_id"`
	Message   string `json:"message"`
	BizId     string `json:"biz_id"`
	Code      string `json:"code"`
}

func (Sms) TableName() string {
	return "sms"
}
