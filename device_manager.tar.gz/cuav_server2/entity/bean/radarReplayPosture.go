package bean

import (
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
)

type RadarReplayPosture struct {
	Id         int     `json:"id"`
	Sn         string  `json:"sn"`
	Heading    float64 `json:"heading"`
	Pitching   float64 `json:"pitching"`
	Rolling    float64 `json:"rolling"`
	Longitude  float64 `json:"longitude"`                 //经度
	Latitude   float64 `json:"latitude"`                  //纬度
	CreateTime int64   `json:"create_time"  gorm:"index"` //创建时间
}

func (RadarReplayPosture) TableName() string {
	return "radar_replay_posture"
}

func (RadarReplayPosture) GetTableName(sn string) string {
	return common.BuildPostureTableName(sn)
}
