package bean

type RadarTcpPostureInfo struct {
	Id                  int     `json:"id"`
	Sn                  string  `json:"sn"`
	Reserved            uint8   `json:"reserved"`
	Heading             float64 `json:"heading"`   //航线角度
	Pitching            float64 `json:"pitching"`  //纵摇角度
	Rolling             float64 `json:"rolling"`   //横滚角度
	Longitude           float64 `json:"longitude"` //
	Latitude            float64 `json:"latitude"`  //
	Altitude            float64 `json:"altitude"`
	VelocityNavi        float64 `json:"velocity_navi"`          //导航速度（m/s）
	SigProcRelativeTime float64 `json:"sig_proc_relative_time"` //目标时标（绝对时间）
}

func (RadarTcpPostureInfo) TableName() string {
	return "radar_tcp_posture_info"
}
