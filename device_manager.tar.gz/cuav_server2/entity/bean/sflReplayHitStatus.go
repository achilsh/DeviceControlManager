package bean

import "adasgitlab.autel.com/tools/cuav_server/entity/common"

// SFLReplayHitStatusData ...
type SFLReplayHitStatusData struct {
	ID                 int     `json:"id"`
	SN                 string  `json:"sn"`
	HitState           int32   `json:"hitState"`
	ProductType        int32   `json:"productType"`
	DroneName          string  `json:"droneName"`
	SerialNum          string  `json:"serialNum"`
	DroneLongitude     float64 `json:"droneLongitude"`
	DroneLatitude      float64 `json:"droneLatitude"`
	DroneHeight        float64 `json:"droneHeight"`
	DroneYawAngle      float64 `json:"droneYawAngle"`
	DroneSpeed         float64 `json:"droneSpeed"`
	DroneVerticalSpeed float64 `json:"droneVerticalSpeed"`
	SpeedDirection     int32   `json:"speedDirection"`
	DroneSailLongitude float64 `json:"droneSailLongitude"`
	DroneSailLatitude  float64 `json:"droneSailLatitude"`
	PilotLongitude     float64 `json:"pilotLongitude"`
	PilotLatitude      float64 `json:"pilotLatitude"`
	DroneHorizon       float64 `json:"droneHorizon"`
	DronePitch         float64 `json:"dronePitch"`
	UFreq              float64 `json:"uFreq"`
	UDistance          int32   `json:"uDistance"`
	UDangerLevels      int32   `json:"uDangerLevels"`
	Role               int32   `json:"role"`
	CreateTime         int64   `json:"create_time"  gorm:"index"`
}

// GetTableName ..
func (SFLReplayHitStatusData) GetTableName(sn string) string {
	return common.BuildHitStatusTableName(sn)
}
