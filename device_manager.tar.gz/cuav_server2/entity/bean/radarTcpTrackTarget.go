package bean

type RadarTcpTrackTarget struct {
	id                int64   `json:"id"`
	Sn                string  `json:"sn"`
	Obj_id            uint32  `json:"obj_id"`
	HeaderUid         int64   `json:"header_uid"`
	Azimuth           float64 `json:"azimuth"`
	Obj_dist_interpol float64 `json:"obj_dist_interpol"`
	Elevation         float64 `json:"elevation"`
	Velocity          float64 `json:"velocity"`
	Doppler_chn       int16   `json:"doppler_chn"`
	Mag               float64 `json:"mag"`
	Ambiguous         int16   `json:"ambiguous"`
	Classification    int16   `json:"classification"`
	Classfy_prob      float64 `json:"classfy_prob"`
	ExistingProb      float32 `json:"existing_prob"`
	Abs_vel           float64 `json:"abs_vel"`
	Orientation_angle float64 `json:"orientation_angle"`
	Alive             uint16  `json:"alive"`
	Tws_tas_flag      uint16  `json:"tws_tas_flag"`
	X                 float64 `json:"x"`
	Y                 float64 `json:"y"`
	Z                 float64 `json:"z"`
	VX                float64 `json:"vx"`
	VY                float64 `json:"vy"`
	VZ                float64 `json:"vz"`
	AX                float64 `json:"ax"`
	AY                float64 `json:"ay"`
	AZ                float64 `json:"az"`
	X_variance        float64 `json:"x_variance"`
	Y_variance        float64 `json:"y_variance"`
	Z_variance        float64 `json:"z_variance"`
	Vx_variance       float64 `json:"vx_variance"`
	Vy_variance       float64 `json:"vy_variance"`
	Vz_variance       float64 `json:"vz_variance"`
	Ax_variance       float64 `json:"ax_variance"`
	Ay_variance       float64 `json:"ay_variance"`
	Az_variance       float64 `json:"az_variance"`
	State_type        int16   `json:"state_type"`
	Motion_type       int16   `json:"motion_type"`
	Forcast_frame_num int16   `json:"forcast_frame_num"`
	Association_num   int16   `json:"association_num"`
	Assoc_bit0        uint32  `json:"assoc_bit0"`
	Assoc_bit1        uint32  `json:"assoc_bit1"`
	Reserve           uint16  `json:"reserve"`
	Reserved2         uint16  `json:"reserved2"`
	Crc               uint16  `json:"crc"`
	Create_time       string  `json:"create_time"`
	Vendor            string  `json:"vendor"`
	Frequency         string  `json:"frequency"`
	Model             string  `json:"model"`
	Is_whitelist      bool    `json:"is_whitelist"`
}

func (RadarTcpTrackTarget) TableName() string {
	return "radar_tcp_track_target"
}
