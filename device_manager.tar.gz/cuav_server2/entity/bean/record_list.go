package bean

type RecordList struct {
	Id              int32  `json:"id"`
	DevType         int32  `json:"dev_type"`
	DetectTableName string `json:"detect_table_name"`
}

func (RecordList) TableName() string {
	return "record_list"
}
