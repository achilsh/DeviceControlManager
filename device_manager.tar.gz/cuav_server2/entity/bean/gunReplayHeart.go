package bean

import "adasgitlab.autel.com/tools/cuav_server/entity/common"

type GunReplayHeartData struct {
	Id             int     `json:"id"`
	Sn             string  `json:"sn"`
	ScreenStatus   uint32  `json:"screen_status"`
	Electricity    uint32  `json:"electricity"`
	SignalStrength uint32  `json:"signal_strength"`
	WorkStatus     uint32  `json:"work_status"`
	AlarmLevel     uint32  `json:"alarm_level"`
	HitFreq        uint32  `json:"hit_freq"`
	DetectFreq     uint32  `json:"detect_freq"`
	X              uint32  `json:"x"`
	Y              uint32  `json:"y"`
	Z              uint32  `json:"z"`
	GunLongitude   float64 `json:"gun_longitude"`
	GunLatitude    float64 `json:"gun_latitude"`
	GunAltitude    int32   `json:"gun_altitude"`
	SatellitesNum  uint32  `json:"satellites_num"`
	GunDirection   float64 `json:"gun_direction"`
	ReHitTime      uint32  `json:"rehit_time"`
	HitTime        uint32  `json:"hit_time"`
	UDroneNum      uint32  `json:"drone_num"`
	Elevation      float64 `json:"elevation"`
	IsOnline       int32   `json:"is_online"`
	CreateTime     int64   `json:"create_time"  gorm:"index"` //创建时间戳格式  "2006-01-02 15:04:05.000"  // 对应的时间格式
}

func (GunReplayHeartData) GetTableName(sn string) string {
	return common.BuildHeartTableName(sn)
}
