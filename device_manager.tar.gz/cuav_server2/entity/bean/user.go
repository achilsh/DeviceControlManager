package bean

import (
	"strconv"
	"time"
)

type User struct {
	ID             int64  `gorm:"primary_key;auto_increment" json:"id"`
	Role           string `json:"role"`
	Name           string `json:"name"`
	Password       string `json:"password"`
	NickName       string `json:"nick_name"`
	Gender         bool   `json:"gender"`
	Mobile         string `gorm:"unique" json:"mobile"`
	Email          string `gorm:"unique" json:"email"`
	CrtTime        string `json:"crt_time"`
	UpdateTime     string `json:"update_time"`
	Updater        string `json:"updater"`
	PushToken      string `json:"push_token"`
	IsDelete       bool   `json:"is_delete"`
	LastSmsTime    string `json:"last_sms_time"`    // 上次发送短信的时间
	DailySendTimes int64  `json:"daily_send_times"` // 当日已发送短信次数
}

func (User) TableName() string {
	return "user_base"
}

func (user User) GetUid() string {
	return strconv.Itoa(int(user.ID))
}

// GetTodaySendSmsTimes 校验用户当天已发送短信的次数
func (user User) GetTodaySendSmsTimes() (times int64, ok bool) {
	if user.ID == 0 {
		return 0, false
	}
	if user.LastSmsTime == "" {
		return 0, true
	}
	now := time.Now()
	today := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, now.Location())
	lastSmsTime := StringToTime(user.LastSmsTime)
	lastDay := time.Date(lastSmsTime.Year(), lastSmsTime.Month(), lastSmsTime.Day(), 0, 0, 0, 0, lastSmsTime.Location())
	if today == lastDay {
		if user.DailySendTimes >= 5 {
			return user.DailySendTimes, false
		}
		return user.DailySendTimes, true
	}
	return 0, true
}

func StringToTime(str string) time.Time {
	strTime, _ := time.ParseInLocation("2006-01-02 15:04:05", str, time.Local)
	return strTime
}
