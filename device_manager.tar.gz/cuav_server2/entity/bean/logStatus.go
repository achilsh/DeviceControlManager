package bean

type LogStatus struct {
	Id     int32  `json:"id"`
	Sn     string `json:"sn"`
	Status int32  `json:"status"`
	Path   string `json:"path"`
	Proid  int32  `json:"proid"`
}

func (LogStatus) TableName() string {
	return "log_status"
}
