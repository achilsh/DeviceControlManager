package bean

type TracerDetectInfo struct {
	Id                 int     `json:"id"`
	DetectId           int64   `json:"detect_id"`
	ProductType        uint8   `json:"product_type"`         //无人机类型
	DroneName          string  `json:"drone_name"`           //无人机厂商 品牌+机型
	SerialNum          string  `json:"serial_num"`           //无人机Sn码
	DroneLongitude     float64 `json:"drone_longitude"`      //经度
	DroneLatitude      float64 `json:"drone_latitude"`       //纬度
	DroneHeight        float64 `json:"drone_height"`         //高度
	DroneYawAngle      float64 `json:"drone_yaw_angle"`      //偏航角
	DroneSpeed         float64 `json:"drone_speed"`          //速度
	DroneVerticalSpeed float64 `json:"drone_vertical_speed"` //垂直速度
	OperatorLongitude  float64 `json:"operator_longitude"`   //飞手经度
	OperatorLatitude   float64 `json:"operator_latitude"`    //飞手纬度
	Freq               float64 `json:"freq"`                 //频率
	Distance           uint16  `json:"distance"`             //距离
	DangerLevels       uint16  `json:"danger_levels"`        //危险等级
	ReceivedTime       int64   `json:"received_time"`        //创建时间
}

func (TracerDetectInfo) TableName() string {
	return "tracer_detect_info"
}
