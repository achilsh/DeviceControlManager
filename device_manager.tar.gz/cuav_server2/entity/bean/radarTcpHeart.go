package bean

type RadarTcpHeart struct {
	Id          int    `json:"id"`
	Sn          string `json:"sn"`
	Electricity int32  `json:"electricity"` //电量
	Status      int    `json:"status"`      //状态 1 在线 0-离线
	IsOnline    int    `json:"is_online"`
	Ip          string `json:"ip"`         //ip地址
	SerialNum   string `json:"serial_num"` //序列号
}

func (RadarTcpHeart) TableName() string {
	return "radar_tcp_heart"
}
