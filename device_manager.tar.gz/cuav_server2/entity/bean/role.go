package bean

type Role struct {
	Id         int    `json:"id"`
	Name       string `json:"name"`
	Status     int    `json:"status"`
	CrtTime    string `json:"crt_time"`
	UpdateTime string `json:"update_time"`
	Remark     string `json:"remark"`
}

func (Role) TableName() string {
	return "role"
}
