package bean

import (
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
)

type TracerReplayHeart struct {
	Id          int    `json:"id"`
	Sn          string `json:"sn"`
	IsOnline    int    `json:"is_online"`
	Electricity int    `json:"electricity"`
	WorkMode    int    `json:"work_mode"`
	WorkStatus  int    `json:"work_status"`
	AlarmLevel  int    `json:"alarm_level"`
	CreateTime  int64  `json:"create_time"  gorm:"index"` //创建时间戳格式  "2006-01-02 15:04:05.000"  // 对应的时间格式
}

func (TracerReplayHeart) TableName() string {
	return "tracer_replay_heart"
}

func (TracerReplayHeart) GetTableName(sn string) string {
	return common.BuildHeartTableName(sn)
}
