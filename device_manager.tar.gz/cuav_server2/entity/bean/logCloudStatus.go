package bean

type LogCloudStatus struct {
	Id     int32  `json:"id"`
	Status int32  `json:"status"`
	Path   string `json:"path"`
	Proid  int32  `json:"proid"`
}

func (LogCloudStatus) TableName() string {
	return "log_cloud_status"
}
