package bean

type GunTcpHeartUav struct {
	Id                 int     `json:"id"`
	HeaderId           int64   `json:"header_id"`
	ProductType        int     `json:"product_type"`
	DroneName          string  `json:"drone_name"`
	SerialNum          string  `json:"serial_num"`
	DroneLongitude     float64 `json:"drone_longitude"`
	DroneLatitude      float64 `json:"drone_latitude"`
	DroneHeight        float64 `json:"drone_height"`
	DroneYawAngle      float64 `json:"drone_yaw_angle"`
	DroneSpeed         float64 `json:"drone_speed"`
	DroneVerticalSpeed float64 `json:"drone_vertical_speed"`
	PilotLongitude     float64 `json:"pilot_longitude"`
	PilotLatitude      float64 `json:"pilot_latitude"`
	UFreq              float64 `json:"u_freq"`
	UDistance          int     `json:"u_distance"`
	UDangerLevels      int     `json:"u_danger_levels"`
}

func (GunTcpHeartUav) TableName() string {
	return "gun_tcp_heart_uav"
}
