package mavlink

import (
	"encoding/binary"
	"errors"

	"github.com/sigurn/crc16"
)

const (
	checkSumLen = 8           //checksum 位校验长度
	headerLen   = 9           //header 的长度
	crcLen      = 2           //CRC 校验位长度
	crcStartLoc = 1           //CRC 开始位
	frameLoc    = 0           //帧头在协议包中字节位置
	magic       = uint8(0xFD) //帧头
	lenLoc      = 3           //包长度最大位置
)

// Encode 编码
func Encode(mavpacket *MavPacket) ([]byte, error) {
	mavpacket.Header.CheckSum()
	buff := make([]byte, 0)
	buff = append(buff, mavpacket.Header.Encode()...)
	buff = append(buff, mavpacket.PayLoad...)
	crc := make([]byte, crcLen)
	binary.BigEndian.PutUint16(crc, calcCrc(buff[crcStartLoc:]))
	for i := len(crc) - 1; i >= 0; i-- {
		buff = append(buff, crc[i])
	}
	return buff, nil
}

// Decode 解码
func Decode(buff []byte) (*MavPacket, error) {
	if buff == nil {
		return nil, errors.New("buff empty")
	}
	if !IsMavLink(buff[frameLoc]) {
		return nil, errors.New("not mavlink")
	}
	packet := &MavPacket{}
	err := packet.Header.Decode(buff[:headerLen])
	if err != nil {
		return nil, err
	}
	if !isCheckSumEqual(buff[:checkSumLen], packet.Header.Checksum) {
		return nil, errors.New("check sum error")
	}
	packet.Crc = packet.GetCrc(buff[(packet.Len() - crcLen):])
	if !isCheckCrcEqual(buff[crcStartLoc:(packet.Len()-crcLen)], packet.Crc) {
		return nil, errors.New("check crc error")
	}
	packet.PayLoad = make([]byte, packet.payloadLen())
	copy(packet.PayLoad, buff[headerLen:(packet.Len()-crcLen)])
	return packet, nil
}

// IsMavLink 判断包头首字节是否mavlink包
func IsMavLink(first byte) bool {
	return first == magic
}

// GetPacketLen 获取包长度,默认buff第1、2位为包头的len_l, len_h
func GetPacketLen(buff []byte) uint32 {
	if len(buff) < lenLoc {
		return 0
	}
	return uint32(uint16(buff[2])<<8|uint16(buff[1])) + headerLen + crcLen
}

// isCheckSumEqual 校验校验和
func isCheckSumEqual(buff []byte, sum uint8) bool {
	if len(buff) != checkSumLen {
		return false
	}
	var check uint32
	for _, v := range buff {
		check += uint32(v)
	}
	return sum == uint8(check&0xFF)
}

// isCheckCrcEqual 校验校验值
func isCheckCrcEqual(buff []byte, crc uint16) bool {
	if buff == nil {
		return false
	}
	return calcCrc(buff) == crc
}

// calcCrc 获取校验值
func calcCrc(buff []byte) uint16 {
	table := crc16.MakeTable(crc16.CRC16_MCRF4XX)
	return crc16.Checksum(buff, table)
}

// MavHeader Mavlink包头
type MavHeader struct {
	Magic    uint8 //帧头
	Len_l    uint8 //有效数据长度低8位
	Len_h    uint8 //有效数据长度高8位
	Seq      uint8 //帧序号
	Destid   uint8 //接收者的设备ID
	Sourceid uint8 //发送者的设备ID
	Msgid    uint8 //消息ID
	Ans      uint8 //是否需要应答
	Checksum uint8 //包头校验值
}

// CheckSum 计算头部的校验和
func (m *MavHeader) CheckSum() {
	buff := []byte{m.Magic, m.Len_l, m.Len_h, m.Seq, m.Destid, m.Sourceid, m.Msgid, m.Ans}
	var sum uint32
	for _, v := range buff {
		sum += uint32(v)
	}
	m.Checksum = uint8(sum & 0xFF)
}

// Encode 头部编码
func (m *MavHeader) Encode() []byte {
	return []byte{m.Magic, m.Len_l, m.Len_h, m.Seq, m.Destid, m.Sourceid, m.Msgid, m.Ans, m.Checksum}
}

// Decode 头部解码
func (m *MavHeader) Decode(buff []byte) error {
	if len(buff) != headerLen {
		return errors.New("head len error")
	}
	m.Magic = buff[0]
	m.Len_l = buff[1]
	m.Len_h = buff[2]
	m.Seq = buff[3]
	m.Destid = buff[4]
	m.Sourceid = buff[5]
	m.Msgid = buff[6]
	m.Ans = buff[7]
	m.Checksum = buff[8]
	return nil
}

// MavPacket Mavlink包
type MavPacket struct {
	Header  MavHeader
	PayLoad []byte //具体消息内容
	Crc     uint16 //整帧数据校验
}

// Len 包长度
func (m *MavPacket) Len() uint32 {
	return uint32(uint16(m.Header.Len_h)<<8|uint16(m.Header.Len_l)) + headerLen + crcLen
}

// GetCrc 包CRC检验
func (m *MavPacket) GetCrc(buff []byte) uint16 {
	if len(buff) != crcLen {
		return 0
	}
	return uint16(buff[1])<<8 | uint16(buff[0])
}

func (m *MavPacket) SetHead(sourceid, destid, seq, msgid, ans uint8, len uint16) {
	m.Header.Magic = magic
	m.Header.Destid = destid
	m.Header.Sourceid = sourceid
	m.Header.Msgid = msgid
	m.Header.Seq = seq
	m.Header.Ans = ans
	m.Header.Len_l = uint8(len & 0x00FF)
	m.Header.Len_h = uint8((len & 0xFF00) >> 8)
}

// payloadLen 载荷长度
func (m *MavPacket) payloadLen() uint32 {
	return uint32(uint16(m.Header.Len_h)<<8 | uint16(m.Header.Len_l))
}
