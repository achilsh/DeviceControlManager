// Package jwttoken JWT(JSON Web Tokens) 是一种用于在网络应用之间传递信息的安全方式

package jwttoken

import (
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/test"
)

func TestCreateToken(t *testing.T) {
	test.MockConfig()
	type args struct {
		GuardName string
		ID        int64
	}
	tests := []struct {
		name    string
		args    args
		want    TokenOutPut
		wantErr bool
	}{
		{
			name: "Case1",
			args: args{
				GuardName: "C2_test",
				ID:        12345678,
			},
			want: TokenOutPut{
				AccessToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2OTMyOTYwOTUsImp0aSI6IjEyMzQ1Njc4IiwiaXNzIjoiQzJfdGVzdCIsIm5iZiI6MTY5MzI5NTA4NX0.I7mLUKjLOGVI1183FLahggbYeTqOOfekGBOEDb29rK0",
				ExpiresIn:   10,
				TokenType:   "",
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := CreateToken(tt.args.GuardName, tt.args.ID)
			if (err != nil) != tt.wantErr {
				t.Errorf("CreateToken() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}
