//go:build linux || android

package iphelper

import (
	"fmt"
	"net"
	"strconv"
	"strings"
	"syscall"
	"unsafe"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

/*
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <net/if.h>
*/
import "C"

// IPInfo 本地IP地址信息
type IPInfo struct {
	LocalIP     string //本地IP地址
	BroadCastIP string //本地IP地址对应的广播地址
}

// GetLocalIPInfos 获取所有本地网口IP地址
func GetLocalIPInfos() ([]IPInfo, error) {
	interfaces, err := interfaces()
	if err != nil {
		logger.Error("Get local interfaces err %v", err)
		return nil, err
	}
	localIPInfos := []IPInfo{}
	for _, netIF := range interfaces {
		if (netIF.Flags & (net.FlagUp | net.FlagBroadcast | net.FlagLoopback)) == (net.FlagBroadcast | net.FlagUp) {
			addrs, err := netIF.getAddrs()
			if err != nil {
				logger.Error("get net interface addr %+v err %v", netIF, err)
				continue
			}
			for _, addr := range addrs {
				if ipNet, ok := addr.(*net.IPNet); ok {
					if ipNet.IP.To4() != nil {
						broadcast := make(net.IP, len(ipNet.IP.To4()))
						for i := 0; i < len(ipNet.IP.To4()); i++ {
							broadcast[i] = ipNet.IP.To4()[i] | ^ipNet.Mask[i]
						}
						localIPInfos = append(localIPInfos, IPInfo{
							LocalIP:     ipNet.IP.To4().String(),
							BroadCastIP: broadcast.String(),
						})
					}
				}
			}
		}
	}
	return localIPInfos, nil
}

// GetFreeTcpPort gets a free tcp port.
func GetFreeTCPPort() (port int, err error) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return 0, err
	}
	defer listener.Close()

	return listener.Addr().(*net.TCPAddr).Port, nil
}

// MatchLocalIP 根据输入的IP匹配本地中相同网段的ip
func MatchLocalIP(ip string) string {
	interfaces, err := interfaces()
	if err != nil {
		logger.Error("Get local interfaces err %v", err)
		return ""
	}
	for _, netIF := range interfaces {
		if (netIF.Flags & (net.FlagUp | net.FlagBroadcast | net.FlagLoopback)) == (net.FlagBroadcast | net.FlagUp) {
			addrs, err := netIF.Addrs()
			if err != nil {
				logger.Error("get net interface addr %+v err %v", netIF, err)
				continue
			}
			for _, addr := range addrs {
				if ipNet, ok := addr.(*net.IPNet); ok {
					if ipNet.IP.To4() != nil {
						if ipNet.Contains(net.ParseIP(ip)) {
							return ipNet.IP.To4().String()
						}
					}
				}
			}
		}
	}
	return ""
}

type inf struct {
	net.Interface
	addrs []net.Addr
}

func interfaces() ([]inf, error) {
	var addr *C.struct_ifaddrs
	ret, err := C.getifaddrs(&addr)
	if ret != 0 {
		return nil, fmt.Errorf("getifaddrs: %w", err.(syscall.Errno))
	}
	defer C.freeifaddrs(addr)

	interfaces := make(map[string]inf)
	curr := addr

	var iface inf
	for {
		if curr == nil {
			break
		}

		iface = makeInterface(curr)

		// getifaddrs() returns a separate list entry for AF_INET and AF_INET6 addresses, but the
		// other fields are identical. Merge into a single entry as net.Interfaces() does.
		if existing, ok := interfaces[iface.Name]; ok {
			iface.addrs = append(iface.addrs, existing.addrs...)
		}

		// Replaces (potentially) existing with merged version
		interfaces[iface.Name] = iface

		// Advance to next item in linked list
		curr = curr.ifa_next
	}

	s := make([]inf, 0)
	for _, iface = range interfaces {
		s = append(s, iface)
	}
	return s, nil
}
func (i *inf) getAddrs() ([]net.Addr, error) {
	return i.addrs, nil
}

func makeInterface(ifa *C.struct_ifaddrs) (i inf) {
	i.Name = C.GoString(ifa.ifa_name)
	i.Flags = linkFlags(uint32(ifa.ifa_flags))
	i.Index = index(ifa)
	i.addrs = []net.Addr{}

	// getifaddrs doesn't supply this, but it could be fetched via SIOCGIFMTU if needed
	i.MTU = 0

	// HardwareAddr (MAC) is not populated -- this whole package is needed because Android
	// locked down RTM_GETLINK to prevent access to the MAC. The rest of the Interface fields
	// were collateral damage.

	// Not all interfaces have an addr (e.g. VPNs)
	if ifa.ifa_addr == nil {
		return
	}

	var ip string
	var mask string
	family := int(ifa.ifa_addr.sa_family)
	switch family {
	case syscall.AF_INET:
		ip = sockaddr4(ifa.ifa_addr)
		mask = sockmask4(ifa.ifa_netmask)
	//case syscall.AF_INET6:
	//	ip = sockaddr6(ifa.ifa_addr)
	default:
		// Unsupported address family, omit the addr
		return
	}

	// Populate netmask (ifa.ifa_netmask) and IPv6 Zone.
	var m net.IPMask
	ms := strings.Split(mask, ".")
	if len(ms) >= 4 {
		a, _ := strconv.Atoi(ms[0])
		b, _ := strconv.Atoi(ms[1])
		c, _ := strconv.Atoi(ms[2])
		d, _ := strconv.Atoi(ms[3])
		m = net.IPv4Mask(byte(a), byte(b), byte(c), byte(d))
	}
	addr := net.IPNet{IP: net.ParseIP(ip), Mask: m}
	i.addrs = []net.Addr{&addr}

	return
}

func index(ifa *C.struct_ifaddrs) int {
	return int(C.if_nametoindex(ifa.ifa_name))
}

func sockaddr4(sockaddr *C.struct_sockaddr) string {
	var buf [C.INET_ADDRSTRLEN]byte
	addr := (*C.struct_sockaddr_in)(unsafe.Pointer(sockaddr))
	C.inet_ntop(
		syscall.AF_INET,
		unsafe.Pointer(&addr.sin_addr),
		(*C.char)(unsafe.Pointer(&buf[0])),
		C.socklen_t(len(buf)),
	)
	return stripNULL(string(buf[:]))
}

func sockmask4(sockaddr *C.struct_sockaddr) string {
	var buf [C.INET_ADDRSTRLEN]byte
	addr := (*C.struct_sockaddr_in)(unsafe.Pointer(sockaddr))
	C.inet_ntop(
		syscall.AF_INET,
		unsafe.Pointer(&addr.sin_addr),
		(*C.char)(unsafe.Pointer(&buf[0])),
		C.socklen_t(len(buf)),
	)
	return stripNULL(string(buf[:]))
}

func sockaddr6(sockaddr *C.struct_sockaddr) string {
	var buf [C.INET6_ADDRSTRLEN]byte
	addr := (*C.struct_sockaddr_in6)(unsafe.Pointer(sockaddr))
	C.inet_ntop(
		syscall.AF_INET6,
		unsafe.Pointer(&addr.sin6_addr),
		(*C.char)(unsafe.Pointer(&buf[0])),
		C.socklen_t(len(buf)),
	)
	return stripNULL(string(buf[:]))
}

func linkFlags(rawFlags uint32) net.Flags {
	var f net.Flags
	if rawFlags&syscall.IFF_UP != 0 {
		f |= net.FlagUp
	}
	if rawFlags&syscall.IFF_BROADCAST != 0 {
		f |= net.FlagBroadcast
	}
	if rawFlags&syscall.IFF_LOOPBACK != 0 {
		f |= net.FlagLoopback
	}
	if rawFlags&syscall.IFF_POINTOPOINT != 0 {
		f |= net.FlagPointToPoint
	}
	if rawFlags&syscall.IFF_MULTICAST != 0 {
		f |= net.FlagMulticast
	}
	return f
}

func stripNULL(s string) string {
	s, _, _ = strings.Cut(s, "\x00")
	return s
}
