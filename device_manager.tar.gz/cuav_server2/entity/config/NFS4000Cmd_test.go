package config

//func TestCalculatellhToposAndvel(t *testing.T) {
//	type args struct {
//		longitude float64
//		latitude  float64
//		height    float64
//	}
//	tests := []struct {
//		name  string
//		args  args
//		want  string
//		want1 string
//	}{
//		{
//			name: "Test case 1",
//			args: args{
//				longitude: 114.498738,
//				latitude:  22.803104,
//				height:    14.00,
//			},
//			want:  "22.803284, 114.501653, 214.007052",
//			want1: "-1.332346, 19.955572, 0.000000",
//		},
//		// Add more test cases if needed
//	}
//	for _, tt := range tests {
//		t.Run(tt.name, func(t *testing.T) {
//			got, got1 := CalculatellhToposAndvel(tt.args.longitude, tt.args.latitude, tt.args.height)
//			if got != tt.want {
//				t.Errorf("CalculatellhToposAndvel() got = %v, want %v", got, tt.want)
//			}
//			if got1 != tt.want1 {
//				t.Errorf("CalculatellhToposAndvel() got1 = %v, want %v", got1, tt.want1)
//			}
//		})
//	}
//}
//
//func TestEnu2llh(t *testing.T) {
//	type args struct {
//		enu  []float64
//		rllh [3]float64
//		llh  []float64
//	}
//	tests := []struct {
//		name  string
//		args  args
//		want  [3]float64
//		want1 []float64
//	}{
//		{
//			name: "Test case 1",
//			args: args{
//				enu:  []float64{100, 200, 0},
//				rllh: [3]float64{0.7853981633974483, 0.4363323129985824, 14.00},
//				llh:  []float64{0, 0, 0},
//			},
//			want:  [3]float64{0.7853981633974483, 0.4363323129985824, 14.000000},
//			want1: []float64{0.7854154526432877, 0.43636382471706564, 14.003934635780752},
//		},
//		// Add more test cases if needed
//	}
//	for _, tt := range tests {
//		t.Run(tt.name, func(t *testing.T) {
//			got, got1 := Enu2llh(tt.args.enu, tt.args.rllh, tt.args.llh)
//			if !reflect.DeepEqual(got, tt.want) {
//				t.Errorf("Enu2llh() got = %v, want %v", got, tt.want)
//			}
//			if !reflect.DeepEqual(got1, tt.want1) {
//				t.Errorf("Enu2llh() got1 = %v, want %v", got1, tt.want1)
//			}
//		})
//	}
//}
//
//func TestStartActiveProtect(t *testing.T) {
//	m_distance = "300"
//	m_speed = "20"
//	M_tgtHeading = 0
//
//	tests := []struct {
//		name  string
//		want  string
//		want1 string
//	}{
//		{
//			name:  "Test case 1",
//			want:  "22.803284, 114.501653, 214.007052",
//			want1: "-1.332346, 19.955572, 0.000000",
//		},
//		// Add more test cases if needed
//	}
//	for _, tt := range tests {
//		t.Run(tt.name, func(t *testing.T) {
//			got, got1 := StartActiveProtect()
//			if got != tt.want {
//				t.Errorf("StartActiveProtect() got = %v, want %v", got, tt.want)
//			}
//			if got1 != tt.want1 {
//				t.Errorf("StartActiveProtect() got1 = %v, want %v", got1, tt.want1)
//			}
//		})
//	}
//}
