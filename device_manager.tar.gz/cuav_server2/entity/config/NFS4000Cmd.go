package config

import (
	"fmt"
	"math"
	"strconv"
)

// 开启、关闭
const (
	NFSCLOSE = `
$SET,PlyRfChanSw,0,0
$SET,PlyRfChanSw,1,0
$SET,PlyRfChanSw,2,0
$SET,PlyRfChanSw,3,0
$SET,PlySta,0
`
	//NFSCLOSE = "$SET,PlySta,0" + "\r\n" //关闭
	NFSOPEN = "$SET,PlySta,1" + "\r\n" //开启
)
const (
	NSF4000TypeOnline    = 0x1D //29  在离线
	NSF4000TypeWorking   = 0x1E //30  是否工作中
	NSF4000TypeGpsStatus = 0x1F //31  GPS是否定位
	NSF4000TypeEphemeris = 0x20 //32  星历是否收集
	NSF4000TypeTimeSync  = 0x21 //33  时钟是否同步
	NSF4000TypeLLH       = 0x22 //34   经纬高
)

type WorkMode int32

const (
	ACTIVEDEFENSE    WorkMode = 1 //主动防御
	AREADENIAL       WorkMode = 2 //区域拒止
	DIRECTIONALDRIVE WorkMode = 3 //定向驱离
)

const STARTWORK = 99

// 定向驱离
const (
	NFSMOVEEAST  = "$SET,SimMov,0,-20,0,0\r\n" //东向20 m/s驱离
	NFSMOVEWEST  = "$SET,SimMov,0,20,0,0\r\n"  //西向20 m/s驱离
	NFSMOVENORTH = "$SET,SimMov,0,0,-20,0\r\n" //北向20 m/s驱离
	NFSMOVESOUTH = "$SET,SimMov,0,0,20,0\r\n"  //南向20 m/s驱离

	NFSMOVEUP   = "$SET,SimMov,0,0,0,-5\r\n" //向上 5m/s驱离
	NFSMOVEDOWN = "$SET,SimMov,0,0,0,5\r\n"  //向下 5m/s驱离
)

type Angle int32

const (
	NORTH Angle = 360
	EAST  Angle = 90
	SOUTH Angle = 180
	WEST  Angle = 270
	UP    Angle = 1
	DOWN  Angle = -1
)

// AreaDenial 区域拒止
var AreaDenial string = `
$SET,PlyRfChanSw,0,0
$SET,PlyRfChanSw,1,0
$SET,PlyRfChanSw,2,0
$SET,PlyRfChanSw,3,0

$SET,PlySta,0 

$SET,SimChanCtrl,L1CA,1
$SET,PlyIfChanMap,0,L1CA
$SET,PlyIfChanPara,0,123420000,25000000,1575420000

$SET,SimChanCtrl,B1I,1
$SET,PlyIfChanMap,1,B1I
$SET,PlyIfChanPara,1,109098000,25000000,1561098000

$SET,SimChanCtrl,G1I,1
$SET,PlyIfChanMap,2,G1I
$SET,PlyIfChanPara,2,150000000,25000000,1602000000

$SET,SimChanCtrl,E1B,1
$SET,PlyIfChanMap,3,E1B
$SET,PlyIfChanPara,3,123420000,25000000,1575420000

$SET,JamChanCtrl,JAM0,1
$SET,JamChanPara,JAM0,4
$SET,JamGwnPara,JAM0,0,5000000
$SET,JamChanCtrl,JAM1,1
$SET,JamChanPara,JAM1,4
$SET,JamGwnPara,JAM1,0,8500000
$SET,PlyIfChanMap,4,JAM0
$SET,PlyIfChanPara,4,109098000.000,25000000,1561098000.000
$SET,PlyIfChanMap,5,JAM0
$SET,PlyIfChanPara,5,123420000.000,25000000,1575420000.000
$SET,PlyIfChanMap,6,JAM1
$SET,PlyIfChanPara,6,150000000.000,25000000,1602000000.000

$SET,PlyIfChanComb,0,0x7F
$SET,PlyIfChanComb,1,0x0
$SET,PlyIfChanComb,2,0x0
$SET,PlyIfChanComb,3,0x0
$SET,PlyRfChanSw,0,1
$SET,PlyRfChanSw,1,0
$SET,PlyRfChanSw,2,0
$SET,PlyRfChanSw,3,0

$SET,SimPos,1,$Latitude,$Longititude,$Height,0,0,0

$SET,SimTmOft,0
$SET,SimRecPar,0,0,0,0
$SET,SimTrkMode,0
$SET,SimPwrMode,1
$SET,SimCarMode,0
$SET,SimDisMode,0
$SET,SimObsMode,0
$SET,PlyDura,-1
$SET,FlowMode,1

$SET,PlyChanPwr,0,$Power
$SET,PlyChanPwr,1,$Power
$SET,PlyChanPwr,2,$Power
$SET,PlyChanPwr,3,$Power

$SET,PlyChanPwr,4,$Add10
$SET,PlyChanPwr,5,$Add10
$SET,PlyChanPwr,6,$Add10
$SET,PlySta,1
`

// ActiveDefense 主动防御 定向驱离使用
var ActiveDefense string = `
$SET,PlyRfChanSw,0,0
$SET,PlyRfChanSw,1,0
$SET,PlyRfChanSw,2,0
$SET,PlyRfChanSw,3,0
$SET,PlySta,0 

$SET,SimChanCtrl,L1CA,1
$SET,PlyIfChanMap,0,L1CA
$SET,PlyIfChanPara,0,123420000,25000000,1575420000

$SET,SimChanCtrl,B1I,1
$SET,PlyIfChanMap,1,B1I
$SET,PlyIfChanPara,1,109098000,25000000,1561098000

$SET,SimChanCtrl,G1I,1
$SET,PlyIfChanMap,2,G1I
$SET,PlyIfChanPara,2,150000000,25000000,1602000000

$SET,SimChanCtrl,E1B,1
$SET,PlyIfChanMap,3,E1B
$SET,PlyIfChanPara,3,123420000,25000000,1575420000

$SET,JamChanCtrl,JAM0,1
$SET,JamChanPara,JAM0,4
$SET,JamGwnPara,JAM0,0,5000000
$SET,JamChanCtrl,JAM1,1
$SET,JamChanPara,JAM1,4
$SET,JamGwnPara,JAM1,0,8500000
$SET,PlyIfChanMap,4,JAM0
$SET,PlyIfChanPara,4,109098000.000,25000000,1561098000.000
$SET,PlyIfChanMap,5,JAM0
$SET,PlyIfChanPara,5,123420000.000,25000000,1575420000.000
$SET,PlyIfChanMap,6,JAM1
$SET,PlyIfChanPara,6,150000000.000,25000000,1602000000.000

$SET,PlyIfChanComb,0,0x7F
$SET,PlyIfChanComb,1,0x0
$SET,PlyIfChanComb,2,0x0
$SET,PlyIfChanComb,3,0x0
$SET,PlyRfChanSw,0,1
$SET,PlyRfChanSw,1,0
$SET,PlyRfChanSw,2,0
$SET,PlyRfChanSw,3,0

$SET,SimPos,1,$Latitude,$Longititude,$Height,0,0,0

$SET,SimTmOft,0
$SET,SimRecPar,0,0,0,0
$SET,SimTrkMode,0
$SET,SimPwrMode,1
$SET,SimCarMode,0
$SET,SimDisMode,0
$SET,SimObsMode,0
$SET,PlyDura,-1
$SET,FlowMode,1

$SET,PlyChanPwr,0,$Power
$SET,PlyChanPwr,1,$Power
$SET,PlyChanPwr,2,$Power
$SET,PlyChanPwr,3,$Power

$SET,PlyChanPwr,4,$Add10
$SET,PlyChanPwr,5,$Add10
$SET,PlyChanPwr,6,$Add10
$SET,PlySta,1
`

const (
	WGS84_a   = 6378137          // WGS84 semimajor axis
	WGS84_e2  = 0.00669437999014 // WGS84 eccentricity square
	WGS84_e2_ = 0.00673949674228 // WGS84 second eccentricity square
	PI        = 3.14159265358979
)

var (
	m_refPos     [3]float64
	m_tgtRefPnt  [3]float64
	m_tgtRadius  float64
	m_tgtGSpeed  float64
	speed_val    float64
	radius_val   float64
	M_tgtHeading float64 = 0.0 // angle
)

// CalculatellhToposAndvel 诱导设备计算公式
func CalculatellhToposAndvel(speed int32, radius int32, vspeed int32, longitude, latitude, height float64) (string, string) {
	// 使用 C2 发送指令获取 longitude, latitude, height 数据
	//longitude := 114.498738// 获取到的经度值
	//latitude := 22.803104  // 获取到的纬度值
	//height := 14.00        // 获取到的高度值

	m_refPos[1] = longitude * PI / 180 // 经度
	m_refPos[0] = latitude * PI / 180  // 纬度
	m_refPos[2] = height               // 高度

	m_tgtRefPnt[0] = m_refPos[1]
	m_tgtRefPnt[1] = m_refPos[0]
	m_tgtRefPnt[2] = m_refPos[2] + 200

	pos, vel := StartActiveProtect(strconv.Itoa(int(speed)), strconv.Itoa(int(radius)), vspeed)
	return pos, vel
}

// 诱导设备计算公式
func StartActiveProtect(speed string, radius string, vspeed int32) (string, string) {
	pos := ""
	vel := ""
	llh := make([]float64, 3)
	enu := make([]float64, 3)
	venu := make([]float64, 3)

	m_tgtRadius, _ = strconv.ParseFloat(radius, 64)
	m_tgtGSpeed, _ = strconv.ParseFloat(speed, 64)
	speed_val, _ = strconv.ParseFloat(speed, 64)
	radius_val, _ = strconv.ParseFloat(radius, 64)

	//m_tgtOmega = m_tgtGSpeed / m_tgtRadius // angular velocity

	M_tgtHeading += speed_val / radius_val
	if M_tgtHeading > 2*PI {
		M_tgtHeading -= 2 * PI
	} else if M_tgtHeading < (-2 * PI) {
		M_tgtHeading += 2 * PI

	}

	enu[0] = m_tgtRadius * math.Cos(M_tgtHeading)
	enu[1] = m_tgtRadius * math.Sin(M_tgtHeading)
	enu[2] = 0 //垂向速度

	Erllh, Ellh := Enu2llh(enu, m_tgtRefPnt, llh)
	fmt.Println(Erllh, Ellh)

	llh[0] *= 180 / PI // to degree
	llh[1] *= 180 / PI

	pos = fmt.Sprintf("%f, %f, %f", llh[1], llh[0], llh[2])

	venu[0] = -m_tgtGSpeed * math.Sin(M_tgtHeading)
	venu[1] = m_tgtGSpeed * math.Cos(M_tgtHeading)
	venu[2] = float64(vspeed)
	vel = fmt.Sprintf("%f, %f, %f", venu[0], venu[1], venu[2])
	return pos, vel
}

// 诱导设备计算公式
func Enu2llh(enu []float64, rllh [3]float64, llh []float64) ([3]float64, []float64) {
	var r [3]float64
	var rr [3]float64
	var dr [3]float64
	var T [3][3]float64

	lon := rllh[0] // rad
	lat := rllh[1] // rad

	// llh2xyz(rllh, rr) //rllh   经度、纬度、高度
	h := rllh[2] // meter
	N1 := WGS84_a / math.Sqrt(1-WGS84_e2*math.Sin(lat)*math.Sin(lat))
	rr[0] = (N1 + h) * math.Cos(lat) * math.Cos(lon)
	rr[1] = (N1 + h) * math.Cos(lat) * math.Sin(lon)
	rr[2] = (N1*(1-WGS84_e2) + h) * math.Sin(lat)

	// ecef2enu(rllh, T)
	T[0][0] = -math.Sin(lon)
	T[0][1] = math.Cos(lon)
	T[0][2] = 0
	T[1][0] = -math.Sin(lat) * math.Cos(lon)
	T[1][1] = -math.Sin(lat) * math.Sin(lon)
	T[1][2] = math.Cos(lat)
	T[2][0] = math.Cos(lat) * math.Cos(lon)
	T[2][1] = math.Cos(lat) * math.Sin(lon)
	T[2][2] = math.Sin(lat)

	for i := 0; i < 3; i++ {
		dr[i] = 0
		for j := 0; j < 3; j++ {
			dr[i] += T[j][i] * enu[j]
		}
		r[i] = rr[i] + dr[i]
	}

	//==========xyz2llh(r, llh)
	var tanu, tanu_, tanl, cosl, sinl, err float64
	var cosu, sinu, cosu2, sinu2, cosu3, sinu3 float64

	var WGS84_b, p, N float64
	WGS84_b = WGS84_a * math.Sqrt(1-WGS84_e2)

	if r[0] >= 0 { // east/west [0-90](1) (4)
		llh[0] = math.Atan(r[1] / r[0])
	} else { // east [90-180] degree (2)
		if r[1] >= 0 {
			llh[0] = PI + math.Atan(r[1]/r[0])
		} else { // west [90-180] degree (3)
			llh[0] = -PI + math.Atan(r[1]/r[0])
		}
	}

	p = math.Sqrt(r[0]*r[0] + r[1]*r[1])

	tanu = (r[2] / p) * (WGS84_a / WGS84_b)
	for i := 0; i < 10; i++ {
		cosu2 = 1 / (1 + tanu*tanu)
		sinu2 = 1 - cosu2

		if r[2] >= 0 {
			sinu = math.Sqrt(sinu2)
		} else {
			sinu = -math.Sqrt(sinu2)
		}
		cosu = math.Sqrt(cosu2)
		sinu3 = sinu2 * sinu
		cosu3 = cosu2 * cosu
		tanl = (r[2] + WGS84_e2_*WGS84_b*sinu3) / (p - WGS84_e2*WGS84_a*cosu3)

		tanu_ = (WGS84_b / WGS84_a) * tanl
		err = tanu - tanu_

		if err < 1e-6 && err > -1e-6 {
			break
		}
		tanu = tanu_
	}

	llh[1] = math.Atan(tanl)
	sinl = math.Sin(llh[1])
	cosl = math.Cos(llh[1])
	N = WGS84_a / math.Sqrt(1-WGS84_e2*sinl*sinl)

	if cosl > 1e-6 || cosl < -1e-6 {
		llh[2] = p/cosl - N
	} else {
		llh[2] = r[2]/sinl - N + WGS84_e2*N
	}
	return rllh, llh
}
