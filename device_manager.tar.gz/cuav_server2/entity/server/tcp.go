package server

import (
	"context"
	"fmt"
	"net"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

type TcpServer struct {
	Address        string
	Ip             string
	Port           int
	Handle         TcpReceiveCallBack
	ServerType     uint8  //如果是设备的通信信道，对应的是设备id
	ServerName     string //如果是设备的通信信道，对应设备的唯一标识符（比如sn
	Status         int    //服务的状态，设备如果长期断开，则考虑回收的问题
	LastHeartTime  time.Time
	CreateTime     time.Time
	Ch             chan int
	ClientCount    int //客户端连接个数，只在乎曾经连过
	ConnCh         chan TcpConn
	Ctx            context.Context
	NeedUpdateConn bool
}

type TcpConn struct {
	Conn  net.Conn
	DevSn string
}

var (
	TcpChannelPort     int = 8060
	TcpServerNormal    int = 1
	TcpServerNoDevConn int = 2
)

type TcpReceiveCallBack func(ctx context.Context, conn net.Conn)

func NewTcpServer(port int, handle TcpReceiveCallBack) *TcpServer {
	address := fmt.Sprintf(":%v", port)
	logger.Info("TCP服务获取到本机ip:", address)
	return &TcpServer{
		Address: address,
		Handle:  handle,
		Ch:      make(chan int),
		Port:    port,
		ConnCh:  make(chan TcpConn),
	}
}

func (s *TcpServer) Start() {
	listener, err := net.Listen("tcp", s.Address)
	if err != nil {
		logger.Error("tcp server listen err:", err)
		return
	}
	defer listener.Close()
	ctx, cancel := context.WithCancel(context.Background())
	s.Ctx = ctx
	defer cancel()
	logger.Info("tcp server start:", s.Address)
	go func() {
		status := <-s.Ch
		if status == TcpServerNoDevConn {
			listener.Close()
		}
	}()
	s.Status = TcpServerNormal
	s.CreateTime = time.Now()
	for {
		conn, err := listener.Accept()
		if err != nil {
			logger.Error("tcp server accept err: ", err)
			if s.Status != TcpServerNormal {
				return
			}
			break
		}
		logger.Info("tcp listen conn: ", conn.RemoteAddr().String())
		s.ClientCount++
		if s.NeedUpdateConn {
			s.ConnCh <- TcpConn{
				Conn:  conn,
				DevSn: s.ServerName,
			}
		}

		go s.Handle(ctx, conn)
	}
}

func (s *TcpServer) Stop() {
	logger.Info("stop tcp:", s.Address)
	if s.Status != TcpServerNoDevConn {
		s.Status = TcpServerNoDevConn
		s.Ch <- TcpServerNoDevConn
		close(s.Ch)
	}
}
