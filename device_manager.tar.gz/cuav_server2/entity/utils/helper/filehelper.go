package helper

import (
	"fmt"
	"os"
	"path/filepath"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

// Findfile 获取文件完整路径
func Findfile(path string) []string {
	// 打开文件夹，返回一个 *os.File 对象
	folder, err := os.Open(path)
	if err != nil {
		logger.Error("打开文件夹失败：", err)
		return nil
	}
	defer folder.Close()

	// 读取文件夹中的所有文件和文件夹
	fileInfos, err := folder.Readdir(0)
	if err != nil {
		logger.Error("读取文件夹失败：", err)
		return nil
	}

	// 定义结果切片
	var result []string

	// 遍历文件夹中的所有文件和文件夹
	for _, fileInfo := range fileInfos {
		// 获取文件或文件夹的完整路径
		fullPath := filepath.Join(path, fileInfo.Name())

		// 判断是否为文件夹
		if fileInfo.IsDir() {
			// 递归调用 listFiles() 函数，获取该文件夹下所有文件的完整目录
			subResult := Findfile(fullPath)

			// 将子文件夹中的文件完整路径添加到结果切片中
			result = append(result, subResult...)
		} else {
			// 将文件完整路径添加到结果切片中
			result = append(result, fullPath)
		}
	}

	// 返回结果切片
	return result
}

// ListFiles 获取文件夹下所有文件及大小kb
func ListFiles(folderPath string) map[string]float64 {
	// 打开文件夹，返回一个 *os.File 对象
	folder, err := os.Open(folderPath)
	if err != nil {
		fmt.Println("打开文件夹失败：", err)
		return nil
	}
	defer folder.Close()

	// 读取文件夹中的所有文件和文件夹
	fileInfos, err := folder.Readdir(0)
	if err != nil {
		fmt.Println("读取文件夹失败：", err)
		return nil
	}

	// 定义结果 map
	result := make(map[string]float64)

	// 遍历文件夹中的所有文件和文件夹
	for _, fileInfo := range fileInfos {
		// 获取文件或文件夹的完整路径
		fullPath := filepath.Join(folderPath, fileInfo.Name())

		// 判断是否为文件夹
		if fileInfo.IsDir() {
			// 递归调用 listFiles() 函数，获取该文件夹下所有文件的完整目录和文件大小
			subResult := ListFiles(fullPath)

			// 将子文件夹中的文件完整路径和文件大小添加到结果 map 中
			for subPath, subSize := range subResult {
				result[subPath] = subSize
			}
		} else {
			// 获取文件大小（单位为 KB）
			size := float64(fileInfo.Size()) / 1024

			// 将文件完整路径和文件大小添加到结果 map 中
			result[fullPath] = size
		}
	}

	// 返回结果 map
	return result
}

func FindFileMoreDir(root string, fileName string) ([]string, error) {
	var files []string
	err := filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if !info.IsDir() && info.Name() == fileName {
			files = append(files, path)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return files, nil
}

func CreateDirIfNotExist(path string) error {
	if _, err := os.Stat(path); os.IsNotExist(err) {
		err = os.MkdirAll(path, 0755)
		if err != nil {
			logger.Error("MkdirAll,err:", err)
			return err
		}
	}
	return nil
}
