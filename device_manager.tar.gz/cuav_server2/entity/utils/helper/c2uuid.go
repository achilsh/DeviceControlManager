package helper

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/md5"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"io"
	"net"
	"os"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

// C2UUID 生成C2唯一ID
func C2UUID() string {
	hostname, _ := os.Hostname()
	macAddress := getMacAddress()
	version := getVersion()

	hardwareInfo := fmt.Sprintf("%s-%s-%s", hostname, macAddress, version)

	hash := md5.Sum([]byte(hardwareInfo))
	uuid := hex.EncodeToString(hash[:])
	logger.Debugf("hostname %s macAddress %s uuid %s version %s", hostname, macAddress, uuid, version)
	return uuid
}

func getMacAddress() string {
	interfaces, err := net.Interfaces()
	if err != nil {
		return ""
	}
	for _, iface := range interfaces {
		if iface.Flags&net.FlagUp != 0 && iface.Flags&net.FlagLoopback == 0 {
			addrs, err := iface.Addrs()
			if err != nil {
				return ""
			}
			for _, addr := range addrs {
				if ipnet, ok := addr.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
					mac := iface.HardwareAddr.String()
					return mac
				}
			}
		}
	}
	return ""
}

func getVersion() string {
	version, err := os.ReadFile("/proc/version")
	if err != nil {
		logger.Errorf("read /proc/version err %v", err)
		return ""
	}
	return string(version)
}

// Encrypt ...
func Encrypt(in []byte, key []byte) (string, error) {
	return encrypt(in, key)
}

// Decrypt ...
func Decrypt(in string, key []byte) ([]byte, error) {
	return decrypt(in, key)
}

func encrypt(in []byte, key []byte) (string, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		logger.Errorf("aes NewCipher err %v", err)
		return "", err
	}
	cipherText := make([]byte, aes.BlockSize+len(in))
	iv := cipherText[:aes.BlockSize]
	if _, err := io.ReadFull(rand.Reader, iv); err != nil {
		logger.Errorf("ReadFull err %v", err)
		return "", err
	}
	stream := cipher.NewCFBEncrypter(block, iv)
	stream.XORKeyStream(cipherText[aes.BlockSize:], in)
	encodeText := base64.StdEncoding.EncodeToString(cipherText)
	return encodeText, nil
}

func decrypt(in string, key []byte) ([]byte, error) {
	decodeText, err := base64.StdEncoding.DecodeString(in)
	if err != nil {
		logger.Errorf("DecodeString in %s err %v", in, err)
		return nil, err
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		logger.Errorf("aes NewCipher err %v", err)
		return nil, err
	}
	iv := decodeText[:aes.BlockSize]
	cipherText := decodeText[aes.BlockSize:]
	plainText := make([]byte, len(cipherText))
	stream := cipher.NewCFBDecrypter(block, iv)
	stream.XORKeyStream(plainText, cipherText)
	return plainText, nil
}
