package helper

import (
	"reflect"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/test"
)

func Test_encrypt(t *testing.T) {
	test.LoggerMock()

	type args struct {
		in  []byte
		key []byte
	}
	tests := []struct {
		name    string
		args    args
		want    string
		wantErr bool
	}{
		// {
		// 	name: "Case1",
		// 	args: args{
		// 		in:  []byte("01234567899"),
		// 		key: []byte("skyfendCUASC2OSS"),
		// 	},
		// 	want:    "9Bxg9QG7t7/WFb+SpWWiF69ehhT2SrksPyhJ",
		// 	wantErr: false,
		// },
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := encrypt(tt.args.in, tt.args.key)
			if (err != nil) != tt.wantErr {
				t.Errorf("encrypt() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("encrypt() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_decrypt(t *testing.T) {
	type args struct {
		in  string
		key []byte
	}
	tests := []struct {
		name    string
		args    args
		want    []byte
		wantErr bool
	}{
		{
			name: "Case1",
			args: args{
				in:  "nbdqwWBwd6FI71uJnwJwJKw8S6scS0tVp6l0",
				key: []byte("skyfendCUASC2OSS"),
			},
			want:    []byte("01234567899"),
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := decrypt(tt.args.in, tt.args.key)
			if (err != nil) != tt.wantErr {
				t.Errorf("decrypt() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("decrypt() = %v, want %v", got, tt.want)
			}
		})
	}
}
