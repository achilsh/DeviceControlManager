package helper

import (
	"container/heap"
	"fmt"
	"math"
	"sync"
	"testing"
	"time"
)

func TestSkyFendPQ(t *testing.T) {
	type skfString = string
	datas := map[skfString]int{
		"Frank": 3, "Tom": 2, "Alice": 4, "Bob": 5,
	}
	pq := new(SkyFendPQ[skfString])
	i := int32(0)
	for value, priority := range datas {
		heap.Push(pq, &SkyFendPQItem[skfString]{
			Value:    value,
			Priority: int64(priority),
			Index:    i,
		})
		i++
	}
	min := int64(math.MinInt64)
	for pq.Len() > 0 {
		item := heap.Pop(pq).(*SkyFendPQItem[skfString])
		if item.Priority < min {
			t.Error("build min heap fail,[item.Priority - min]: ", item.Priority, min)
		}
		min = item.Priority
		t.Log("[ Value - priority : ]", item.Value, item.Priority)
	}

}

func TestSkyFendPQWrap(t *testing.T) {
	type skfString = string
	datas := map[skfString]int{
		"Frank": 3, "Tom": 2, "Alice": 4, "Bob": 5, "Jeck": 6, "Davi": 1,
	}
	pq := NewSkyFendWrap[skfString]()
	i := int32(0)
	for value, priority := range datas {
		pq.Push(&SkyFendPQItem[skfString]{
			Value:    value,
			Priority: int64(priority),
			Index:    0,
		})
		i++
	}
	wantPrioprity := int64(4)
	seqPrioprity := int64(math.MinInt64)
	list := pq.PopLesserPriority(wantPrioprity)
	for _, v := range list {
		t.Log("item = ", v)
		if v.Priority > wantPrioprity || v.Priority < seqPrioprity {
			t.Error("error SkyFendWrap pop data.")
		}
		seqPrioprity = v.Priority
	}
}

func TestSkyFendPQWrapConcurrency(t *testing.T) {
	type skfString = string
	var wg sync.WaitGroup
	runTimes := 1 // increase concurrency num may case panic,due to slice out of range
	wg.Add(runTimes)
	startTime := time.Now().UnixMilli() + 100000
	pq := NewSkyFendWrap[skfString]()
	// defer func() {
	// 	if r := recover(); r != nil {
	// 		err := fmt.Errorf("panic: %v", r)
	// 		t.Error("panic:", err)
	// 	}
	// }()
	for i := 0; i < runTimes; i++ {
		go func() {
			// defer func() {
			// 	if r := recover(); r != nil {
			// 		err := fmt.Errorf("panic: %v", r)
			// 		t.Error("panic:", err)
			// 	}
			// }()
			time := time.Now().UnixMilli()
			timeStr := fmt.Sprintf("%d", time)
			pq.Push(&SkyFendPQItem[skfString]{
				Value:    timeStr,
				Priority: time,
				Index:    0,
			})
			wg.Done()
		}()
	}
	seqPrioprity := int64(math.MinInt64)
	list := pq.PopLesserPriority(startTime)
	for _, v := range list {
		// t.Log("item = ", v)
		if v.Priority < seqPrioprity {
			msg := fmt.Sprintf("error SkyFendWrap pop data: v.Priority = %d,seqPriorprity = %d", v.Priority, seqPrioprity)
			t.Error(msg)
		}
	}
	wg.Wait()

}
