package ota

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	utils "adasgitlab.autel.com/tools/cuav_server/entity/utils/panic"
)

// GetOtaCloudFileList 获取ota升级包下载地址
func GetOtaCloudFileList(deviceType int32, testSet int32) (*GetOtaCloudFileListResult, error) {
	defer utils.HandlePanic()
	logger.Info("get cloud file list:", deviceType)
	fileType := FileTypeOtaPkg
	if testSet == 1 {
		fileType = TestFileTypeOtaPkg
	}

	req := &FileListReq{
		FileType:   int8(fileType),
		DeviceType: int8(deviceType),
	}
	var result GetOtaCloudFileListResult
	// 尝试从云端获取升级列表
	response, err := SendJsonPostReq(req, GetCloudFileListUrl)
	if err != nil {
		// 获取不到从本地缓存获取列表
		if len(CloudOtaFileCacheList) > 0 {
			result.List = CloudOtaFileCacheList
			return &result, nil
		}
		data, err := os.ReadFile(filepath.Join(DefaultOtaPkgPath, "/cache/list.json"))
		if err != nil {
			logger.Error("GetOtaCloudFileList readFile error")
			return nil, err
		}
		err = json.Unmarshal(data, &CloudOtaFileCacheList)
		if err != nil {
			logger.Error("GetOtaCloudFileList unmarshal json file error")
			return nil, err
		}
		result.List = CloudOtaFileCacheList
		for _, p := range result.List {
			//CloudOtaFileMap[p.FileName] = p
			SetCloudOtaFilePackage(p.FileName, p)

		}
		logger.Debug("get Local list.json :", result)
		return &result, nil
	}

	defer response.Body.Close()
	rsp := Response{}
	if err := json.NewDecoder(response.Body).Decode(&rsp); err != nil {
		logger.Errorf("err json.NewDecoder:%v \n", err)
		return nil, err
	}
	if rsp.Code != 0 {
		return nil, errors.New(rsp.Msg)
	}
	dataStr, err := json.Marshal(rsp.Data)
	if err != nil {
		logger.Errorf("err json.Marshal:%v \n", err)
		return nil, err
	}

	if err = json.Unmarshal(dataStr, &result); err != nil {
		logger.Errorf("err json.Unmarshal(dataStr, &result):%v \n", err)
		return nil, err
	}

	if len(result.List) > 0 {
		CloudOtaFileCacheList = result.List
		for _, p := range result.List {
			//CloudOtaFileMap[p.FileName] = p
			SetCloudOtaFilePackage(p.FileName, p)
		}
		CacheLocal(result.List, "/cache/", "list.json")
	}
	logger.Debug("get cloud list.json :", result)
	return &result, nil
}

// GetOtaCloudFileListUpgrade 获取ota升级包信息列表
func GetOtaCloudFileListUpgrade(deviceType int32) (*GetOtaCloudFileListResult, error) {
	defer utils.HandlePanic()
	logger.Info("get cloud file list:", deviceType)
	fileType := FileTypeOtaPkg

	req := &FileListReq{
		FileType:   int8(fileType),
		DeviceType: int8(deviceType),
	}
	var result GetOtaCloudFileListResult
	// 尝试从云端获取升级列表
	response, err := SendJsonPostReq(req, GetCloudFileListUrl)
	if err != nil {
		// 获取不到从本地缓存获取列表
		if len(CloudOtaFileCacheList) > 0 {
			result.List = CloudOtaFileCacheList
			return &result, nil
		}
		data, err := os.ReadFile(filepath.Join(DefaultOtaPkgPath, "/cache/list.json"))
		if err != nil {
			logger.Error("GetOtaCloudFileList readFile error")
			return nil, err
		}
		err = json.Unmarshal(data, &CloudOtaFileCacheList)
		if err != nil {
			logger.Error("GetOtaCloudFileList unmarshal json file error")
			return nil, err
		}
		result.List = CloudOtaFileCacheList
		for _, p := range result.List {
			//CloudOtaFileMap[p.FileName] = p
			SetCloudOtaFilePackage(p.FileName, p)

		}
		logger.Debug("get Local list.json :", result)
		return &result, nil
	}

	defer response.Body.Close()
	rsp := Response{}
	if err := json.NewDecoder(response.Body).Decode(&rsp); err != nil {
		logger.Errorf("err json.NewDecoder:%v \n", err)
		return nil, err
	}
	if rsp.Code != 0 {
		return nil, errors.New(rsp.Msg)
	}
	dataStr, err := json.Marshal(rsp.Data)
	if err != nil {
		logger.Errorf("err json.Marshal:%v \n", err)
		return nil, err
	}

	if err = json.Unmarshal(dataStr, &result); err != nil {
		logger.Errorf("err json.Unmarshal(dataStr, &result):%v \n", err)
		return nil, err
	}

	if len(result.List) > 0 {
		CloudOtaFileCacheList = result.List
		for _, p := range result.List {
			//CloudOtaFileMap[p.FileName] = p
			SetCloudOtaFilePackage(p.FileName, p)
		}
		CacheLocal(result.List, "/cache/", "list.json")
	}
	logger.Debug("get cloud list.json :", result)
	return &result, nil
}
