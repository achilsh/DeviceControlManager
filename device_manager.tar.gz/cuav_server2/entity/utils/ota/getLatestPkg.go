package ota

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	utils "adasgitlab.autel.com/tools/cuav_server/entity/utils/panic"
)

func GetLatestPkg(deviceType int32) (*Package, error) {
	defer utils.HandlePanic()
	// 先尝试查询云端
	req := &GetLatestPkgReq{
		DeviceType: int8(deviceType),
	}
	response, err := SendJsonPostReq(req, GetLatestPkgUrl)
	if err != nil {
		// 云端查询失败查询本地缓存
		if len(LatestOtaCacheMap) > 0 {
			//return LatestOtaCacheMap[deviceType], nil
			rsp, _ := GetLatestOtaCacheMapPackage(deviceType)
			return rsp, nil
		}
		if len(CloudOtaFileCacheList) == 0 {
			data, err := os.ReadFile(filepath.Join(DefaultOtaPkgPath, "/cache/list.json"))
			if err != nil {
				logger.Error("GetOtaCloudFileList readFile error")
				return nil, err
			}
			err = json.Unmarshal(data, &CloudOtaFileCacheList)
			if err != nil {
				logger.Error("GetOtaCloudFileList unmarshal json file error")
				return nil, err
			}
		}
		for _, p := range CloudOtaFileCacheList {
			if p.IsLatest == 1 {
				SetLatestOtaCacheMapPackage(int32(p.DeviceType), &Package{
					ID:         p.ID,
					CreatedAt:  p.CreatedAt,
					UpdatedAt:  p.UpdatedAt,
					DeletedAt:  p.DeletedAt,
					FileKey:    p.FileKey,
					FileName:   p.FileName,
					Version:    p.Version,
					IsLatest:   p.IsLatest,
					FileType:   p.FileType,
					FileSize:   p.FileSize,
					MacAddr:    p.MacAddr,
					UserName:   p.UserName,
					DeviceType: p.DeviceType,
					Status:     p.Status,
				})
			}
		}
		rsp, _ := GetLatestOtaCacheMapPackage(deviceType)
		return rsp, nil
	}

	defer response.Body.Close()
	rsp := Response{}
	if err := json.NewDecoder(response.Body).Decode(&rsp); err != nil {
		logger.Errorf("err json.NewDecoder:%v \n", err)
		return nil, err
	}
	if rsp.Code != 0 {
		return nil, errors.New(rsp.Msg)
	}
	dataStr, err := json.Marshal(rsp.Data)
	if err != nil {
		logger.Errorf("err json.Marshal:%v \n", err)
		return nil, err
	}
	var data Package
	if err = json.Unmarshal(dataStr, &data); err != nil {
		logger.Errorf("err json.Unmarshal(dataStr, &data):%v \n", err)
		return nil, err
	}

	return &data, nil
}
