package threatlevel

import (
	"math"
)

// JudgeElement 最大威胁等级判断依据
type JudgeElement struct {
	X             float64 // x相对坐标（m）
	Y             float64 // y相对坐标（m）
	Z             float64 // z相对坐标（m）
	Vx            float64 // x方向相对速度（m/s）
	Vy            float64 // y方向相对速度（m/s）
	EleScanCenter int32   // 俯仰扫描中心，-20°～+20°，默认为0
	EleScanScope  int32   // 俯仰扫描范围，0、10、20、40，默认为40
	Pitching      float64 // 纵摇角度，平台坐标系相对于地理坐标系在垂直平面内的摇摆角，平台前边高为正，平台后边高为负。取值范围：[-30,+30]度
}

// MaxThreatLevel 最大威胁等级判断
func MaxThreatLevel(e *JudgeElement) int {
	d1 := math.Sqrt(e.X*e.X+e.Y*e.Y) - 200
	if d1 < 0 {
		d1 = 0
	}
	d2 := math.Sqrt(e.X*e.X + e.Y*e.Y)
	vCosTheta1 := (e.Vx*e.X + e.Vy*e.Y) / d2
	t1 := -1 * d1 / vCosTheta1
	if t1 > 1000 {
		t1 = 1000
	}

	var theta2 float64
	if e.Z >= 0 {
		theta2 = float64(e.EleScanCenter) + float64(e.EleScanScope)/2 + e.Pitching
	} else {
		theta2 = float64(e.EleScanCenter) - float64(e.EleScanScope)/2 + e.Pitching
	}
	tanTheta2 := math.Tan(theta2 * math.Pi / 180)
	d3 := d2 - e.Z/tanTheta2
	if d3 < 0 {
		d3 = 0
	}
	t2 := -1 * d3 / vCosTheta1
	if t2 > 1000 {
		t2 = 1000
	}

	var l1, l2 int
	t1 = t1 - 15
	if t1 < 20 {
		l1 = 1
	} else if t1 <= 90 {
		l1 = 2
	} else {
		l1 = 3
	}

	if t2 < 10 {
		l2 = 1
	} else if t2 <= 20 {
		l2 = 2
	} else {
		l2 = 3
	}

	if l1 < l2 {
		return l1
	}
	return l2
}
