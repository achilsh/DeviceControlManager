package common

type Response struct {
	ErrorCode int32       `json:"error_code"`
	Message   string      `json:"message,omitempty"`
	Data      interface{} `json:"data"`
}
