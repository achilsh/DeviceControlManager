// Package api 用户管理

package webapi

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/agiledragon/gomonkey"
	"github.com/emicklei/go-restful"
	"github.com/stretchr/testify/assert"
	"gorm.io/gorm"
)

func Test_userAPI_Register_Case1(t *testing.T) {
	// Mock 日志
	test.LoggerMock()
	// Mock数据库
	DB, mock := test.GetMockDB(t)
	patch := gomonkey.ApplyFunc(db.GetDB, func() *gorm.DB {
		return DB
	})
	defer patch.Reset()

	mock.ExpectQuery("^SELECT \\* FROM `user_base` WHERE name = \\? ORDER BY `user_base`.`id` LIMIT 1").WillReturnError(gorm.ErrDuplicatedKey)

	data := `{"name":"test1", "password":"aaa", "nickname":"test111", "mobile":"1122232424"}`
	req := httptest.NewRequest(http.MethodPost, "/user/register", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		u    *userAPI
		args args
	}{
		{
			name: "Case1",
			u:    &userAPI{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.u.Register(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
			if tt.args.res.Error() != nil {
				t.Errorf("test case %s error %v", tt.name, tt.args.res.Error())
				return
			}
		})
	}
}

func Test_userAPI_Register_Case2(t *testing.T) {
	// Mock 日志
	test.LoggerMock()
	// Mock数据库
	DB, mock := test.GetMockDB(t)
	patch := gomonkey.ApplyFunc(db.GetDB, func() *gorm.DB {
		return DB
	})
	defer patch.Reset()

	mock.ExpectQuery("^SELECT \\* FROM `user_base` WHERE name = \\? ORDER BY `user_base`.`id` LIMIT 1").WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectExec("INSERT INTO `user_base` \\(`role`,`name`,`password`,`nick_name`,`gender`,`mobile`,`email`,`crt_time`,`update_time`,`updater`,`push_token`,`is_delete`,`last_sms_time`,`daily_send_times`\\) VALUES \\(\\?,\\?,\\?,\\?,\\?,\\?,\\?,\\?,\\?,\\?,\\?,\\?,\\?,\\?\\)").WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()

	data := `{"name":"test1", "password":"aaa", "nickname":"test111", "mobile":"1122232424"}`
	req := httptest.NewRequest(http.MethodPost, "/user/register", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		u    *userAPI
		args args
	}{
		{
			name: "Case1",
			u:    &userAPI{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.u.Register(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
			if tt.args.res.Error() != nil {
				t.Errorf("test case %s error %v", tt.name, tt.args.res.Error())
				return
			}
		})
	}
}

//func Test_userAPI_Login_Case1(t *testing.T) {
//	// Mock 日志
//	test.LoggerMock()
//	// Mock数据库
//	var mock sqlmock.Sqlmock
//	handler.Db, mock = test.GetMockDB(t)
//
//	mock.ExpectQuery("^SELECT \\* FROM `user_base` WHERE name = \\? ORDER BY `user_base`.`id` LIMIT 1").WillReturnError(gorm.ErrRecordNotFound)
//
//	data := `{"name":"test1", "password":"aaa"}`
//	req := httptest.NewRequest(http.MethodPost, "/user/login", strings.NewReader(data))
//	req.Header.Set("Content-Type", "application/json")
//	rsp := httptest.NewRecorder()
//
//	type args struct {
//		req *restful.Request
//		res *restful.Response
//	}
//	tests := []struct {
//		name string
//		u    *userAPI
//		args args
//	}{
//		{
//			name: "Case1",
//			u:    &userAPI{},
//			args: args{
//				req: restful.NewRequest(req),
//				res: restful.NewResponse(rsp),
//			},
//		},
//	}
//	for _, tt := range tests {
//		t.Run(tt.name, func(t *testing.T) {
//			tt.u.Login(tt.args.req, tt.args.res)
//			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
//		})
//	}
//}
//
//func Test_userAPI_Login_Case2(t *testing.T) {
//	// Mock 日志
//	test.LoggerMock()
//	// Mock数据库
//	var mock sqlmock.Sqlmock
//	handler.Db, mock = test.GetMockDB(t)
//
//	rows := sqlmock.NewRows([]string{"id", "name", "nickname", "mobile", "password"}).AddRow(
//		1, "test1", "aaaa", "ffag@qq.com", "aaa",
//	)
//	mock.ExpectQuery("^SELECT \\* FROM `user_base` WHERE name = \\? ORDER BY `user_base`.`id` LIMIT 1").WillReturnRows(rows)
//
//	//Mock配置
//	config.Global = &config.GlobalConfig{
//		Jwt: &config.Jwt{
//			Ttl: 10,
//		},
//	}
//
//	data := `{"name":"test1", "password":"aaa"}`
//	req := httptest.NewRequest(http.MethodPost, "/user/login", strings.NewReader(data))
//	req.Header.Set("Content-Type", "application/json")
//	rsp := httptest.NewRecorder()
//
//	type args struct {
//		req *restful.Request
//		res *restful.Response
//	}
//	tests := []struct {
//		name string
//		u    *userAPI
//		args args
//	}{
//		{
//			name: "Case1",
//			u:    &userAPI{},
//			args: args{
//				req: restful.NewRequest(req),
//				res: restful.NewResponse(rsp),
//			},
//		},
//	}
//	for _, tt := range tests {
//		t.Run(tt.name, func(t *testing.T) {
//			tt.u.Login(tt.args.req, tt.args.res)
//			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
//			if tt.args.res.Error() != nil {
//				t.Errorf("test case %s error %v", tt.name, tt.args.res.Error())
//				return
//			}
//		})
//	}
//}

func Test_userAPI_Update(t *testing.T) {
	// Mock 日志
	test.LoggerMock()
	// Mock数据库
	DB, mock := test.GetMockDB(t)
	patch := gomonkey.ApplyFunc(db.GetDB, func() *gorm.DB {
		return DB
	})
	defer patch.Reset()

	mock.ExpectQuery("^SELECT \\* FROM `user_base` WHERE id = \\? ORDER BY `user_base`.`id` LIMIT 1").WillReturnRows(sqlmock.NewRows([]string{"id", "name", "nickname", "mobile", "password"}).AddRow(1, "test1", "aaaa", "ffag@qq.com", "aaa"))
	mock.ExpectQuery("SELECT count\\(\\*\\) FROM `user_base` WHERE name = \\? and id != \\?").WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg()).WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(2))

	mock.ExpectBegin()
	mock.ExpectExec("UPDATE `user_base` SET `name`=\\?, `password`=\\?").WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg()).WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()

	data := `{"name":"test1", "password":"aaa"}`
	req := httptest.NewRequest(http.MethodPost, "/user/update", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		u    *userAPI
		args args
	}{
		{
			name: "Case1",
			u:    &userAPI{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			u := &userAPI{}
			u.Update(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_userAPI_ChangePasswd(t *testing.T) {
	// Mock 日志
	test.LoggerMock()
	// Mock数据库
	DB, mock := test.GetMockDB(t)
	patch := gomonkey.ApplyFunc(db.GetDB, func() *gorm.DB {
		return DB
	})
	defer patch.Reset()

	mock.ExpectQuery("SELECT \\* FROM `user_base` WHERE `id` = \\? ORDER BY `user_base`.`id` LIMIT 1").WillReturnRows(sqlmock.NewRows([]string{"id", "name", "nickname", "mobile", "password"}).AddRow(1, "test1", "aaaa", "ffag@qq.com", "aaa"))

	mock.ExpectBegin()
	mock.ExpectExec("UPDATE `user_base` SET `name`=\\?, `password`=\\? Where `id` = \\?").WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()

	data := `{"name":"test1", "password":"aaa"}`
	req := httptest.NewRequest(http.MethodPost, "/user/change", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		u    *userAPI
		args args
	}{
		{
			name: "Case1",
			u:    &userAPI{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			u := &userAPI{}
			u.ChangePasswd(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_userAPI_List(t *testing.T) {
	// Mock 日志
	test.LoggerMock()
	// Mock数据库
	DB, mock := test.GetMockDB(t)
	patch := gomonkey.ApplyFunc(db.GetDB, func() *gorm.DB {
		return DB
	})
	defer patch.Reset()

	mock.ExpectQuery("SELECT count\\(\\*\\) FROM `user_base`").WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(2))

	mock.ExpectQuery("SELECT `user_base`.`id`,`user_base`.`role`,`user_base`.`name`,`user_base`.`password`,`user_base`.`nick_name`,`user_base`.`gender`,`user_base`.`mobile`,`user_base`.`email`,`user_base`.`crt_time`,`user_base`.`update_time`,`user_base`.`updater`,`user_base`.`push_token`,`user_base`.`is_delete` FROM `user_base` ORDER BY crt_time desc LIMIT 10").WillReturnRows(sqlmock.NewRows([]string{"id", "name", "nickname", "mobile", "password"}).AddRow(1, "test1", "aaaa", "ffag@qq.com", "aaa"))

	data := `{"name":"test1", "password":"aaa"}`
	req := httptest.NewRequest(http.MethodPost, "/user/list", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		u    *userAPI
		args args
	}{
		{
			name: "Case1",
			u:    &userAPI{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			u := &userAPI{}
			u.List(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_userAPI_ResetPwd(t *testing.T) {
	// Mock 日志
	test.LoggerMock()
	// Mock数据库
	DB, mock := test.GetMockDB(t)
	patch := gomonkey.ApplyFunc(db.GetDB, func() *gorm.DB {
		return DB
	})
	defer patch.Reset()

	mock.ExpectBegin()
	mock.ExpectExec("UPDATE `user_base` SET `password`=\\? WHERE mobile = \\?").WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg()).WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()

	data := `{"phone":"test1", "password":"aaa"}`
	req := httptest.NewRequest(http.MethodPost, "/user/reset", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		u    *userAPI
		args args
	}{
		{
			name: "Case1",
			u:    &userAPI{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			u := &userAPI{}
			u.ResetPwd(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_userAPI_Delete(t *testing.T) {
	// Mock 日志
	test.LoggerMock()
	// Mock数据库
	DB, mock := test.GetMockDB(t)
	patch := gomonkey.ApplyFunc(db.GetDB, func() *gorm.DB {
		return DB
	})
	defer patch.Reset()

	mock.ExpectBegin()
	mock.ExpectExec("DELETE FROM `user_base` WHERE `user_base`.`id` IN \\(\\?,\\?\\)").WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg()).WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()

	data := `{"ids":[1,2]}`
	req := httptest.NewRequest(http.MethodPost, "/user/delete", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		u    *userAPI
		args args
	}{
		{
			name: "Case1",
			u:    &userAPI{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			u := &userAPI{}
			u.Delete(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}
