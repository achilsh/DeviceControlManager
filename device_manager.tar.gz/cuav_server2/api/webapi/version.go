package webapi

import (
	"context"
	"net/http"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

var (
	VersionApi = new(Version)
)

type Version struct {
}

func (v *Version) C2DbReset(request *restful.Request, response *restful.Response) {
	c2Req := &client.ExecReq{}
	c2Rsp := &client.ExecRes{}
	err := request.ReadEntity(c2Req)
	if err != nil {
		ParameterBindFail(http.StatusBadRequest, err.Error(), response)
		return
	}
	err = handler.NewSqlSrv().Exec(context.Background(), c2Req, c2Rsp)
	if err != nil {
		CustomFail(http.StatusInternalServerError, err.Error(), response)
		return
	}
	Success(nil, response)

}

func init() {
	RegistHandler("/c2/reset", VersionApi.C2DbReset)
}
