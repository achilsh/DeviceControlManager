package webapi

var ErrCode = map[string]int32{
	"do not send the verification code repeatedly within a minute": 2001,
	"incorrect verification code":                                  2002,
	"verification code has expired":                                2003,
	"internal service error":                                       2004,
	"SMS sent exceeds the daily limit":                             2005,
}

func GetErrCode(err error) int32 {
	errJson := err.Error()
	// errInfo := &ErrInfo{}
	// if err1 := jsoniter.Unmarshal([]byte(errJson), &errInfo); err1 != nil {
	// 	return 500
	// }
	// if code, ok := ErrCode[errInfo.Detail]; ok {
	// 	return code
	// }
	if code, ok := ErrCode[errJson]; ok {
		return code
	}
	return 500
}

type ErrInfo struct {
	Code   int    `json:"code"`
	Detail string `json:"detail"`
}
