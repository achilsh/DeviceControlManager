package webapi

import (
	"context"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"adasgitlab.autel.com/tools/cuav_plugin/broker/memory"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"github.com/agiledragon/gomonkey"
	"github.com/emicklei/go-restful"
	"github.com/stretchr/testify/assert"
)

func Test_deviceManager_GetSystemInfo(t *testing.T) {
	data := `{"sn":"v1.0.0.15","data_type":2}`
	req := httptest.NewRequest(http.MethodPost, "/device/radar/get-system-info", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "GetSystemInfo", func(_ *handler.DeviceCenter, _ context.Context, req *client.GetSystemInfoRequest, rsp *client.GetSystemInfoResponse) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.GetSystemInfo(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_deviceManager_SetWifiDisConn(t *testing.T) {
	test.LoggerMock()
	mq.EquipMessageBoxBroker = memory.NewBroker()
	data := `{"sn":"12", "status":1}`
	req := httptest.NewRequest(http.MethodPost, "/device/radar/close-wifi", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.EquipList{}
	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "SetEnableState", func(_ *handler.EquipList, _ context.Context, req *client.SetEnableReq, res *client.SetEnableRes) error {
		res.Status = 1
		return nil
	})
	patches.ApplyMethod(reflect.TypeOf(e), "SetWifiDisConn", func(_ *handler.DeviceCenter, _ context.Context, req *client.SetWifiDisConnRequest, rsp *client.SetWifiDisConnResponse) error {
		rsp.Status = 0
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.SetWifiDisConn(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_deviceManager_SetWifiConn(t *testing.T) {
	test.LoggerMock()
	mq.EquipMessageBoxBroker = memory.NewBroker()
	data := `{"sn":"12", "status":1}`
	req := httptest.NewRequest(http.MethodPost, "/device/radar/open-wifi", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.EquipList{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "SetEnableState", func(_ *handler.EquipList, _ context.Context, req *client.SetEnableReq, res *client.SetEnableRes) error {
		res.Status = 1
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.SetWifiConn(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}
