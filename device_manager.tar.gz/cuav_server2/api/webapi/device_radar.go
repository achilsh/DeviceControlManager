package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

// GetSystemInfo 雷达 获取系统信息 0xD2
func (e *deviceManager) GetSystemInfo(req *restful.Request, res *restful.Response) {
	devReq := &client.GetSystemInfoRequest{}
	devRsp := &client.GetSystemInfoResponse{}
	err := req.ReadEntity(devReq)
	if err != nil {
		logger.Errorf("parse GetSystemInfo params[%v] error:%v", devReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GetSystemInfo(context.Background(), devReq, devRsp)
	if err != nil {
		logger.Errorf("radar GetSystemInfo error:%v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(devRsp, res)
}

// SetSystemStatus 雷达系统设备
func (e *deviceManager) SetSystemStatus(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SetSystemStatusRequest{}
	deviceRsp := &client.SetSystemStatusResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		logger.Errorf("parse SetSystemStatus params[%v] error:%v", deviceReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().SetSystemStatus(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("radar SetSystemStatus error:%v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) GetCryptKey(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetCryptKeyRequest{}
	deviceRsp := &client.GetCryptKeyResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		logger.Errorf("parse GetCryptKey params[%v] error:%v", deviceReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GetCryptKey(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("radar GetCryptKey error:%v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) SetSn(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SetSnRequest{}
	deviceRsp := &client.SetSnResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		logger.Errorf("parse SetSn params[%v] error:%v", deviceReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().SetSn(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("radar SetSn error:%v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) SetUploadMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SetUploadModeRequest{}
	deviceRsp := &client.SetUploadModeResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		logger.Errorf("parse SetUploadMode params[%v] error:%v", deviceReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().SetUploadMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("radar SetUploadMode error:%v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) SetWifiDisConn(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SetWifiDisConnRequest{}
	deviceRsp := &client.SetWifiDisConnResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		logger.Errorf("parse SetWifiDisConn params[%v] error:%v", deviceReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	setStatusRes := &client.SetEnableRes{}
	err = handler.NewEquipList().SetEnableState(context.Background(), &client.SetEnableReq{Sn: deviceReq.Sn, Status: 2, EType: "radar"}, setStatusRes)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	if setStatusRes.Status != 1 {
		ParameterBindFail(500, "禁用失败", res)
		return
	}

	err = handler.NewDeviceCenter().SetWifiDisConn(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("radar SetWifiDisConn error:%v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	if deviceRsp.Status == 1 {
		deviceRsp.Status = 0
	} else {
		deviceRsp.Status = 1
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) SetWifiConn(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SetWifiDisConnRequest{}
	deviceRsp := &client.SetWifiDisConnResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		logger.Errorf("parse SetWifiConn params[%v] error:%v", deviceReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	setStatusRes := &client.SetEnableRes{}
	err = handler.NewEquipList().SetEnableState(context.Background(), &client.SetEnableReq{Sn: deviceReq.Sn, Status: deviceReq.Status, EType: "radar"}, setStatusRes)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	if deviceRsp.Status == 1 {
		deviceRsp.Status = 0
	} else {
		deviceRsp.Status = 1
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) RadarGetBeamConfig(req *restful.Request, res *restful.Response) {
	deviceReq := &client.RadarGetBeamConfigRequest{}
	deviceRsp := &client.RadarGetBeamConfigResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().RadarGetBeamConfig(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("radar GetBeamConfig error: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) RadarStartDetect(req *restful.Request, res *restful.Response) {
	deviceReq := &client.RadarStartDetectRequest{}
	deviceRsp := &client.RadarStartDetectResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		logger.Errorf("parse RadarStartDetect params[%v] error:%v", deviceReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().RadarStartDetect(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("radar RadarStartDetect error:%v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	//设备的接口返回值和其他接口反了
	if deviceRsp.Status == 0 {
		deviceRsp.Status = 1
	} else if deviceRsp.Status == 1 {
		deviceRsp.Status = 0
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) RadarEndDetect(req *restful.Request, res *restful.Response) {
	deviceReq := &client.RadarEndDetectRequest{}
	deviceRsp := &client.RadarEndDetectResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		logger.Errorf("parse RadarEndDetect params[%v] error:%v", deviceReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().RadarEndDetect(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("radar RadarEndDetect error:%v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	//status := &SetRadarResultEntity{}
	//设备的接口返回值和其他接口反了
	if deviceRsp.Status == 0 {
		deviceRsp.Status = 1
	} else if deviceRsp.Status == 1 {
		deviceRsp.Status = 0
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) RadarSetBeamSchedule(req *restful.Request, res *restful.Response) {
	deviceReq := &client.RadarSetBeamScheduleRequest{}
	deviceRsp := &client.RadarSetBeamScheduleResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().RadarSetBeamSchedule(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("radar SetBeamConfig error: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) GetSourceId(req *restful.Request, res *restful.Response) {
	reqData := &client.GetSourceIdReq{}
	err := req.ReadEntity(reqData)
	if err != nil {
		logger.Errorf("parse GetSourceId params[%v] error:%v", reqData, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	result := &client.GetSourceIdRes{}
	err = handler.NewEquipList().GetSourceId(context.Background(), reqData, result)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(result, res)
}

func (e *deviceManager) GetStatus(req *restful.Request, res *restful.Response) {
	reqData := &client.GetStatusReq{}
	err := req.ReadEntity(reqData)
	if err != nil {
		logger.Errorf("parse GetStatus params[%v] error:%v", reqData, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	result := &client.GetStatusRes{}
	err = handler.NewEquipList().GetStatus(context.Background(), reqData, result)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(result, res)
}

func (e *deviceManager) RadarPostureCalibration(req *restful.Request, res *restful.Response) {
	deviceReq := &client.PostureCalibrationRequest{}
	deviceRsp := &client.PostureCalibrationResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().PostureCalibration(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) RadarPostureCalibrationManual(req *restful.Request, res *restful.Response) {
	deviceReq := &client.PostureCalibrationManualRequest{}
	deviceRsp := &client.PostureCalibrationManualResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().PostureCalibrationManual(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) RadarGetVersionInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.RadarGetVersionInfoRequest{}
	deviceRsp := &client.RadarGetVersionInfoResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().RadarGetVersionInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func init() {
	//雷达 获取系统信息
	RegistHandler("/device/radar/get-system-info", DeviceManagerApi.GetSystemInfo) //前端未使用
	RegistHandler("/device/radar/set-system-status", DeviceManagerApi.SetSystemStatus)
	RegistHandler("/device/radar/get-crypt-key", DeviceManagerApi.GetCryptKey) //前端未使用
	RegistHandler("/device/radar/set-sn", DeviceManagerApi.SetSn)
	RegistHandler("/device/radar/set-upload-mode", DeviceManagerApi.SetUploadMode)
	RegistHandler("/device/radar/close-wifi", DeviceManagerApi.SetWifiDisConn)
	RegistHandler("/device/radar/open-wifi", DeviceManagerApi.SetWifiConn)
	RegistHandler("/device/radar/get-source-id", DeviceManagerApi.GetSourceId)
	RegistHandler("/device/radar/get-status", DeviceManagerApi.GetStatus)
	RegistHandler("/device/radar/get-beam-config", DeviceManagerApi.RadarGetBeamConfig)
	RegistHandler("/device/radar/start-detect", DeviceManagerApi.RadarStartDetect)
	RegistHandler("/device/radar/end-detect", DeviceManagerApi.RadarEndDetect)
	RegistHandler("/device/radar/set-beam-schedule", DeviceManagerApi.RadarSetBeamSchedule)
	RegistHandler("/device/radar/posture/calibration", DeviceManagerApi.RadarPostureCalibration)
	RegistHandler("/device/radar/posture/calibration-manual", DeviceManagerApi.RadarPostureCalibrationManual)
	RegistHandler("/device/radar/get-version-info", DeviceManagerApi.RadarGetVersionInfo)
}
