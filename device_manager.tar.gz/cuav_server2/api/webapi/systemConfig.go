package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

type systemConfigApi struct {
}

var (
	SystemConfigApi = new(systemConfigApi)
)

// swagger:route POST /systemConfig/update systemConfig global
// Responses:
//
//	200: Response
func (s *systemConfigApi) Update(req *restful.Request, res *restful.Response) {
	sysReq := &client.CrudReq{}
	sysRsp := &client.CrudRes{}
	err := req.ReadEntity(sysReq)
	if err != nil {
		logger.Errorf("update system config param[%v] error:%v", sysReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewSystemConfig().Update(context.Background(), sysReq, sysRsp)
	Result(err, res)
}

// swagger:route POST /systemConfig/delete systemConfig global
// Responses:
//
//	200: Response
func (s *systemConfigApi) Delete(req *restful.Request, res *restful.Response) {
	sysReq := &client.CrudReq{}
	sysRsp := &client.CrudRes{}
	err := req.ReadEntity(sysReq)
	if err != nil {
		logger.Errorf("delete system config param[%s] error:%v", sysReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewSystemConfig().Delete(context.Background(), sysReq, sysRsp)
	Result(err, res)
}

// swagger:route POST /systemConfig/config systemConfig config
// Responses:
//
//	200: Response
func (s *systemConfigApi) GetSystemConfig(req *restful.Request, res *restful.Response) {
	sysReq := &client.ConfigReq{}
	sysRsp := &client.ConfigRes{}
	err := handler.NewSystemConfig().GetSystemConfig(context.Background(), sysReq, sysRsp)
	if err != nil {
		logger.Errorf("call system_config_srv GetSystemConfig error:%v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	} else {
		Success(sysRsp, res)
	}
}

func init() {
	RegistHandler("/systemConfig/config", SystemConfigApi.GetSystemConfig)
	RegistHandler("/systemConfig/update", SystemConfigApi.Update)
	RegistHandler("/systemConfig/delete", SystemConfigApi.Delete)
}
