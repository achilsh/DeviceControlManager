package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

// SflGetVersionInfo 获取版本号
func (e *deviceManager) SflGetVersionInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetVersionRequest{}
	deviceRsp := &client.SflGetVersionResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflGetVersionInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// SflStopHit 发送停止打击
func (e *deviceManager) SflStopHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflStopHitRequest{}
	deviceRsp := &client.SflStopHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflStopHitSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflSetGNSS ...
func (e *deviceManager) SflSetGNSS(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflSetGNSSRequest{}
	deviceRsp := &client.SflSetGNSSResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	logger.Debug("SflSetGNSS ------- req ", deviceReq)
	err := handler.NewDeviceCenter().SflGNSSSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	logger.Debug("SflSetGNSS ------- deviceRsp", deviceRsp)
	Success(deviceRsp, res)
}

// SflGetGNSS ...
func (e *deviceManager) SflGetGNSS(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetGNSSRequest{}
	deviceRsp := &client.SflGetGNSSResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	logger.Debug("SflGetGNSS ------- deviceReq ", deviceReq)
	err := handler.NewDeviceCenter().SflGNSSGet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	logger.Debug("SflGetGNSS deviceRsp ----  ", deviceRsp)
	Success(deviceRsp, res)
}

// SflHitAngle 发送打击点信息配置
func (e *deviceManager) SflHitAngle(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflHitAngleRequest{}
	deviceRsp := &client.SflHitAngleResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflHitAngleSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflOnOff 发送开关机指令
func (e *deviceManager) SflOnOff(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflOnOffRequest{}
	deviceRsp := &client.SflOnOffResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflOnOffSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflResetting 发送一键复位指令
func (e *deviceManager) SflResetting(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflResetRequest{}
	deviceRsp := &client.SflResetResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflReSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflGetStatus 发送获取角度、工作模式、打击时长、打击范围
func (e *deviceManager) SflGetStatus(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetStatusRequest{}
	deviceRsp := &client.SflGetStatusResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflGetStatus(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflGetPower 发送获取开关机指令
func (e *deviceManager) SflGetPower(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetPowerRequest{}
	deviceRsp := &client.SflGetPowerResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflGetPower(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflDetectInfo 发送获取侦测信息
func (e *deviceManager) SflDetectInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflDetectInfoRequest{}
	deviceRsp := &client.SflDetectInfoResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflDetectInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflDetectInfoExport 发送侦测信息导出
func (e *deviceManager) SflDetectInfoExport(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflDetectInfoExportRequest{}
	deviceRsp := &client.SflDetectInfoExportResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflDetectInfoExport(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflHitUav 发送选中无人机打击
func (e *deviceManager) SflHitUav(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflSendHitUavRequest{}
	deviceRsp := &client.SflSendHitUavResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflSendHitUav(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflSetHitMode 发送设置工作模式：手动、自动
func (e *deviceManager) SflSetHitMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflSetHitModeRequest{}
	deviceRsp := &client.SflSetHitModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflSetHitMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflGetHitMode 发送获取工作模式：手动、自动
func (e *deviceManager) SflGetHitMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetHitModeRequest{}
	deviceRsp := &client.SflGetHitModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflGetHitMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// 启动/停止打击
func (e *deviceManager) SflTurnHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflTurnHitRequest{}
	deviceRsp := &client.SflTurnHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflTurnHit(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// 水平方向转动
func (e *deviceManager) SflHorizontalTurn(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflHorizontalTurnRequest{}
	deviceRsp := &client.SflHorizontalTurnResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflHorizontalTurn(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// 垂直方向转动
func (e *deviceManager) SflVerticalTurn(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflVerticalTurnRequest{}
	deviceRsp := &client.SflVerticalTurnResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflVerticalTurn(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func init() {
	RegistHandler("/device/sfl/get-version-info", DeviceManagerApi.SflGetVersionInfo)
	//停止当前打击
	RegistHandler("/device/sfl/stop-hit", DeviceManagerApi.SflStopHit)
	//设置打击参数信息
	RegistHandler("/device/sfl/hit-angle", DeviceManagerApi.SflHitAngle)
	//开机、关机
	RegistHandler("/device/sfl/on-off", DeviceManagerApi.SflOnOff)
	//一键云台复位
	RegistHandler("/device/sfl/resetting", DeviceManagerApi.SflResetting)
	//侦测看板
	RegistHandler("/device/sfl/detect-info", DeviceManagerApi.SflDetectInfo)
	//导出侦测看板
	RegistHandler("/device/sfl/detect-info-export", DeviceManagerApi.SflDetectInfoExport)
	//选中无人机手动打击
	RegistHandler("/device/sfl/hit-uav", DeviceManagerApi.SflHitUav)
	//获取设备状态
	RegistHandler("/device/sfl/get-status", DeviceManagerApi.SflGetStatus)
	//获取开关机状态
	RegistHandler("/device/sfl/get-onoff", DeviceManagerApi.SflGetPower)

	//设置是否自动打击
	RegistHandler("/device/sfl/set-hit-mode", DeviceManagerApi.SflSetHitMode)
	//获取是否自动打击
	RegistHandler("/device/sfl/get-hit-mode", DeviceManagerApi.SflGetHitMode)

	//获取设备GNSS位置
	RegistHandler("/device/sfl/setGNSS", DeviceManagerApi.SflSetGNSS)
	//设置设备GNSS位置
	RegistHandler("/device/sfl/getGNSS", DeviceManagerApi.SflGetGNSS)

	//启动/停止打击
	RegistHandler("/device/sfl/turn-hit", DeviceManagerApi.SflTurnHit)
	//水平方向转动
	RegistHandler("/device/sfl/horizontal-turn", DeviceManagerApi.SflHorizontalTurn)
	//垂直方向转动
	RegistHandler("/device/sfl/vertical-turn", DeviceManagerApi.SflVerticalTurn)
}
