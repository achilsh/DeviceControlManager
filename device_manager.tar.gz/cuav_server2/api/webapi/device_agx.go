package webapi

import (
	"context"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

// AgxSelectUav Agx  选中无人机命令下发
func (e *deviceManager) AgxSelectUav(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AgxSelectUavRequest{}
	deviceRsp := &client.AgxSelectUavResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().AgxSelectUav(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// AgxCalibration Agx  下发标定指令
func (e *deviceManager) AgxCalibration(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AgxCalibrationRequest{}
	deviceRsp := &client.AgxCalibrationRespone{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().AgxCalibration(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// AgxSelectSflUav Agx  选中Sfl无人机命令下发
func (e *deviceManager) AgxSelectSflUav(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AgxSelectSflUavRequest{}
	deviceRsp := &client.AgxSelectSflUavResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().AgxSelectSflUav(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}
func init() {

	RegistHandler("/device/agx/select-uav", DeviceManagerApi.AgxSelectUav)

	RegistHandler("/device/agx/calibration", DeviceManagerApi.AgxCalibration)

	RegistHandler("/device/agx/sfl/select-uav", DeviceManagerApi.AgxSelectSflUav)
}
