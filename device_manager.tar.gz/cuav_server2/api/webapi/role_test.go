package webapi

import (
	"context"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"github.com/agiledragon/gomonkey"
	"github.com/emicklei/go-restful"
	"github.com/stretchr/testify/assert"
)

func Test_roleApi_List(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{}`
	req := httptest.NewRequest(http.MethodPost, "/role/list", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	s := &handler.Role{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(s), "GetRoles", func(_ *handler.Role, _ context.Context, req *client.ListReq, res *client.ListRes) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		r    *roleApi
		args args
	}{
		{
			name: "Case1",
			r:    &roleApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.r.List(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_roleApi_Insert(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"name":"3445436", "status":1}`
	req := httptest.NewRequest(http.MethodPost, "/role/create", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	s := &handler.Role{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(s), "CreateRole", func(_ *handler.Role, _ context.Context, req *client.CreateReq, res *client.CreateRes) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		r    *roleApi
		args args
	}{
		{
			name: "Case1",
			r:    &roleApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			r := &roleApi{}
			r.Insert(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_roleApi_Update(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"name":"3445436", "status":1}`
	req := httptest.NewRequest(http.MethodPost, "/role/update", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	s := &handler.Role{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(s), "UpdateRole", func(_ *handler.Role, _ context.Context, req *client.UpdateRoleReq, res *client.UpdateRoleRes) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		r    *roleApi
		args args
	}{
		{
			name: "Case1",
			r:    &roleApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			r := &roleApi{}
			r.Update(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_roleApi_Delete(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"name":"3445436", "status":1}`
	req := httptest.NewRequest(http.MethodPost, "/role/delete", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	s := &handler.Role{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(s), "BatchDeleteRoleByIds", func(_ *handler.Role, _ context.Context, req *client.RoleIds, res *client.DeleteRes) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		r    *roleApi
		args args
	}{
		{
			name: "Case1",
			r:    &roleApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			r := &roleApi{}
			r.Delete(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}
