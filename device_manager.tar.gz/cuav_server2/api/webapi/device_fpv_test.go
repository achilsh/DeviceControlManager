package webapi

import (
	"context"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/agiledragon/gomonkey"
	"github.com/emicklei/go-restful"
)

func Test_deviceManager_FpvSendGetHitMode(t *testing.T) {
	data := `{"sn":"v1.0.0.15"}`
	req := httptest.NewRequest(http.MethodPost, "/device/fpv/get-hit-mode", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "FpvSendGetHitMode",
		func(_ *handler.DeviceCenter, _ context.Context, req *client.FpvSendGetHitModeRequest, rsp *client.FpvSendGetHitModeResponse) error {
			return nil
		})
	defer patches.Reset()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.FpvSendGetHitMode(tt.args.req, tt.args.res)
		})
	}
}

func Test_deviceManager_FpvSendGetHitTime(t *testing.T) {
	data := `{"sn":"v1.0.0.15"}`
	req := httptest.NewRequest(http.MethodPost, "/device/fpv/get-hit-time", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "FpvSendGetHitTime",
		func(_ *handler.DeviceCenter, _ context.Context, req *client.FpvSendGetHitTimeRequest, rsp *client.FpvSendGetHitTimeResponse) error {
			return nil
		})
	defer patches.Reset()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.FpvSendGetHitTime(tt.args.req, tt.args.res)
		})
	}
}

func Test_deviceManager_FpvSendHitUav(t *testing.T) {
	data := `{"sn":"v1.0.0.15"}`
	req := httptest.NewRequest(http.MethodPost, "/device/fpv/send-hit", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "FpvSendHitUav",
		func(_ *handler.DeviceCenter, _ context.Context, req *client.FpvSendHitRequest, rsp *client.FpvSendHitResponse) error {
			return nil
		})
	defer patches.Reset()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.FpvSendHitUav(tt.args.req, tt.args.res)
		})
	}
}

func Test_deviceManager_FpvSendSetHitMode(t *testing.T) {
	data := `{"sn":"v1.0.0.15","hit_mode":1}`
	req := httptest.NewRequest(http.MethodPost, "/device/fpv/set-hit-mode", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "FpvSendSetHitMode",
		func(_ *handler.DeviceCenter, _ context.Context, req *client.FpvSendSetHitModeRequest, rsp *client.FpvSendSetHitModeResponse) error {
			return nil
		})
	defer patches.Reset()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.FpvSendSetHitMode(tt.args.req, tt.args.res)
		})
	}
}

func Test_deviceManager_FpvSendSetHitTime(t *testing.T) {
	data := `{"sn":"v1.0.0.15","hit_time":20}`
	req := httptest.NewRequest(http.MethodPost, "/device/fpv/set-hit-time", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "FpvSendSetHitTime",
		func(_ *handler.DeviceCenter, _ context.Context, req *client.FpvSendSetHitTimeRequest, rsp *client.FpvSendSetHitTimeResponse) error {
			return nil
		})
	defer patches.Reset()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.FpvSendSetHitTime(tt.args.req, tt.args.res)
		})
	}
}

func Test_deviceManager_FpvSendStopHit(t *testing.T) {
	data := `{"sn":"v1.0.0.15"}`
	req := httptest.NewRequest(http.MethodPost, "/device/fpv/stop-hit", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "FpvSendStopHit",
		func(_ *handler.DeviceCenter, _ context.Context, req *client.FpvSendStopHitRequest, rsp *client.FpvSendStopHitResponse) error {
			return nil
		})
	defer patches.Reset()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.FpvSendStopHit(tt.args.req, tt.args.res)
		})
	}
}
