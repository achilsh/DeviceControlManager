package mavlink

import (
	"bytes"
	"encoding/binary"
	"strconv"
	"strings"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

const (
	ScreenIdGetChannel    = 0xB3
	ScreenIdHeart         = 0xC8
	ScreenMsgHit          = 0x23
	ScreenHitStatusUpload = 0x26
	SendHitResult         = 0x27
	ScreenHitResult       = 0x28
	DroneReduceValue      = 10000000 //10的7次方
	ScreenIdResetSystem   = 0xA1     // 屏幕复位
	ScreenGetTime         = 0xE3
	ScreenOtaReSetCode    = 0x55AA
)

type ScreenHeartBeatResponse struct {
	TimeStamp      uint32             `json:"timeStamp"`
	ScreenStatus   uint8              `json:"screenStatus"`
	Electricity    uint8              `json:"electricity"`
	SignalStrength uint8              `json:"signalStrength"`
	WorkStatus     uint8              `json:"workStatus"`
	AlarmLevel     uint8              `json:"alarmLevel"`
	HitFreq        uint8              `json:"hitFreq"`
	DetectFreq     uint32             `json:"detectFreq"`
	X              uint16             `json:"x"`
	Y              uint16             `json:"y"`
	Z              uint16             `json:"z"`
	GunLongitude   string             `json:"gunLongitude"`
	GunLatitude    string             `json:"gunLatitude"`
	GunAltitude    int32              `json:"gunAltitude"`
	SatellitesNum  uint16             `json:"satellitesNum"`
	GunDirection   string             `json:"gunDirection"`
	ReHitTime      uint16             `json:"reHitTime,omitempty"`
	HitTime        uint16             `json:"hitTime,omitempty"`
	UDroneNum      uint8              `json:"uDroneNum"`
	Elevation      string             `json:"elevation"`
	Info           []*ScreenHeartInfo `json:"info"`
}

type ScreenHeartInfo struct {
	ProductType        int    `json:"productType"`
	DroneName          string `json:"droneName"`
	SerialNum          string `json:"serialNum"`
	DroneLongitude     string `json:"droneLongitude"`
	DroneLatitude      string `json:"droneLatitude"`
	DroneHeight        string `json:"droneHeight"`
	DroneYawAngle      string `json:"droneYawAngle"`
	DroneSpeed         string `json:"droneSpeed"`
	DroneVerticalSpeed string `json:"droneVerticalSpeed"`
	PilotLongitude     string `json:"pilotLongitude"`
	PilotLatitude      string `json:"pilotLatitude"`
	DroneHorizon       string `json:"droneHorizon,omitempty"`
	DronePitch         string `json:"dronePitch,omitempty"`
	UFreq              string `json:"uFreq"`
	UDistance          string `json:"uDistance"`
	UDangerLevels      int    `json:"uDangerLevels"`
}

type ScreenGetChannelRequest struct {
	Sn         [32]uint8
	Company    [32]byte
	DeviceName [32]byte
	DeviceType uint16
	Version    [16]byte
}

func (g *ScreenGetChannelRequest) ID() uint8 {
	return ScreenIdGetChannel
}

func (g *ScreenGetChannelRequest) Size() uint16 {
	return 114
}

func (g *ScreenGetChannelRequest) IsNeedAns() uint8 {
	return 1
}

func (g *ScreenGetChannelRequest) SnToString() string {
	var bs []byte
	for _, v := range g.Sn {
		if v == 0x00 {
			break
		}
		bs = append(bs, v)
	}
	return string(bs)
}

type ScreenGetChannelResponse struct {
	Proxy       uint8
	GunIp       [4]uint8
	GunPort     uint16
	NewSourceID uint16
}

func (g *ScreenGetChannelResponse) ID() uint8 {
	return ScreenIdGetChannel
}

func (g *ScreenGetChannelResponse) Size() uint16 {
	return 9
}

func (g *ScreenGetChannelResponse) IsNeedAns() uint8 {
	return 0
}

func (g *ScreenGetChannelResponse) CreateGetChannelResponse(ip string, port uint16) []byte {
	if ip == "" {
		return nil
	}
	ipSegArr := strings.Split(ip, ".")
	var uIps [4]uint8
	for i, v := range ipSegArr {
		tmp, _ := strconv.Atoi(v)
		uIps[i] = uint8(tmp)
	}
	g.GunIp = uIps
	g.GunPort = port
	g.Proxy = 1
	g.NewSourceID = 3
	p, err := NewPacket(uint8(common.DEV_SCREEN), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type ScreenHeartbeatExtRequest struct {
	Sum uint8
}

func (r *ScreenHeartbeatExtRequest) ID() uint8 {
	return 0x25
}

func (r *ScreenHeartbeatExtRequest) Size() uint16 {
	return 1
}

func (g *ScreenHeartbeatExtRequest) IsNeedAns() uint8 {
	return 0
}

func (g *ScreenHeartbeatExtRequest) CreateScreenHeartbeatExt() []byte {
	p, err := NewPacket(uint8(common.DEV_SCREEN), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SetScreenHitRequest struct {
	Mode           uint8
	HitFreq        uint8
	DroneLongitude uint16
	DroneLatitude  uint16
	DroneAltitude  uint16
	HitTime        uint16 //打击时长，单位s ,默认10
}

func (g *SetScreenHitRequest) ID() uint8 {
	return 0x23
}

func (g *SetScreenHitRequest) Size() uint16 {
	return 10
}

func (g *SetScreenHitRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SetScreenHitRequest) CreateHitRequest() []byte {
	p, err := NewPacket(uint8(common.DEV_SCREEN), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SetScreenHitResponse struct {
	Status uint8 `json:"status"`
}

func (g *SetScreenHitResponse) ID() uint8 {
	return 0x23
}

func (g *SetScreenHitResponse) Size() uint16 {
	return 1
}

func (g *SetScreenHitResponse) IsNeedAns() uint8 {
	return 0
}

type SendScreenHitDataRequest struct {
}

type ScreenHitData struct {
	Mode               uint8
	HitFreq            uint8
	HitTime            uint16 //打击时长，单位s ,默认10
	ObjId              uint8
	ProductType        uint8
	DroneName          [20]byte
	SerialNum          [16]byte
	DroneLongitude     int32
	DroneLatitude      int32
	DroneHeight        int16
	DroneYawAngle      int16
	DroneSpeed         int16
	DroneVerticalSpeed int16
	PilotLongitude     int32
	PilotLatitude      int32
	UFreq              uint32
	UDistance          uint16
	UDangerLevels      uint16
	X                  int32
	Y                  int32
	Z                  int32
}

func (g *SendScreenHitDataRequest) ID() uint8 {
	return 0x23
}

func (g *SendScreenHitDataRequest) Size() uint16 {
	return 4
}

func (g *SendScreenHitDataRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SendScreenHitDataRequest) CreateHitRequest(uavs []*ScreenHitData) []byte {
	size := uint16(86 * len(uavs))
	rowLength := uint8(size & 0x00FF)
	highLength := uint8((size & 0xFF00) >> 8)
	mavPackage := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         uint8(common.DEV_SCREEN),
			SendID:            uint8(common.DEV_C2_WIFI),
			MessageID:         g.ID(),
			Ans:               g.IsNeedAns(),
		},
		Msg: g,
	}
	//计算checkSum
	var r bytes.Buffer
	if err := binary.Write(&r, binary.LittleEndian, mavPackage.Header); err != nil {
		return []byte{}
	}
	if err := binary.Write(&r, binary.LittleEndian, g); err != nil {
		return []byte{}
	}
	for _, v := range uavs {
		if err := binary.Write(&r, binary.LittleEndian, v); err != nil {
			return []byte{}
		}
	}
	dataBuff := r.Bytes()
	mavPackage.ComputeChecksum()
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	return genBuff
}

type ScreenHitStatusResponse struct {
	Status uint8 `json:"status"` // 0x01收到
}

func (g *ScreenHitStatusResponse) ID() uint8 {
	return 0x26
}

func (g *ScreenHitStatusResponse) Size() uint16 {
	return 1
}

func (g *ScreenHitStatusResponse) IsNeedAns() uint8 {
	return 0
}

func (g *ScreenHitStatusResponse) CreateScreenHitStatusResponse() []byte {
	p, err := NewPacket(uint8(common.DEV_SCREEN), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type ScreenHitStatus struct {
	WorkStatus uint8 `json:"work_status"` //枪工作状态 0x00: 侦测模式（打击结束) 0x01: 打击中
	DroneNum   uint8 `json:"drone_num"`   //	打击的无人机个数
}

type ScreenHitUav struct {
	ObjId          uint8    `json:"obj_id"`       //	无人机唯一标识
	ProductType    uint8    `json:"product_type"` //	无人机类型
	DroneName      [20]byte `json:"drone_name"`   //无人机名称
	SerialNum      [16]byte `json:"serial_num"`
	DroneLongitude int32    `json:"drone_longitude"` //LSB无人机经度(/1e7/pi*180)
	DroneLatitude  int32    `json:"drone_latitude"`  //LSB无人机纬度(/1e7/pi*180)
	DroneHeight    int16    `json:"drone_height"`    //LSB无人机相对地面高度(0.1m)
}

func (sr *ScreenHitStatus) ReverseHitUav(uavBuff []byte) []*client.HitUavEntity {
	packageLen := 48
	uavs := make([]*client.HitUavEntity, 0)
	for i := 0; i < int(sr.DroneNum); i++ {
		var tmp ScreenHitUav
		buff := &bytes.Buffer{}
		if err := binary.Write(buff, binary.LittleEndian, uavBuff[i*packageLen:(i+1)*packageLen]); err != nil {
			logger.Error("ReverseHitUav write err :", err)
			return nil
		}
		if err := binary.Read(buff, binary.LittleEndian, &tmp); err != nil {
			logger.Error("ReverseHitUav read err :", err)
			continue
		}
		nameBuff := make([]byte, 0)
		for _, v := range tmp.DroneName {
			if v == 0x00 {
				continue
			}
			nameBuff = append(nameBuff, v)
		}
		snBuff := make([]byte, 0)
		for _, v := range tmp.SerialNum {
			if v == 0x00 {
				continue
			}
			snBuff = append(snBuff, v)
		}
		uavs = append(uavs, &client.HitUavEntity{
			ObjId:          uint32(tmp.ObjId),
			ProductType:    uint32(tmp.ProductType),
			DroneName:      string(nameBuff),
			SerialNum:      string(snBuff),
			DroneLongitude: tmp.DroneLongitude,
			DroneLatitude:  tmp.DroneLatitude,
			DroneHeight:    int32(tmp.DroneHeight),
		})
	}
	return uavs
}

func (g *ScreenHitStatus) ID() uint8 {
	return 0x26
}

func (g *ScreenHitStatus) Size() uint16 {
	return 2
}

func (g *ScreenHitStatus) IsNeedAns() uint8 {
	return 1
}

type SendHitResultRequest struct {
	DroneNum uint8 `json:"drone_num"`
}

type HitResult struct {
	ObjId  uint8 `json:"obj_id"`
	Result uint8 `json:"result"`
}

func (g *SendHitResultRequest) ID() uint8 {
	return 0x27
}

func (g *SendHitResultRequest) Size() uint16 {
	return 1
}

func (g *SendHitResultRequest) IsNeedAns() uint8 {
	return 0
}

func (g *SendHitResultRequest) CreateHitRequest(hitRes []*HitResult) []byte {
	size := 1 + 2*g.DroneNum
	mavPackage := &MavPacket{
		Header: MavHeader{
			FrameStart:       FrameStart,
			PayloadLowLength: size,
			PacketSequence:   PackageSeq,
			ReceiveID:        uint8(common.DEV_SCREEN),
			SendID:           uint8(common.DEV_C2_WIFI),
			MessageID:        g.ID(),
			Ans:              g.IsNeedAns(),
		},
		Msg: g,
	}
	//计算checkSum
	var r bytes.Buffer
	if err := binary.Write(&r, binary.LittleEndian, mavPackage.Header); err != nil {
		return []byte{}
	}
	if err := binary.Write(&r, binary.LittleEndian, g); err != nil {
		return []byte{}
	}
	for _, v := range hitRes {
		if err := binary.Write(&r, binary.LittleEndian, v); err != nil {
			return []byte{}
		}
	}
	dataBuff := r.Bytes()
	mavPackage.ComputeChecksum()
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	return genBuff
}

type ScreenCloseConnRequest struct {
	Status uint8
}

func (g *ScreenCloseConnRequest) ID() uint8 {
	return 0x28
}

func (g *ScreenCloseConnRequest) Size() uint16 {
	return 1
}

func (g *ScreenCloseConnRequest) IsNeedAns() uint8 {
	return 1
}

func (g *ScreenCloseConnRequest) CreateScreenCloseConn() []byte {
	g.Status = 1
	p, err := NewPacket(uint8(common.DEV_SCREEN), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type ScreenCloseConnResponse struct {
	Status uint8
}

func (g *ScreenCloseConnResponse) ID() uint8 {
	return 0x28
}

func (g *ScreenCloseConnResponse) Size() uint16 {
	return 1
}

func (g *ScreenCloseConnResponse) IsNeedAns() uint8 {
	return 0
}

// ScreenResetSystemRequest 雷达复位请求
type ScreenResetSystemRequest struct {
	ResetCode uint16 `json:"reset_code"`
	Type      uint16 `json:"type"`
}

func (g *ScreenResetSystemRequest) ID() uint8 {
	return 0xA1
}

func (g *ScreenResetSystemRequest) Size() uint16 {
	return 4
}

func (g *ScreenResetSystemRequest) IsNeedAns() uint8 {
	return 1
}

func (g *ScreenResetSystemRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_SCREEN), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type ScreenResetSystemResponse struct {
	Status uint8 `json:"status"`
}

func (g *ScreenResetSystemResponse) ID() uint8 {
	return 0xA1
}

func (g *ScreenResetSystemResponse) Size() uint16 {
	return 1
}

func (g *ScreenResetSystemResponse) IsNeedAns() uint8 {
	return 0
}

type ScreenGetTimeResponse struct {
	Time [20]byte `json:"time"`
}

func (g *ScreenGetTimeResponse) ID() uint8 {
	return 0xE3
}

func (g *ScreenGetTimeResponse) Size() uint16 {
	return 20
}

func (g *ScreenGetTimeResponse) IsNeedAns() uint8 {
	return 1
}

func (g *ScreenGetTimeResponse) CreateGetTimeMessage(time [20]byte) []byte {
	g.Time = time
	p, err := NewPacket(uint8(common.DEV_SCREEN), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}
