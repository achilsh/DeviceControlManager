package mavlink

import (
	"bytes"
	"encoding/binary"
	"fmt"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
)

const (
	FpvUdpBroadcastResponse = 0xBB
	C2SendHeartbeatToFpv    = 0x25

	FpvMsgHeartbeat           = 0xEF
	FpvGetFreqDetectRes       = 0xE2
	FpvGetHitStateRes         = 0xE4
	FpvPushVideoStreams       = 0xE7
	FpvGetVersionInfo         = 0x20
	FpvCliSend                = 0x2F //下发Fpv指令
	FpvIdGetVersionInfo       = 0xAB // 获取版本信息
	FpvIdResetSystem          = 0xA1 // 系统复位
	FpvIdGetUpdateWriteStatus = 0xA6 // 获取固件写入状态
	FpvIdRequestUpgrade       = 0xA7 // 请求固件升级
	FpvIdSendUpdatePkg        = 0xA8 // 发送升级固件数据
	FpvIdWriteUpdateData      = 0xA9 // 写入固件数据
	FpvIdRunApp               = 0xAD // 运行固件App
	FpvIdVerifyImage          = 0xAC // 校验固件镜像
	FpvIdGetTimeoutRetryTime  = 0xAE // 获取运行超时重试时间

	FpvSendSetHitMode = 0x30
	FpvSendGetHitMode = 0x31

	FpvSendHitCmd     = 0x32
	FpvSendStopHitCmd = 0x33

	FpvSendSetHitTime = 0x34
	FpvSendGetHitTime = 0x35

	FpvHeartReportMsg    = 401
	FpvFreqReportMsg     = 402
	FpvHitStateReportMsg = 403
	FpvVideoStreamMsg    = 404

	FpvC2SystemConfig = 405
	FpvOtaReSetCode   = 0x55AA
)

type FpvHeartbeat struct {
	Info FpvDeviceInfo
}

type FpvDeviceInfo struct {
	TimeStamp     uint32
	Electricity   uint8
	BatteryStatus uint8 //0：电池 1：电池 + 适配器（充电） 2：适配器
	WorkMode      uint8 //工作模式 1:Droneid模式  2:全向侦测模式  3:定向侦测模式
	WorkStatus    uint8 //TRACER工作状态 0：待机 1: 侦测 2：打击中 3：水平扫描中 4：水平瞄准中 5：俯仰扫描中 6：俯仰瞄准中 7：瞄准完成
	Fault         uint8 //0：没有故障 1：有故障 2：其他故障依次添加
	AlarmLevel    uint8 //0: 拨码开关关闭，无告警 1: 低档告警 2: 中档告警 3: 高档告警
	Buzzer        uint8 //0: 蜂鸣器不响 1：蜂鸣器响
	Vibration     uint8 //0: 马达震动关闭 1：马达震动打开
	StealthMode   uint8 //0: 隐蔽模式关闭 1：隐蔽模式打开
	Recerve       int32 //保留
	SN            [25]uint8
}

func (d *FpvDeviceInfo) Size() uint16 {
	return uint16(binary.Size(d))
}

type FpvReport struct {
	TimeStamp     uint32 `json:"time_stamp"`
	Electricity   uint8  `json:"electricity"`
	Sn            string `json:"sn"`
	IsOnline      int    `json:"is_online"`
	BatteryStatus uint8  `json:"battery_status"` //0：电池 1：电池 + 适配器（充电） 2：适配器
	WorkMode      uint8  `json:"work_mode"`      //工作模式 1:Droneid模式  2:全向侦测模式  3:定向侦测模式
	WorkStatus    uint8  `json:"work_status"`    //TRACER工作状态 0：待机 1: 侦测 2：打击中 3：水平扫描中 4：水平瞄准中 5：俯仰扫描中 6：俯仰瞄准中 7：瞄准完成
	Fault         uint8  `json:"fault"`          //0：没有故障 1：有故障 2：其他故障依次添加
	AlarmLevel    uint8  `json:"alarm_level"`    //0: 拨码开关关闭，无告警 1: 低档告警 2: 中档告警 3: 高档告警
	Buzzer        uint8  `json:"buzzer"`         //0: 蜂鸣器不响 1：蜂鸣器响
	Vibration     uint8  `json:"vibration"`      //0: 马达震动关闭 1：马达震动打开
	StealthMode   uint8  `json:"stealth_mode"`   //0: 隐蔽模式关闭 1：隐蔽模式打开
}
type FpvHitState struct {
	Sn       [25]byte
	HitState uint8 //1打击中    2打击结束
}

type FpvHitStateReport struct {
	Sn       string `json:"sn"`
	HitState int    `json:"hit_state"` //1 打击中   2 打击结束
}

func (g *FpvHitState) ID() uint8 {
	return FpvGetHitStateRes
}

func (g *FpvHitState) Size() uint16 {
	return 26
}

func (g *FpvHitState) IsNeedAns() uint8 {
	return 0
}

type FpvGetChannelRequest struct {
	Sn         [32]uint8
	Company    [32]uint8
	DeviceName [32]uint8
	DeviceType uint16
	Version    [16]byte
}

func (d *FpvGetChannelRequest) ID() uint8 {
	return DRONEIDMsgGetChannel
}

func (d *FpvGetChannelRequest) Size() uint16 {
	return uint16(binary.Size(d))
}

func (d *FpvGetChannelRequest) IsNeedAns() uint8 {
	return 1
}

type FpvHeartbeatExtRequest struct {
	Sum uint8
}

func (d *FpvHeartbeatExtRequest) ID() uint8 {
	return C2SendHeartbeatToFpv
}

func (d *FpvHeartbeatExtRequest) Size() uint16 {
	return 1
}

func (d *FpvHeartbeatExtRequest) IsNeedAns() uint8 {
	return 0
}

func (d *FpvHeartbeatExtRequest) CreateFpvHeartbeatExt() []byte {
	p, err := NewPacket(uint8(common.DEV_FPV), uint8(common.DEV_C2_WIFI), d)
	if err != nil {
		return nil
	}
	fpvBuff := p.StructToSlice()
	return fpvBuff
}

// 上传频谱（定向）侦测结果
type FpvFreqDetectResult struct {
	Info        FpvFreqDetectInfo
	Description []*FpvFreqDetectDescription
}
type FpvFreqDetectInfo struct {
	SN        [25]uint8
	QxPower   uint16 //全向功率
	DxPower   uint16 //定向功率
	DxHorizon int32  //定向天线水平角(0.01°)
	DroneNum  uint8
}
type FpvFreqDetectDescription struct {
	UavNumber     uint8     //无人机编号
	DroneName     [25]uint8 //无人机品牌+机型
	DroneHorizon  int32     //lsb 目标水平角（0.01°），无效值0x7fffffff
	UFreq         uint32    //频率
	UDangerLevels uint16    //危险等级
	Recerve       int32     //保留
}
type FpvFreqDetectReport struct {
	Sn          string                            `json:"sn"`
	QxPower     float64                           `json:"qx_power"`   //全向功率
	DxPower     float64                           `json:"dx_power"`   //定向功率
	DxHorizon   float64                           `json:"dx_horizon"` //定向天线水平角(0.01°)
	Description []*FpvFreqDetectDescriptionReport `json:"list"`
}
type FpvFreqDetectDescriptionReport struct {
	UavNumber     uint8   `json:"uav_number"`      //无人机编号
	DroneName     string  `json:"drone_name"`      //无人机品牌+机型
	DroneHorizon  float64 `json:"drone_horizon"`   //lsb 目标水平角（0.01°），无效值0x7fffffff
	UFreq         float64 `json:"u_freq"`          //频率
	UDangerLevels uint16  `json:"u_danger_levels"` //危险等级
	Recerve       int32   `json:"recerve"`         //保留
}

func (d *FpvFreqDetectResult) DeserializeDrone(msg []byte) error {
	if err := d.checkDroneMsg(msg); err != nil {
		d.Info.DroneNum = 0
		return nil
	}

	//drones := make([]*Drone, 0)
	//packageLen := binary.Size(DroneID{})
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, msg); err != nil {
		return fmt.Errorf("DeserializeDrone write buff err: %v", err)
	}

	for i := 0; i < int(d.Info.DroneNum); i++ {
		var drone FpvFreqDetectDescription
		if err := binary.Read(buff, binary.LittleEndian, &drone); err != nil {
			return fmt.Errorf("DeserializeDrone read buff err: %v", err)
		}
		d.Description = append(d.Description, &drone)
	}

	return nil
}

func (d *FpvFreqDetectResult) checkDroneMsg(msg []byte) error {
	packageLen := binary.Size(FpvFreqDetectDescription{})
	if len(msg)/packageLen != int(d.Info.DroneNum) || len(msg)%packageLen != 0 {
		return fmt.Errorf("Fpv data len err: {msg len:%v, packageLen:%v, DroneNum:%v}", len(msg), packageLen, d.Info.DroneNum)
	}
	return nil
}

// FpvSendGetVersionRequest Fpv获取版本信息
type FpvSendGetVersionRequest struct {
}

func (g *FpvSendGetVersionRequest) ID() uint8 {
	return FpvGetVersionInfo
}

func (g *FpvSendGetVersionRequest) Size() uint16 {
	return 0
}

func (g *FpvSendGetVersionRequest) IsNeedAns() uint8 {
	return 1
}

func (g *FpvSendGetVersionRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_FPV), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type FpvSendGetVersionResponse struct {
	CompanyName [16]byte
	DeviceName  [16]byte
	PsVersion   [32]byte
	PlVersion   [32]byte
	DeviceSn    [32]byte
	DeviceIP    [16]byte
}

func (g *FpvSendGetVersionResponse) ID() uint8 {
	return FpvGetVersionInfo
}

func (g *FpvSendGetVersionResponse) Size() uint16 {
	return uint16(binary.Size(g))
}

func (g *FpvSendGetVersionResponse) IsNeedAns() uint8 {
	return 0
}

// FpvSendSetHitModeRequest Fpv设置打击模式
type FpvSendSetHitModeRequest struct {
	Status   uint8
	Reserved [3]byte
}

func (g *FpvSendSetHitModeRequest) ID() uint8 {
	return FpvSendSetHitMode
}

func (g *FpvSendSetHitModeRequest) Size() uint16 {
	return 4
}

func (g *FpvSendSetHitModeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *FpvSendSetHitModeRequest) Create(hitMode uint8) []byte {
	g.Status = hitMode
	g.Reserved = [3]uint8{}

	p, err := NewPacket(uint8(common.DEV_FPV), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type FpvSendSetHitModeResponse struct {
	Status uint8
}

func (g *FpvSendSetHitModeResponse) ID() uint8 {
	return FpvSendSetHitMode
}

func (g *FpvSendSetHitModeResponse) Size() uint16 {
	return 1
}

func (g *FpvSendSetHitModeResponse) IsNeedAns() uint8 {
	return 0
}

// FpvSendGetHitModeRequest Fpv获取打击模式
type FpvSendGetHitModeRequest struct {
}

func (g *FpvSendGetHitModeRequest) ID() uint8 {
	return FpvSendGetHitMode
}

func (g *FpvSendGetHitModeRequest) Size() uint16 {
	return 0
}

func (g *FpvSendGetHitModeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *FpvSendGetHitModeRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_FPV), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type FpvSendGetHitModeResponse struct {
	Status uint8
}

func (g *FpvSendGetHitModeResponse) ID() uint8 {
	return FpvSendGetHitMode
}

func (g *FpvSendGetHitModeResponse) Size() uint16 {
	return 1
}

func (g *FpvSendGetHitModeResponse) IsNeedAns() uint8 {
	return 0
}

// FpvSendHitRequest Fpv发送打击
type FpvSendHitRequest struct {
}

func (g *FpvSendHitRequest) ID() uint8 {
	return FpvSendHitCmd
}

func (g *FpvSendHitRequest) Size() uint16 {
	return 0
}

func (g *FpvSendHitRequest) IsNeedAns() uint8 {
	return 1
}

func (g *FpvSendHitRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_FPV), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type FpvSendHitResponse struct {
	Status uint8
}

func (g *FpvSendHitResponse) ID() uint8 {
	return FpvSendHitCmd
}

func (g *FpvSendHitResponse) Size() uint16 {
	return 1
}

func (g *FpvSendHitResponse) IsNeedAns() uint8 {
	return 0
}

// FpvSendStopHitRequest Fpv发送停止打击
type FpvSendStopHitRequest struct {
}

func (g *FpvSendStopHitRequest) ID() uint8 {
	return FpvSendStopHitCmd
}

func (g *FpvSendStopHitRequest) Size() uint16 {
	return 0
}

func (g *FpvSendStopHitRequest) IsNeedAns() uint8 {
	return 1
}

func (g *FpvSendStopHitRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_FPV), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type FpvSendStopHitResponse struct {
	Status uint8
}

func (g *FpvSendStopHitResponse) ID() uint8 {
	return FpvSendStopHitCmd
}

func (g *FpvSendStopHitResponse) Size() uint16 {
	return 1
}

func (g *FpvSendStopHitResponse) IsNeedAns() uint8 {
	return 0
}

// FpvSetHitTimeRequest Fpv发送设置打击时长
type FpvSetHitTimeRequest struct {
	HitTime uint8
}

func (g *FpvSetHitTimeRequest) ID() uint8 {
	return FpvSendSetHitTime
}

func (g *FpvSetHitTimeRequest) Size() uint16 {
	return 1
}

func (g *FpvSetHitTimeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *FpvSetHitTimeRequest) Create(hitTime uint8) []byte {
	g.HitTime = hitTime
	p, err := NewPacket(uint8(common.DEV_FPV), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type FpvSetHitTimeResponse struct {
	Status uint8
}

func (g *FpvSetHitTimeResponse) ID() uint8 {
	return FpvSendSetHitTime
}

func (g *FpvSetHitTimeResponse) Size() uint16 {
	return 1
}

func (g *FpvSetHitTimeResponse) IsNeedAns() uint8 {
	return 0
}

// FpvGetHitTimeRequest Fpv发送获取打击时长
type FpvGetHitTimeRequest struct {
}

func (g *FpvGetHitTimeRequest) ID() uint8 {
	return FpvSendGetHitTime
}

func (g *FpvGetHitTimeRequest) Size() uint16 {
	return 0
}

func (g *FpvGetHitTimeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *FpvGetHitTimeRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_FPV), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type FpvGetHitTimeResponse struct {
	HitTime uint8 //打击时长
}

func (g *FpvGetHitTimeResponse) ID() uint8 {
	return FpvSendGetHitTime
}

func (g *FpvGetHitTimeResponse) Size() uint16 {
	return 1
}

func (g *FpvGetHitTimeResponse) IsNeedAns() uint8 {
	return 0
}

// FpvCliRequest 下发Fpv指令
type FpvCliRequest struct {
	Handle uint32
	Cmd    []uint8
}

func (g *FpvCliRequest) ID() uint8 {
	return TracerCliSend
}

func (g *FpvCliRequest) Size() uint16 {
	return uint16(g.Len())
}

func (g *FpvCliRequest) IsNeedAns() uint8 {
	return 1
}
func (g *FpvCliRequest) Len() int {
	return 4 + len(g.Cmd)
}

func (g *FpvCliRequest) Create() []byte {

	size := g.Size()
	rowLength := uint8(size & 0x00FF)
	highLength := uint8((size & 0xFF00) >> 8)
	var header MavHeader
	header = MavHeader{
		FrameStart:        FrameStart,
		PayloadLowLength:  rowLength,
		PayloadHighLength: highLength,
		PacketSequence:    PackageSeq,
		ReceiveID:         uint8(common.DEV_FPV),
		SendID:            uint8(common.DEV_C2_WIFI),
		MessageID:         g.ID(),
		Ans:               g.IsNeedAns(),
	}
	header.Checksum = g.computeChecksum(header)
	genBuff := g.structToSlice(header)

	return genBuff
}
func (g *FpvCliRequest) bytes(header MavHeader) []byte {
	var r bytes.Buffer
	var err error
	if err = binary.Write(&r, binary.LittleEndian, header); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.Handle); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.Cmd); err != nil {
		return []byte{}
	}

	return r.Bytes()
}

func (g *FpvCliRequest) computeChecksum(header MavHeader) uint8 {
	var sum uint32
	buff := g.bytes(header)
	if buff == nil || len(buff) < CheckSumLen {
		return 0
	}
	sumData := buff[:CheckSumLen]
	for _, v := range sumData {
		sum += uint32(v)
	}
	return uint8(sum & 0xFF)
}

func (g *FpvCliRequest) structToSlice(header MavHeader) []byte {
	dataBuff := g.bytes(header)
	if len(dataBuff) <= 0 {
		return dataBuff
	}
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	return genBuff
}

// FpvCliResponse Fpv指令响应
type FpvCliResponse struct {
	Handle          uint32
	CmdParseRetcode uint32
	CmdExecRetcode  uint32
	CmdResult       []byte
}

func (g *FpvCliResponse) ID() uint8 {
	return TracerCliSend
}

func (g *FpvCliResponse) Size() uint16 {
	return uint16(12 + len(g.CmdResult))
}

func (g *FpvCliResponse) IsNeedAns() uint8 {
	return 0
}

const DevSNLen int = 25

type FpvTransferVideoStreamPkg struct {
	SN         [DevSNLen]uint8 //fpv的sn
	FrameIndex uint32          //帧序号
	PkgMax     uint32          //最大分包数
	PkgIndex   uint32          //分包序号
	DataLen    uint32          //分包中数据域长度
	Data       []byte          //分包中payload数据域，长度由DataLen来确定
}

// FpvResetSystemRequest Fpv复位请求
type FpvResetSystemRequest struct {
	ResetCode uint16 `json:"reset_code"`
	Type      uint16 `json:"type"`
}

func (g *FpvResetSystemRequest) ID() uint8 {
	return FpvIdResetSystem
}

func (g *FpvResetSystemRequest) Size() uint16 {
	return 4
}

func (g *FpvResetSystemRequest) IsNeedAns() uint8 {
	return 0
}

func (g *FpvResetSystemRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_FPV), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

// FpvRunAppRequest 请求运行固件App
type FpvRunAppRequest struct {
}

func (g *FpvRunAppRequest) ID() uint8 {
	return FpvIdRunApp
}

func (g *FpvRunAppRequest) Size() uint16 {
	return 0
}

func (g *FpvRunAppRequest) IsNeedAns() uint8 {
	return 1
}

func (g *FpvRunAppRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_FPV), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type FpvRunAppResponse struct {
	Status uint8 `json:"status"`
}

func (g *FpvRunAppResponse) ID() uint8 {
	return FpvIdRunApp
}

func (g *FpvRunAppResponse) Size() uint16 {
	return 1
}

func (g *FpvRunAppResponse) IsNeedAns() uint8 {
	return 0
}

// FpvGetUpdateWriteStatusRequest 获取固件更新写入状态请求
type FpvGetUpdateWriteStatusRequest struct {
}

func (g *FpvGetUpdateWriteStatusRequest) ID() uint8 {
	return FpvIdGetUpdateWriteStatus
}

func (g *FpvGetUpdateWriteStatusRequest) Size() uint16 {
	return 0
}

func (g *FpvGetUpdateWriteStatusRequest) IsNeedAns() uint8 {
	return 1
}

func (g *FpvGetUpdateWriteStatusRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_FPV), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type FpvGetUpdateWriteStatusResponse struct {
	Status uint8  `json:"status"`
	Permil uint16 `json:"permil"`
}

func (g *FpvGetUpdateWriteStatusResponse) ID() uint8 {
	return FpvIdGetUpdateWriteStatus
}

func (g *FpvGetUpdateWriteStatusResponse) Size() uint16 {
	return 3
}

func (g *FpvGetUpdateWriteStatusResponse) IsNeedAns() uint8 {
	return 0
}

// FpvWriteUpdateDataRequest 写入固件数据
type FpvWriteUpdateDataRequest struct {
}

func (g *FpvWriteUpdateDataRequest) ID() uint8 {
	return FpvIdWriteUpdateData
}

func (g *FpvWriteUpdateDataRequest) Size() uint16 {
	return 0
}

func (g *FpvWriteUpdateDataRequest) IsNeedAns() uint8 {
	return 1
}

func (g *FpvWriteUpdateDataRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_FPV), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type FpvWriteUpdateDataResponse struct {
	Status uint8 `json:"status"`
}

func (g *FpvWriteUpdateDataResponse) ID() uint8 {
	return FpvIdWriteUpdateData
}

func (g *FpvWriteUpdateDataResponse) Size() uint16 {
	return 1
}

func (g *FpvWriteUpdateDataResponse) IsNeedAns() uint8 {
	return 0
}

// FpvVerifyImageRequest 请求校验固件
type FpvVerifyImageRequest struct {
}

func (g *FpvVerifyImageRequest) ID() uint8 {
	return FpvIdVerifyImage
}

func (g *FpvVerifyImageRequest) Size() uint16 {
	return 0
}

func (g *FpvVerifyImageRequest) IsNeedAns() uint8 {
	return 1
}

func (g *FpvVerifyImageRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_FPV), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type FpvVerifyImageResponse struct {
	Status uint8 `json:"status"`
}

func (g *FpvVerifyImageResponse) ID() uint8 {
	return FpvIdVerifyImage
}

func (g *FpvVerifyImageResponse) Size() uint16 {
	return 1
}

func (g *FpvVerifyImageResponse) IsNeedAns() uint8 {
	return 0
}

// FpvRequestUpgradeRequest 请求固件升级
type FpvRequestUpgradeRequest struct {
	Data [256]uint8 `json:"data"`
}

func (g *FpvRequestUpgradeRequest) ID() uint8 {
	return FpvIdRequestUpgrade
}

func (g *FpvRequestUpgradeRequest) Size() uint16 {
	return 256
}

func (g *FpvRequestUpgradeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *FpvRequestUpgradeRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_FPV), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type FpvRequestUpgradeResponse struct {
	Status uint8 `json:"status"`
}

func (g *FpvRequestUpgradeResponse) ID() uint8 {
	return FpvIdRequestUpgrade
}

func (g *FpvRequestUpgradeResponse) Size() uint16 {
	return 8
}

func (g *FpvRequestUpgradeResponse) IsNeedAns() uint8 {
	return 0
}

// FpvGetVersionRequest Fpv获取版本信息请求
type FpvGetVersionRequest struct {
}

func (g *FpvGetVersionRequest) ID() uint8 {
	return FpvIdGetVersionInfo
}

func (g *FpvGetVersionRequest) Size() uint16 {
	return 0
}

func (g *FpvGetVersionRequest) IsNeedAns() uint8 {
	return 1
}

func (g *FpvGetVersionRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_FPV), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type FpvGetVersionResponse struct {
	RunVersion      uint32   //当前运行版 0-boot1-app
	AppVersion      [64]byte //软件版本号
	BootVersion     [32]byte //Bootloader
	HwVersion       [32]byte //硬件版本号
	ProtocolVersion [32]byte //协议版本号
}

func (g *FpvGetVersionResponse) ID() uint8 {
	return FpvIdGetVersionInfo
}

func (g *FpvGetVersionResponse) Size() uint16 {
	return 164
}

func (g *FpvGetVersionResponse) IsNeedAns() uint8 {
	return 0
}

// FpvSendUpdatePkgRequest 发送升级固件数据
type FpvSendUpdatePkgRequest struct {
	ImageOffset uint32  `json:"image_offset"` // 数据偏移位置
	ImageLength uint32  `json:"image_length"` // 数据长度
	ImageData   []uint8 `json:"image_data"`   // 升级数据流，最大4096字节
}

func (g *FpvSendUpdatePkgRequest) ID() uint8 {
	return FpvIdSendUpdatePkg
}

func (g *FpvSendUpdatePkgRequest) Size() uint16 {
	return uint16(g.Len())
}

func (g *FpvSendUpdatePkgRequest) IsNeedAns() uint8 {
	return 1
}

func (g *FpvSendUpdatePkgRequest) Len() int {
	return 8 + len(g.ImageData)
}

// Create 元素长度不固定使用protocols下的message进行编码
func (g *FpvSendUpdatePkgRequest) Create() ([]byte, error) {

	size := g.Size()
	rowLength := uint8(size & 0x00FF)
	highLength := uint8((size & 0xFF00) >> 8)
	header := MavHeader{
		FrameStart:        FrameStart,
		PayloadLowLength:  rowLength,
		PayloadHighLength: highLength,
		PacketSequence:    PackageSeq,
		ReceiveID:         uint8(common.DEV_FPV),
		SendID:            uint8(common.DEV_C2_WIFI),
		MessageID:         g.ID(),
		Ans:               g.IsNeedAns(),
	}
	header.Checksum = g.computeChecksum(header)
	genBuff := g.structToSlice(header)

	return genBuff, nil
}

func (g *FpvSendUpdatePkgRequest) bytes(header MavHeader) []byte {
	var r bytes.Buffer
	var err error
	if err = binary.Write(&r, binary.LittleEndian, header); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.ImageOffset); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.ImageLength); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.ImageData); err != nil {
		return []byte{}
	}
	return r.Bytes()
}

func (g *FpvSendUpdatePkgRequest) computeChecksum(header MavHeader) uint8 {
	var sum uint32
	buff := g.bytes(header)
	if buff == nil || len(buff) < CheckSumLen {
		return 0
	}
	sumData := buff[:CheckSumLen]
	for _, v := range sumData {
		sum += uint32(v)
	}
	return uint8(sum & 0xFF)
}

func (g *FpvSendUpdatePkgRequest) structToSlice(header MavHeader) []byte {
	dataBuff := g.bytes(header)
	if len(dataBuff) <= 0 {
		return dataBuff
	}
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	return genBuff
}

type FpvSendUpdatePkgResponse struct {
	Status uint8  `json:"status"`
	Rsv1   uint8  `json:"rsv1"`
	Rsv2   uint8  `json:"rsv2"`
	Rsv3   uint8  `json:"rsv3"`
	Offset uint32 `json:"offset"`
}

func (g *FpvSendUpdatePkgResponse) ID() uint8 {
	return FpvIdSendUpdatePkg
}

func (g *FpvSendUpdatePkgResponse) Size() uint16 {
	return 5
}

func (g *FpvSendUpdatePkgResponse) IsNeedAns() uint8 {
	return 0
}
